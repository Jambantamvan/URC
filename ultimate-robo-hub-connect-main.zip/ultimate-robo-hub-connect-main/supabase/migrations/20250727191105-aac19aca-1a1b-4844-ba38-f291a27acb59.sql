-- Pertama, tambahkan kolom yang dibutuhkan ke tabel projects untuk memperbaiki issue pembuatan proyek
ALTER TABLE projects 
ADD COLUMN IF NOT EXISTS github_url TEXT,
ADD COLUMN IF NOT EXISTS demo_url TEXT,
ADD COLUMN IF NOT EXISTS image_url TEXT;

-- Tambahkan kolom untuk enhanced registration form
ALTER TABLE registration_requests 
ADD COLUMN IF NOT EXISTS full_name TEXT,
ADD COLUMN IF NOT EXISTS age INTEGER,
ADD COLUMN IF NOT EXISTS hobbies TEXT,
ADD COLUMN IF NOT EXISTS birth_place TEXT,
ADD COLUMN IF NOT EXISTS gender TEXT,
ADD COLUMN IF NOT EXISTS phone TEXT;

-- Update nama kolom untuk backward compatibility
UPDATE registration_requests SET full_name = name WHERE full_name IS NULL;

-- Create table untuk user presence dan status
CREATE TABLE IF NOT EXISTS user_presence (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  status TEXT NOT NULL DEFAULT 'offline' CHECK (status IN ('online', 'offline', 'busy')),
  last_seen TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS for user_presence
ALTER TABLE user_presence ENABLE ROW LEVEL SECURITY;

-- Create policies for user_presence
CREATE POLICY "User presence is viewable by everyone" 
ON user_presence 
FOR SELECT 
USING (true);

CREATE POLICY "Users can update their own presence" 
ON user_presence 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own presence status" 
ON user_presence 
FOR UPDATE 
USING (auth.uid() = user_id);

-- Create table untuk admin warnings
CREATE TABLE IF NOT EXISTS user_warnings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  admin_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  reason TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'warning' CHECK (type IN ('warning', 'punishment')),
  severity TEXT NOT NULL DEFAULT 'minor' CHECK (severity IN ('minor', 'major', 'severe')),
  description TEXT,
  expires_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  is_active BOOLEAN NOT NULL DEFAULT true
);

-- Enable RLS for user_warnings
ALTER TABLE user_warnings ENABLE ROW LEVEL SECURITY;

-- Create policies for user_warnings
CREATE POLICY "Admins can manage warnings" 
ON user_warnings 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM profiles 
  WHERE profiles.id = auth.uid() 
  AND profiles.role = 'admin'
));

CREATE POLICY "Users can view their own warnings" 
ON user_warnings 
FOR SELECT 
USING (auth.uid() = user_id OR EXISTS (
  SELECT 1 FROM profiles 
  WHERE profiles.id = auth.uid() 
  AND profiles.role = 'admin'
));

-- Create table untuk forum mentions
CREATE TABLE IF NOT EXISTS forum_mentions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  mentioned_user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  mentioner_user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  thread_id UUID REFERENCES forum_threads(id) ON DELETE CASCADE,
  reply_id UUID REFERENCES forum_replies(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  read_at TIMESTAMP WITH TIME ZONE
);

-- Enable RLS for forum_mentions
ALTER TABLE forum_mentions ENABLE ROW LEVEL SECURITY;

-- Create policies for forum_mentions
CREATE POLICY "Users can view their own mentions" 
ON forum_mentions 
FOR SELECT 
USING (auth.uid() = mentioned_user_id);

CREATE POLICY "Users can create mentions" 
ON forum_mentions 
FOR INSERT 
WITH CHECK (auth.uid() = mentioner_user_id);

CREATE POLICY "Users can update their mention read status" 
ON forum_mentions 
FOR UPDATE 
USING (auth.uid() = mentioned_user_id);

-- Add function to update presence last_seen
CREATE OR REPLACE FUNCTION update_user_presence_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  NEW.last_seen = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for user_presence
DROP TRIGGER IF EXISTS update_user_presence_timestamp_trigger ON user_presence;
CREATE TRIGGER update_user_presence_timestamp_trigger
  BEFORE UPDATE ON user_presence
  FOR EACH ROW
  EXECUTE FUNCTION update_user_presence_timestamp();

-- Add realtime support
ALTER PUBLICATION supabase_realtime ADD TABLE user_presence;
ALTER PUBLICATION supabase_realtime ADD TABLE forum_mentions;
ALTER PUBLICATION supabase_realtime ADD TABLE user_warnings;