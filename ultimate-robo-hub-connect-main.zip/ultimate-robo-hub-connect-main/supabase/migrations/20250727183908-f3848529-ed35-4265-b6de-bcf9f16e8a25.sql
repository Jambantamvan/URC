-- Add start_time and end_time columns to attendances table
ALTER TABLE public.attendances 
ADD COLUMN start_time TIMESTAMP WITH TIME ZONE,
ADD COLUMN end_time TIMESTAMP WITH TIME ZONE;

-- Add index for time queries
CREATE INDEX idx_attendances_start_time ON public.attendances(start_time);
CREATE INDEX idx_attendances_end_time ON public.attendances(end_time);

-- Update existing records to have start_time and end_time based on date
UPDATE public.attendances 
SET 
  start_time = date,
  end_time = date + INTERVAL '2 hours'
WHERE start_time IS NULL;