-- Fix forum mentions table to support proper mention tracking
-- Ensure reply_id can be linked to forum_replies when mentions are in replies

-- Add proper indexes for performance
CREATE INDEX IF NOT EXISTS idx_forum_mentions_mentioned_user ON forum_mentions(mentioned_user_id);
CREATE INDEX IF NOT EXISTS idx_forum_mentions_thread ON forum_mentions(thread_id);
CREATE INDEX IF NOT EXISTS idx_forum_mentions_reply ON forum_mentions(reply_id);

-- Add updated_at trigger for profiles to ensure role changes are properly timestamped
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Add trigger to profiles table if it doesn't exist
DROP TRIGGER IF EXISTS update_profiles_updated_at ON profiles;
CREATE TRIGGER update_profiles_updated_at
    BEFORE UPDATE ON profiles
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Ensure all forum tables have proper RLS and are accessible
-- Update forum_mentions policies to be more permissive for authenticated users
DROP POLICY IF EXISTS "Users can create mentions" ON forum_mentions;
CREATE POLICY "Users can create mentions" 
ON forum_mentions FOR INSERT 
WITH CHECK (auth.uid() = mentioner_user_id);

-- Allow users to see mentions in threads they have access to
DROP POLICY IF EXISTS "Users can view mentions in accessible threads" ON forum_mentions;
CREATE POLICY "Users can view mentions in accessible threads"
ON forum_mentions FOR SELECT
USING (
  auth.uid() = mentioned_user_id OR 
  auth.uid() = mentioner_user_id OR
  EXISTS (
    SELECT 1 FROM forum_threads 
    WHERE forum_threads.id = forum_mentions.thread_id
  )
);