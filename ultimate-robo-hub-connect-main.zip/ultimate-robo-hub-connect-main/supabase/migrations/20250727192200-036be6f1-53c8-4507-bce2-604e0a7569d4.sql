-- Fix projects table - add missing division column
ALTER TABLE projects ADD COLUMN IF NOT EXISTS division TEXT;

-- Enable realtime for projects table
ALTER PUBLICATION supabase_realtime ADD TABLE projects;