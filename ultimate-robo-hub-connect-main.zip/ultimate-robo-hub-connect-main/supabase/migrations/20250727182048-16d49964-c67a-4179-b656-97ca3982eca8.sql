-- Security Enhancements

-- 1. Add missing RLS policies for 'id' table
CREATE POLICY "Only admins can access id table"
ON public.id
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'admin'
  )
);

-- 2. Create security logs table for audit trail
CREATE TABLE IF NOT EXISTS public.security_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  action TEXT NOT NULL,
  resource TEXT,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  metadata JSONB
);

-- Enable RLS on security_logs
ALTER TABLE public.security_logs ENABLE ROW LEVEL SECURITY;

-- Only admins can read security logs
CREATE POLICY "Admins can view security logs"
ON public.security_logs
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'admin'
  )
);

-- System can insert security logs
CREATE POLICY "System can insert security logs"
ON public.security_logs
FOR INSERT
TO authenticated
WITH CHECK (true);

-- 3. Create failed login attempts table
CREATE TABLE IF NOT EXISTS public.failed_login_attempts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL,
  ip_address INET,
  user_agent TEXT,
  attempted_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  reason TEXT
);

-- Enable RLS on failed_login_attempts
ALTER TABLE public.failed_login_attempts ENABLE ROW LEVEL SECURITY;

-- Only admins can view failed attempts
CREATE POLICY "Admins can view failed login attempts"
ON public.failed_login_attempts
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'admin'
  )
);

-- System can log failed attempts
CREATE POLICY "System can log failed attempts"
ON public.failed_login_attempts
FOR INSERT
TO authenticated
WITH CHECK (true);

-- 4. Add content validation triggers
CREATE OR REPLACE FUNCTION validate_content()
RETURNS TRIGGER AS $$
DECLARE
  suspicious_patterns TEXT[] := ARRAY[
    '<script', 'javascript:', 'onload=', 'onerror=', 'onclick=',
    'eval(', 'document.cookie', 'localStorage', 'sessionStorage',
    'DROP TABLE', 'DELETE FROM', 'TRUNCATE', 'ALTER TABLE',
    'CREATE TABLE', 'INSERT INTO', 'UPDATE SET'
  ];
  pattern TEXT;
  content_to_check TEXT;
BEGIN
  -- Check different content fields based on table
  IF TG_TABLE_NAME = 'forum_threads' THEN
    content_to_check := NEW.title || ' ' || NEW.content;
  ELSIF TG_TABLE_NAME = 'forum_replies' THEN
    content_to_check := NEW.content;
  ELSIF TG_TABLE_NAME = 'projects' THEN
    content_to_check := NEW.title || ' ' || COALESCE(NEW.description, '');
  ELSIF TG_TABLE_NAME = 'profiles' THEN
    content_to_check := COALESCE(NEW.name, '') || ' ' || COALESCE(NEW.bio, '');
  ELSE
    RETURN NEW;
  END IF;

  -- Check for suspicious patterns
  FOREACH pattern IN ARRAY suspicious_patterns
  LOOP
    IF LOWER(content_to_check) LIKE '%' || LOWER(pattern) || '%' THEN
      RAISE EXCEPTION 'Content contains potentially harmful code: %', pattern;
    END IF;
  END LOOP;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Apply content validation to relevant tables
DROP TRIGGER IF EXISTS validate_forum_content ON forum_threads;
CREATE TRIGGER validate_forum_content
  BEFORE INSERT OR UPDATE ON forum_threads
  FOR EACH ROW EXECUTE FUNCTION validate_content();

DROP TRIGGER IF EXISTS validate_reply_content ON forum_replies;
CREATE TRIGGER validate_reply_content
  BEFORE INSERT OR UPDATE ON forum_replies
  FOR EACH ROW EXECUTE FUNCTION validate_content();

DROP TRIGGER IF EXISTS validate_project_content ON projects;
CREATE TRIGGER validate_project_content
  BEFORE INSERT OR UPDATE ON projects
  FOR EACH ROW EXECUTE FUNCTION validate_content();

DROP TRIGGER IF EXISTS validate_profile_content ON profiles;
CREATE TRIGGER validate_profile_content
  BEFORE INSERT OR UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION validate_content();

-- 5. Rate limiting function
CREATE OR REPLACE FUNCTION check_rate_limit(
  user_id_param UUID,
  action_type TEXT,
  time_window INTERVAL DEFAULT '1 minute',
  max_attempts INTEGER DEFAULT 10
)
RETURNS BOOLEAN AS $$
DECLARE
  attempt_count INTEGER;
BEGIN
  SELECT COUNT(*)
  INTO attempt_count
  FROM security_logs
  WHERE user_id = user_id_param
    AND action = action_type
    AND created_at > (now() - time_window);

  IF attempt_count >= max_attempts THEN
    INSERT INTO security_logs (user_id, action, metadata)
    VALUES (user_id_param, 'RATE_LIMIT_EXCEEDED', 
           jsonb_build_object('action_type', action_type, 'attempts', attempt_count));
    RETURN FALSE;
  END IF;

  RETURN TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 6. Enhanced audit trigger
CREATE OR REPLACE FUNCTION audit_changes()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO security_logs (
    user_id,
    action,
    resource,
    metadata
  ) VALUES (
    auth.uid(),
    TG_OP,
    TG_TABLE_NAME || ':' || COALESCE(NEW.id::TEXT, OLD.id::TEXT),
    jsonb_build_object(
      'old', to_jsonb(OLD),
      'new', to_jsonb(NEW),
      'timestamp', now()
    )
  );
  
  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Apply audit triggers to sensitive tables
DROP TRIGGER IF EXISTS audit_profiles ON profiles;
CREATE TRIGGER audit_profiles
  AFTER INSERT OR UPDATE OR DELETE ON profiles
  FOR EACH ROW EXECUTE FUNCTION audit_changes();

DROP TRIGGER IF EXISTS audit_projects ON projects;
CREATE TRIGGER audit_projects
  AFTER INSERT OR UPDATE OR DELETE ON projects
  FOR EACH ROW EXECUTE FUNCTION audit_changes();

-- 7. Password policy enforcement for profiles
CREATE OR REPLACE FUNCTION enforce_data_policies()
RETURNS TRIGGER AS $$
BEGIN
  -- Email format validation
  IF NEW.email IS NOT NULL AND NEW.email !~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$' THEN
    RAISE EXCEPTION 'Invalid email format';
  END IF;

  -- Name length validation
  IF NEW.name IS NOT NULL AND (LENGTH(NEW.name) < 2 OR LENGTH(NEW.name) > 100) THEN
    RAISE EXCEPTION 'Name must be between 2 and 100 characters';
  END IF;

  -- Bio length validation
  IF NEW.bio IS NOT NULL AND LENGTH(NEW.bio) > 1000 THEN
    RAISE EXCEPTION 'Bio must be less than 1000 characters';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS enforce_profile_policies ON profiles;
CREATE TRIGGER enforce_profile_policies
  BEFORE INSERT OR UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION enforce_data_policies();