// Security utilities for input validation and sanitization
import DOMPurify from 'isomorphic-dompurify';

export class SecurityUtils {
  // XSS protection
  static sanitizeHTML(input: string): string {
    return DOMPurify.sanitize(input, {
      ALLOWED_TAGS: [],
      ALLOWED_ATTR: [],
      KEEP_CONTENT: true,
    });
  }

  // SQL injection protection for search queries
  static sanitizeSearchInput(input: string): string {
    return input
      .replace(/[^\\w\\s]/gi, '') // Remove special characters except whitespace
      .trim()
      .slice(0, 100); // Limit length
  }

  // Validate email format
  static isValidEmail(email: string): boolean {
    const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
    return emailRegex.test(email) && email.length <= 254;
  }

  // Password strength validation
  static validatePassword(password: string): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];
    
    if (password.length < 8) {
      errors.push('Password harus minimal 8 karakter');
    }
    
    if (password.length > 128) {
      errors.push('Password terlalu panjang (maksimal 128 karakter)');
    }
    
    if (!/[A-Z]/.test(password)) {
      errors.push('Password harus mengandung minimal 1 huruf besar');
    }
    
    if (!/[a-z]/.test(password)) {
      errors.push('Password harus mengandung minimal 1 huruf kecil');
    }
    
    if (!/\d/.test(password)) {
      errors.push('Password harus mengandung minimal 1 angka');
    }
    
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
      errors.push('Password harus mengandung minimal 1 karakter khusus');
    }
    
    // Check for common patterns
    const commonPatterns = [
      /(.)\1{2,}/, // repeated characters
      /123456|654321|abcdef|qwerty|password|admin/i, // common sequences
    ];
    
    for (const pattern of commonPatterns) {
      if (pattern.test(password)) {
        errors.push('Password terlalu mudah ditebak');
        break;
      }
    }
    
    return {
      isValid: errors.length === 0,
      errors
    };
  }

  // Rate limiting check (client-side)
  static checkClientRateLimit(key: string, maxAttempts: number = 5, windowMs: number = 60000): boolean {
    const now = Date.now();
    const attempts = JSON.parse(localStorage.getItem(`rate_limit_${key}`) || '[]');
    
    // Clean old attempts
    const validAttempts = attempts.filter((timestamp: number) => now - timestamp < windowMs);
    
    if (validAttempts.length >= maxAttempts) {
      return false;
    }
    
    validAttempts.push(now);
    localStorage.setItem(`rate_limit_${key}`, JSON.stringify(validAttempts));
    return true;
  }

  // Content validation
  static validateContent(content: string, type: 'text' | 'html' = 'text'): { isValid: boolean; sanitized: string; errors: string[] } {
    const errors: string[] = [];
    let sanitized = content;

    // Length validation
    if (content.length > 10000) {
      errors.push('Konten terlalu panjang (maksimal 10000 karakter)');
      sanitized = content.slice(0, 10000);
    }

    // Dangerous pattern detection
    const dangerousPatterns = [
      /<script[\s\S]*?<\/script>/gi,
      /javascript:/gi,
      /on\w+\s*=/gi,
      /eval\s*\(/gi,
      /document\.(cookie|write)/gi,
      /(INSERT|UPDATE|DELETE|DROP|CREATE|ALTER)\s+(INTO|TABLE|FROM)/gi,
    ];

    for (const pattern of dangerousPatterns) {
      if (pattern.test(content)) {
        errors.push('Konten mengandung kode berbahaya');
        sanitized = content.replace(pattern, '[BLOCKED_CONTENT]');
      }
    }

    // Sanitize based on type
    if (type === 'html') {
      sanitized = this.sanitizeHTML(sanitized);
    } else {
      sanitized = sanitized
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#x27;');
    }

    return {
      isValid: errors.length === 0,
      sanitized,
      errors
    };
  }

  // File upload validation
  static validateFile(file: File, allowedTypes: string[] = [], maxSize: number = 5 * 1024 * 1024): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    // Size validation
    if (file.size > maxSize) {
      errors.push(`File terlalu besar (maksimal ${Math.round(maxSize / 1024 / 1024)}MB)`);
    }

    // Type validation
    if (allowedTypes.length > 0 && !allowedTypes.includes(file.type)) {
      errors.push(`Tipe file tidak diizinkan. Hanya: ${allowedTypes.join(', ')}`);
    }

    // File name validation
    if (!/^[a-zA-Z0-9._-]+$/.test(file.name)) {
      errors.push('Nama file mengandung karakter tidak valid');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  // URL validation
  static isValidURL(url: string, allowedProtocols: string[] = ['http:', 'https:']): boolean {
    try {
      const urlObj = new URL(url);
      return allowedProtocols.includes(urlObj.protocol);
    } catch {
      return false;
    }
  }

  // Generate secure random string
  static generateSecureToken(length: number = 32): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    const cryptoObj = window.crypto || (window as any).msCrypto;
    
    if (cryptoObj && cryptoObj.getRandomValues) {
      const randomValues = new Uint8Array(length);
      cryptoObj.getRandomValues(randomValues);
      
      for (let i = 0; i < length; i++) {
        result += chars[randomValues[i] % chars.length];
      }
    } else {
      // Fallback for older browsers
      for (let i = 0; i < length; i++) {
        result += chars[Math.floor(Math.random() * chars.length)];
      }
    }
    
    return result;
  }

  // Log security events
  static logSecurityEvent(event: string, details: Record<string, any> = {}): void {
    const logEntry = {
      timestamp: new Date().toISOString(),
      event,
      details,
      userAgent: navigator.userAgent,
      url: window.location.href,
    };

    // Store locally for debugging
    const logs = JSON.parse(localStorage.getItem('security_logs') || '[]');
    logs.push(logEntry);
    
    // Keep only last 100 logs
    if (logs.length > 100) {
      logs.splice(0, logs.length - 100);
    }
    
    localStorage.setItem('security_logs', JSON.stringify(logs));

    // In production, send to security monitoring service
    console.warn('Security Event:', logEntry);
  }
}

export default SecurityUtils;
