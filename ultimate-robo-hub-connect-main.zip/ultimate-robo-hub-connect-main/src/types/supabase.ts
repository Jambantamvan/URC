
import { Database as DefaultDatabase } from '@/integrations/supabase/types';

export type UserRole = 'admin' | 'member' | 'non-member';

export interface Profile {
  id: string;
  name: string | null;
  email: string | null;
  role: UserRole;
  class: string | null;
  birth_date: string | null;
  division: string | null;
  skills: string[] | null;
  bio: string | null;
  photo_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface RegistrationRequest {
  id: string;
  user_id: string;
  name: string;
  birth_date: string;
  class: string;
  reason: string;
  skills_to_develop: string[];
  status: string;
  created_at: string;
  reviewed_at?: string | null;
  reviewed_by?: string | null;
}

// Don't extend the DefaultDatabase, instead use the type as is
export type Database = DefaultDatabase;

export interface AttendanceEvent {
  id: string;
  title: string;
  description: string | null;
  date: string;
  start_time?: string | null;
  end_time?: string | null;
  verification_code: string;
  created_by: string | null;
  created_at: string;
  creator_name?: string;
  attendance_count?: number;
  user_attended?: boolean;
}

export interface AttendanceRecord {
  id: string;
  attendance_id: string;
  user_id: string;
  status: 'present' | 'absent';
  reason?: string | null;
  created_at: string;
  user_name?: string;
}

export interface Project {
  id: string;
  title: string;
  description?: string | null;
  status: string;
  tags?: string[] | null;
  created_at: string;
  updated_at?: string;
  leader_id?: string | null;
  division?: string | null;
  github_url?: string | null;
  demo_url?: string | null;
  image_url?: string | null;
  leader_name?: string;
}
