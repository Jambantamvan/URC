
// Type definitions for the application

export interface User {
  id: string;
  name: string;
  class: string;
  division: string;
  skills: string[];
  bio: string;
  photoUrl?: string;
  projects: string[]; // IDs of projects
  competitions: string[]; // IDs of competitions
  createdAt: string;
  updatedAt: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  status: 'planning' | 'in-progress' | 'completed' | 'archived';
  tags: string[];
  members: string[]; // User IDs
  leader: string; // User ID
  media: Media[];
  createdAt: string;
  updatedAt: string;
  comments: Comment[];
  // Add properties to match supabase Project type
  created_at: string;
  github_url?: string | null;
  demo_url?: string | null;
  image_url?: string | null;
  leader_name?: string;
  division?: string | null;
}

export interface Comment {
  id: string;
  content: string;
  userId: string;
  userName: string;
  userPhotoUrl?: string;
  createdAt: string;
}

export interface Media {
  id: string;
  type: 'image' | 'video' | 'document';
  url: string;
  title: string;
  createdAt: string;
  creatorId: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  important: boolean;
  createdAt: string;
  createdBy: string;
  updatedAt: string;
}

export interface Event {
  id: string;
  title: string;
  description: string;
  location: string;
  startDate: string;
  endDate: string;
  attendees: Attendee[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface Attendee {
  userId: string;
  status: 'attending' | 'not-attending' | 'maybe';
  userName: string;
}

export interface LearningMaterial {
  id: string;
  title: string;
  description: string;
  type: 'video' | 'document' | 'link';
  level: 'beginner' | 'intermediate' | 'advanced';
  url: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface ForumThread {
  id: string;
  title: string;
  content: string;
  division: string | null;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  replies: ForumReply[];
}

export interface ForumReply {
  id: string;
  content: string;
  userId: string;
  userName: string;
  userPhotoUrl?: string;
  createdAt: string;
}

export interface CodeSnippet {
  id: string;
  title: string;
  code: string;
  language: 'python' | 'arduino' | 'c' | 'cpp';
  description: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  date: string;
  type: 'competition' | 'project' | 'other';
  participants: string[]; // User IDs
  media: Media[];
  createdBy: string;
  createdAt: string;
}
