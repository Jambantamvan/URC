import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import { AuthProvider } from './contexts/AuthContext';
import { Toaster } from './components/ui/sonner';

// Pages
import Index from './pages/Index';
import Auth from './pages/Auth';
import Registration from './pages/Registration';
import Profile from './pages/Profile';
import Calendar from './pages/Calendar';
import EnhancedForum from './pages/EnhancedForum';
import Learn from './pages/Learn';
import Gallery from './pages/Gallery';
import Projects from './pages/Projects';
import Playground from './pages/Playground';
import NotFound from './pages/NotFound';
import Attendance from './pages/Attendance';
import NewProject from './pages/Projects/New';
import EditProject from './pages/Projects/Edit';

// Admin Pages
import Dashboard from './pages/admin/Dashboard';
import Users from './pages/admin/Users';
import Registrations from './pages/admin/Registrations';
import AdminEventsPage from './pages/admin/Events';
import AdminMaterials from './pages/admin/Materials';
import AdminForumPage from './pages/admin/ForumAdmin';
import AdminProjects from './pages/admin/Projects';
import AdminAttendance from './pages/admin/Attendance';
import AdminWarnings from './pages/admin/Warnings';

function App() {
  return (
    <ThemeProvider>
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/registration" element={<Registration />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/profile/:id" element={<Profile />} />
            <Route path="/calendar" element={<Calendar />} />
            <Route path="/forum/*" element={<EnhancedForum />} />
            <Route path="/learn" element={<Learn />} />
            <Route path="/gallery" element={<Gallery />} />
            <Route path="/gallery/:id" element={<Gallery />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/projects/:id" element={<Projects />} />
            <Route path="/projects/new" element={<NewProject />} />
            <Route path="/projects/:id/edit" element={<EditProject />} />
            <Route path="/playground" element={<Playground />} />
            <Route path="/attendance" element={<Attendance />} />
            <Route path="/admin" element={<Dashboard />} />
            <Route path="/admin/users" element={<Users />} />
            <Route path="/admin/registrations" element={<Registrations />} />
            <Route path="/admin/warnings" element={<AdminWarnings />} />
            <Route path="/admin/events" element={<AdminEventsPage />} />
            <Route path="/admin/materials" element={<AdminMaterials />} />
            <Route path="/admin/forum" element={<AdminForumPage />} />
            <Route path="/admin/projects" element={<AdminProjects />} />
            <Route path="/admin/attendance" element={<AdminAttendance />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
      <Toaster />
    </ThemeProvider>
  );
}

export default App;
