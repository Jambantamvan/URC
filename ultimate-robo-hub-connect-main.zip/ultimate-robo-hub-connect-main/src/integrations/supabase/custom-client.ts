
import { createClient } from '@supabase/supabase-js';
import { Database } from '@/types/supabase';

const SUPABASE_URL = "https://nfpqouvxdqwqgmdloqde.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5mcHFvdXZ4ZHF3cWdtZGxvcWRlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU5ODkwMTYsImV4cCI6MjA2MTU2NTAxNn0.6gzc-IK0DWzbiXJYJFBTilerzGVRw5IyBJ26TIQLlXA";

// Import this client instead of the auto-generated one for properly typed tables
export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    storage: localStorage,
    persistSession: true,
    autoRefreshToken: true,
  }
});
