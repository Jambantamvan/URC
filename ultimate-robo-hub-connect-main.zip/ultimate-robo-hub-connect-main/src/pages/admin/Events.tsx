
import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import AdminSidebar from '@/components/Admin/AdminSidebar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { format, parseISO } from 'date-fns';
import { id } from 'date-fns/locale';
import { Calendar as CalendarIcon, Pencil, Trash } from 'lucide-react';

interface Event {
  id: string;
  title: string;
  description: string | null;
  location: string | null;
  start_date: string;
  end_date: string;
  created_by: string | null;
  created_at: string | null;
}

const AdminEventsPage = () => {
  const [events, setEvents] = useState<Event[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentEvent, setCurrentEvent] = useState<Event | null>(null);
  
  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [startDate, setStartDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endDate, setEndDate] = useState('');
  const [endTime, setEndTime] = useState('');
  
  useEffect(() => {
    fetchEvents();
  }, []);
  
  const fetchEvents = async () => {
    try {
      setIsLoading(true);
      
      const { data, error } = await supabase
        .from('events')
        .select('*')
        .order('start_date', { ascending: false });
      
      if (error) {
        throw error;
      }
      
      setEvents(data || []);
    } catch (error) {
      console.error('Error fetching events:', error);
      toast.error('Gagal memuat data kegiatan');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleOpenDialog = (event?: Event) => {
    if (event) {
      // Edit mode
      setIsEditing(true);
      setCurrentEvent(event);
      setTitle(event.title);
      setDescription(event.description || '');
      setLocation(event.location || '');
      
      // Format dates for the form
      const startDateTime = new Date(event.start_date);
      const endDateTime = new Date(event.end_date);
      
      setStartDate(format(startDateTime, 'yyyy-MM-dd'));
      setStartTime(format(startDateTime, 'HH:mm'));
      setEndDate(format(endDateTime, 'yyyy-MM-dd'));
      setEndTime(format(endDateTime, 'HH:mm'));
    } else {
      // Create mode
      setIsEditing(false);
      setCurrentEvent(null);
      setTitle('');
      setDescription('');
      setLocation('');
      
      // Default to today
      const today = new Date();
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      
      setStartDate(format(today, 'yyyy-MM-dd'));
      setStartTime('09:00');
      setEndDate(format(today, 'yyyy-MM-dd'));
      setEndTime('12:00');
    }
    
    setIsDialogOpen(true);
  };
  
  const resetForm = () => {
    setTitle('');
    setDescription('');
    setLocation('');
    setStartDate('');
    setStartTime('');
    setEndDate('');
    setEndTime('');
    setCurrentEvent(null);
    setIsEditing(false);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (!title || !startDate || !startTime || !endDate || !endTime) {
        toast.error('Mohon isi semua field yang diperlukan');
        return;
      }
      
      // Combine date and time
      const startDateTime = `${startDate}T${startTime}:00`;
      const endDateTime = `${endDate}T${endTime}:00`;
      
      if (new Date(endDateTime) <= new Date(startDateTime)) {
        toast.error('Waktu selesai harus setelah waktu mulai');
        return;
      }
      
      if (isEditing && currentEvent) {
        // Update existing event
        const { error } = await supabase
          .from('events')
          .update({
            title,
            description,
            location,
            start_date: startDateTime,
            end_date: endDateTime,
            updated_at: new Date().toISOString()
          })
          .eq('id', currentEvent.id);
        
        if (error) throw error;
        toast.success('Kegiatan berhasil diperbarui');
      } else {
        // Create new event
        const { error } = await supabase
          .from('events')
          .insert({
            title,
            description,
            location,
            start_date: startDateTime,
            end_date: endDateTime,
            created_by: (await supabase.auth.getUser()).data.user?.id || null
          });
        
        if (error) throw error;
        toast.success('Kegiatan berhasil ditambahkan');
      }
      
      // Close dialog and refresh events
      setIsDialogOpen(false);
      resetForm();
      fetchEvents();
      
    } catch (error) {
      console.error('Error saving event:', error);
      toast.error('Terjadi kesalahan saat menyimpan kegiatan');
    }
  };
  
  const handleDelete = async (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus kegiatan ini?')) {
      try {
        const { error } = await supabase
          .from('events')
          .delete()
          .eq('id', id);
        
        if (error) throw error;
        
        toast.success('Kegiatan berhasil dihapus');
        fetchEvents();
        
      } catch (error) {
        console.error('Error deleting event:', error);
        toast.error('Terjadi kesalahan saat menghapus kegiatan');
      }
    }
  };

  const formatDateTime = (dateTimeStr: string) => {
    try {
      const dateTime = parseISO(dateTimeStr);
      return format(dateTime, 'dd MMM yyyy, HH:mm', { locale: id });
    } catch (e) {
      return dateTimeStr;
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <AdminSidebar />
      
      <div className="ml-0 md:ml-64 p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Manajemen Kegiatan</h1>
            <p className="text-gray-600 dark:text-gray-400">Kelola kegiatan dan acara ekskul robotik</p>
          </div>
          
          <Button onClick={() => handleOpenDialog()} className="mt-4 md:mt-0">
            <CalendarIcon className="h-4 w-4 mr-2" /> Tambah Kegiatan
          </Button>
        </div>
        
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-14 bg-gray-200 dark:bg-gray-700 rounded-md animate-pulse" />
            ))}
          </div>
        ) : events.length === 0 ? (
          <div className="text-center p-12 bg-white dark:bg-gray-800 rounded-md shadow">
            <CalendarIcon className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <h2 className="text-xl font-medium mb-2">Belum ada kegiatan</h2>
            <p className="text-gray-500 mb-6">Mulai dengan menambahkan kegiatan baru</p>
            <Button onClick={() => handleOpenDialog()}>Tambah Kegiatan</Button>
          </div>
        ) : (
          <div className="bg-white dark:bg-gray-800 rounded-md shadow overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Judul</TableHead>
                  <TableHead>Waktu Mulai</TableHead>
                  <TableHead>Waktu Selesai</TableHead>
                  <TableHead>Lokasi</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {events.map((event) => (
                  <TableRow key={event.id}>
                    <TableCell className="font-medium">{event.title}</TableCell>
                    <TableCell>{formatDateTime(event.start_date)}</TableCell>
                    <TableCell>{formatDateTime(event.end_date)}</TableCell>
                    <TableCell>{event.location || '-'}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          onClick={() => handleOpenDialog(event)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          className="text-red-500 hover:text-red-600" 
                          onClick={() => handleDelete(event.id)}
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
      
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>
              {isEditing ? 'Edit Kegiatan' : 'Tambah Kegiatan Baru'}
            </DialogTitle>
            <DialogDescription>
              {isEditing 
                ? 'Ubah detail kegiatan yang ada' 
                : 'Isi detail kegiatan yang ingin ditambahkan'}
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div>
                <label htmlFor="title" className="block text-sm font-medium mb-1">
                  Judul <span className="text-red-500">*</span>
                </label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Masukkan judul kegiatan"
                  required
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="startDate" className="block text-sm font-medium mb-1">
                    Tanggal Mulai <span className="text-red-500">*</span>
                  </label>
                  <Input
                    id="startDate"
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="startTime" className="block text-sm font-medium mb-1">
                    Jam Mulai <span className="text-red-500">*</span>
                  </label>
                  <Input
                    id="startTime"
                    type="time"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    required
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="endDate" className="block text-sm font-medium mb-1">
                    Tanggal Selesai <span className="text-red-500">*</span>
                  </label>
                  <Input
                    id="endDate"
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="endTime" className="block text-sm font-medium mb-1">
                    Jam Selesai <span className="text-red-500">*</span>
                  </label>
                  <Input
                    id="endTime"
                    type="time"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    required
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="location" className="block text-sm font-medium mb-1">
                  Lokasi
                </label>
                <Input
                  id="location"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Masukkan lokasi kegiatan"
                />
              </div>
              
              <div>
                <label htmlFor="description" className="block text-sm font-medium mb-1">
                  Deskripsi
                </label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Masukkan deskripsi kegiatan"
                  rows={4}
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="secondary" 
                onClick={() => {
                  setIsDialogOpen(false);
                  resetForm();
                }}
              >
                Batal
              </Button>
              <Button type="submit">
                {isEditing ? 'Simpan Perubahan' : 'Tambah Kegiatan'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminEventsPage;
