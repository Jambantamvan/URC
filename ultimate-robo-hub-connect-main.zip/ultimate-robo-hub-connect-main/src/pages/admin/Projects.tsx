import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import AdminSidebar from '@/components/Admin/AdminSidebar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { format, parseISO } from 'date-fns';
import { id } from 'date-fns/locale';

interface Project {
  id: string;
  title: string;
  description: string | null;
  status: string;
  division: string | null;
  github_url: string | null;
  demo_url: string | null;
  image_url: string | null;
  leader_id: string | null;
  created_at: string;
  updated_at: string | null;
  leader_name?: string;
  tags?: string[] | null;
}

const AdminProjects = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  
  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState('planning');
  const [division, setDivision] = useState<string | null>(null);
  const [githubUrl, setGithubUrl] = useState('');
  const [demoUrl, setDemoUrl] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [leaderId, setLeaderId] = useState<string | null>(null);
  
  // Members state
  const [members, setMembers] = useState<any[]>([]);
  const [selectedMember, setSelectedMember] = useState<string | null>(null);
  
  useEffect(() => {
    fetchProjects();
    fetchMembers();
  }, []);
  
  const fetchProjects = async () => {
    try {
      setIsLoading(true);
      
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      if (data) {
        // Get leader names for each project
        const projectsWithLeaderNames = await Promise.all(data.map(async project => {
          let leaderName = 'Tidak ada leader';
          
          if (project.leader_id) {
            const { data: userData, error: userError } = await supabase
              .from('profiles')
              .select('name')
              .eq('id', project.leader_id)
              .single();
              
            if (!userError && userData) {
              leaderName = userData.name || 'Unknown';
            }
          }
          
          return {
            ...project,
            leader_name: leaderName
          };
        }));
        
        setProjects(projectsWithLeaderNames as Project[]);
      }
      
    } catch (error) {
      console.error('Error fetching projects:', error);
      toast.error('Gagal memuat data proyek');
    } finally {
      setIsLoading(false);
    }
  };
  
  const fetchMembers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, name')
        .eq('role', 'member')
        .order('name');
      
      if (error) throw error;
      
      if (data) {
        setMembers(data);
      }
    } catch (error) {
      console.error('Error fetching members:', error);
    }
  };
  
  const resetForm = () => {
    setTitle('');
    setDescription('');
    setStatus('planning');
    setDivision(null);
    setGithubUrl('');
    setDemoUrl('');
    setImageUrl('');
    setLeaderId(null);
  };
  
  const handleAddProject = async () => {
    try {
      if (!title || !description || !status) {
        toast.error('Judul, deskripsi, dan status wajib diisi');
        return;
      }
      
      const newProject = {
        title,
        description,
        status,
        division,
        github_url: githubUrl || null,
        demo_url: demoUrl || null,
        image_url: imageUrl || null,
        leader_id: leaderId
      };
      
      const { data, error } = await supabase
        .from('projects')
        .insert(newProject)
        .select();
      
      if (error) throw error;
      
      toast.success('Proyek berhasil ditambahkan');
      resetForm();
      setIsAddDialogOpen(false);
      fetchProjects();
      
    } catch (error) {
      console.error('Error adding project:', error);
      toast.error('Gagal menambahkan proyek');
    }
  };
  
  const handleEditProject = async () => {
    try {
      if (!currentProject) return;
      
      if (!title || !description || !status) {
        toast.error('Judul, deskripsi, dan status wajib diisi');
        return;
      }
      
      const updatedProject = {
        title,
        description,
        status,
        division,
        github_url: githubUrl || null,
        demo_url: demoUrl || null,
        image_url: imageUrl || null,
        leader_id: leaderId,
        updated_at: new Date().toISOString()
      };
      
      const { error } = await supabase
        .from('projects')
        .update(updatedProject)
        .eq('id', currentProject.id);
      
      if (error) throw error;
      
      toast.success('Proyek berhasil diperbarui');
      setIsEditDialogOpen(false);
      fetchProjects();
      
    } catch (error) {
      console.error('Error updating project:', error);
      toast.error('Gagal memperbarui proyek');
    }
  };
  
  const handleDeleteProject = async (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus proyek ini?')) {
      try {
        const { error } = await supabase
          .from('projects')
          .delete()
          .eq('id', id);
        
        if (error) throw error;
        
        toast.success('Proyek berhasil dihapus');
        fetchProjects();
        
      } catch (error) {
        console.error('Error deleting project:', error);
        toast.error('Gagal menghapus proyek');
      }
    }
  };
  
  const openEditDialog = (project: Project) => {
    setCurrentProject(project);
    setTitle(project.title);
    setDescription(project.description || '');
    setStatus(project.status);
    setDivision(project.division);
    setGithubUrl(project.github_url || '');
    setDemoUrl(project.demo_url || '');
    setImageUrl(project.image_url || '');
    setLeaderId(project.leader_id);
    setIsEditDialogOpen(true);
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'planning':
        return <Badge variant="outline" className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200">Perencanaan</Badge>;
      case 'in_progress':
        return <Badge variant="outline" className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200">Sedang Berjalan</Badge>;
      case 'completed':
        return <Badge variant="outline" className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">Selesai</Badge>;
      case 'on_hold':
        return <Badge variant="outline" className="bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200">Ditunda</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  const formatDate = (dateStr: string) => {
    try {
      const date = parseISO(dateStr);
      return format(date, 'dd MMM yyyy', { locale: id });
    } catch (e) {
      return dateStr;
    }
  };
  
  const filteredProjects = projects.filter(project => 
    project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (project.description && project.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (project.division && project.division.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (project.leader_name && project.leader_name.toLowerCase().includes(searchQuery.toLowerCase()))
  );
  
  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <AdminSidebar />
      
      <div className="ml-0 md:ml-64 p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Manajemen Proyek</h1>
            <p className="text-gray-600 dark:text-gray-400">Kelola proyek-proyek URC</p>
          </div>
          
          <div className="flex flex-col md:flex-row gap-4 mt-4 md:mt-0">
            <Input 
              placeholder="Cari proyek..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full md:w-64"
            />
            
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button>Tambah Proyek</Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Tambah Proyek Baru</DialogTitle>
                </DialogHeader>
                
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="title">Judul Proyek</label>
                      <Input
                        id="title"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        placeholder="Masukkan judul proyek"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label htmlFor="status">Status</label>
                      <Select value={status} onValueChange={setStatus}>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="planning">Perencanaan</SelectItem>
                          <SelectItem value="in_progress">Sedang Berjalan</SelectItem>
                          <SelectItem value="completed">Selesai</SelectItem>
                          <SelectItem value="on_hold">Ditunda</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="division">Divisi</label>
                      <Select value={division || ''} onValueChange={setDivision}>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih divisi" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">Tidak ada divisi</SelectItem>
                          <SelectItem value="web">Web Development</SelectItem>
                          <SelectItem value="mobile">Mobile Development</SelectItem>
                          <SelectItem value="ui_ux">UI/UX Design</SelectItem>
                          <SelectItem value="data">Data Science</SelectItem>
                          <SelectItem value="ai">Artificial Intelligence</SelectItem>
                          <SelectItem value="game">Game Development</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <label htmlFor="leader">Project Leader</label>
                      <Select value={leaderId || ''} onValueChange={setLeaderId}>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih leader" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">Tidak ada leader</SelectItem>
                          {members.map((member) => (
                            <SelectItem key={member.id} value={member.id}>
                              {member.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="description">Deskripsi</label>
                    <Textarea
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Masukkan deskripsi proyek"
                      rows={4}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="githubUrl">URL GitHub</label>
                      <Input
                        id="githubUrl"
                        value={githubUrl}
                        onChange={(e) => setGithubUrl(e.target.value)}
                        placeholder="https://github.com/username/repo"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label htmlFor="demoUrl">URL Demo</label>
                      <Input
                        id="demoUrl"
                        value={demoUrl}
                        onChange={(e) => setDemoUrl(e.target.value)}
                        placeholder="https://example.com"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="imageUrl">URL Gambar</label>
                    <Input
                      id="imageUrl"
                      value={imageUrl}
                      onChange={(e) => setImageUrl(e.target.value)}
                      placeholder="https://example.com/image.jpg"
                    />
                  </div>
                </div>
                
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                    Batal
                  </Button>
                  <Button onClick={handleAddProject}>
                    Tambah Proyek
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
        
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-14 bg-gray-200 dark:bg-gray-700 rounded-md animate-pulse" />
            ))}
          </div>
        ) : filteredProjects.length === 0 ? (
          <div className="text-center p-12 bg-white dark:bg-gray-800 rounded-md shadow">
            <h2 className="text-xl font-medium mb-2">Tidak ada proyek ditemukan</h2>
            <p className="text-gray-500">
              {projects.length === 0 
                ? 'Belum ada proyek yang ditambahkan' 
                : 'Tidak ada proyek yang sesuai dengan pencarian Anda'}
            </p>
          </div>
        ) : (
          <div className="bg-white dark:bg-gray-800 rounded-md shadow overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Judul</TableHead>
                  <TableHead>Divisi</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Leader</TableHead>
                  <TableHead>Dibuat Pada</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProjects.map((project) => (
                  <TableRow key={project.id}>
                    <TableCell className="font-medium">{project.title}</TableCell>
                    <TableCell>
                      {project.division ? (
                        <Badge variant="outline">{project.division}</Badge>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </TableCell>
                    <TableCell>{getStatusBadge(project.status)}</TableCell>
                    <TableCell>{project.leader_name}</TableCell>
                    <TableCell>{formatDate(project.created_at)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button 
                          size="sm" 
                          variant="outline" 
                          onClick={() => openEditDialog(project)}
                        >
                          Edit
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive" 
                          onClick={() => handleDeleteProject(project.id)}
                        >
                          Hapus
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
      
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Proyek</DialogTitle>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label htmlFor="edit-title">Judul Proyek</label>
                <Input
                  id="edit-title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Masukkan judul proyek"
                />
              </div>
              
              <div className="space-y-2">
                <label htmlFor="edit-status">Status</label>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="planning">Perencanaan</SelectItem>
                    <SelectItem value="in_progress">Sedang Berjalan</SelectItem>
                    <SelectItem value="completed">Selesai</SelectItem>
                    <SelectItem value="on_hold">Ditunda</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label htmlFor="edit-division">Divisi</label>
                <Select value={division || ''} onValueChange={setDivision}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih divisi" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Tidak ada divisi</SelectItem>
                    <SelectItem value="web">Web Development</SelectItem>
                    <SelectItem value="mobile">Mobile Development</SelectItem>
                    <SelectItem value="ui_ux">UI/UX Design</SelectItem>
                    <SelectItem value="data">Data Science</SelectItem>
                    <SelectItem value="ai">Artificial Intelligence</SelectItem>
                    <SelectItem value="game">Game Development</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <label htmlFor="edit-leader">Project Leader</label>
                <Select value={leaderId || ''} onValueChange={setLeaderId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih leader" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Tidak ada leader</SelectItem>
                    {members.map((member) => (
                      <SelectItem key={member.id} value={member.id}>
                        {member.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <label htmlFor="edit-description">Deskripsi</label>
              <Textarea
                id="edit-description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Masukkan deskripsi proyek"
                rows={4}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label htmlFor="edit-githubUrl">URL GitHub</label>
                <Input
                  id="edit-githubUrl"
                  value={githubUrl}
                  onChange={(e) => setGithubUrl(e.target.value)}
                  placeholder="https://github.com/username/repo"
                />
              </div>
              
              <div className="space-y-2">
                <label htmlFor="edit-demoUrl">URL Demo</label>
                <Input
                  id="edit-demoUrl"
                  value={demoUrl}
                  onChange={(e) => setDemoUrl(e.target.value)}
                  placeholder="https://example.com"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <label htmlFor="edit-imageUrl">URL Gambar</label>
              <Input
                id="edit-imageUrl"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://example.com/image.jpg"
              />
            </div>
          </div>
          
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Batal
            </Button>
            <Button onClick={handleEditProject}>
              Simpan Perubahan
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminProjects;
