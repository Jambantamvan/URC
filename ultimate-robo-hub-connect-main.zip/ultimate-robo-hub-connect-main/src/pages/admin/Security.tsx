import React from 'react';
import Navigation from '@/components/Navigation';
import SecurityDashboard from '@/components/Admin/SecurityDashboard';

const AdminSecurity = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-16 md:pt-0 md:ml-64">
        <SecurityDashboard />
      </div>
    </div>
  );
};

export default AdminSecurity;