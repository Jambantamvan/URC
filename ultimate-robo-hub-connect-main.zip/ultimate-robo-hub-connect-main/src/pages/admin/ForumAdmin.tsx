
import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import AdminSidebar from '@/components/Admin/AdminSidebar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { format, parseISO } from 'date-fns';
import { id } from 'date-fns/locale';
import { MessageSquare, Eye, Trash } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';

interface ForumThread {
  id: string;
  title: string;
  content: string;
  division: string | null;
  created_by: string | null;
  created_at: string | null;
  updated_at: string | null;
  reply_count?: number;
  author_name?: string;
}

const AdminForumPage = () => {
  const [threads, setThreads] = useState<ForumThread[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  
  useEffect(() => {
    fetchThreads();
  }, []);
  
  const fetchThreads = async () => {
    try {
      setIsLoading(true);
      
      // Get threads with author names via join
      const { data: threadsData, error } = await supabase
        .from('forum_threads')
        .select('*');
      
      if (error) throw error;
      
      if (threadsData) {
        // Get reply counts and author names for each thread
        const threadsWithCounts = await Promise.all(threadsData.map(async (thread) => {
          // Get reply count
          const { count, error: countError } = await supabase
            .from('forum_replies')
            .select('*', { count: 'exact', head: true })
            .eq('thread_id', thread.id);
          
          // Get author name if created_by is present
          let authorName = 'Unknown';
          if (thread.created_by) {
            const { data: userData, error: userError } = await supabase
              .from('profiles')
              .select('name')
              .eq('id', thread.created_by)
              .single();
              
            if (!userError && userData) {
              authorName = userData.name || 'Unknown';
            }
          }
          
          return {
            ...thread,
            author_name: authorName,
            reply_count: count || 0
          };
        }));
        
        setThreads(threadsWithCounts);
      }
    } catch (error) {
      console.error('Error fetching threads:', error);
      toast.error('Gagal memuat data forum');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleDelete = async (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus thread ini? Semua balasan juga akan dihapus.')) {
      try {
        const { error } = await supabase
          .from('forum_threads')
          .delete()
          .eq('id', id);
        
        if (error) throw error;
        
        toast.success('Thread berhasil dihapus');
        fetchThreads();
        
      } catch (error) {
        console.error('Error deleting thread:', error);
        toast.error('Terjadi kesalahan saat menghapus thread');
      }
    }
  };
  
  const handleViewThread = (id: string) => {
    navigate(`/forum/${id}`);
  };
  
  const filteredThreads = threads.filter(thread => 
    thread.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    thread.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (thread.division && thread.division.toLowerCase().includes(searchQuery.toLowerCase()))
  );
  
  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return '-';
    try {
      const date = parseISO(dateStr);
      return format(date, 'dd MMM yyyy, HH:mm', { locale: id });
    } catch (e) {
      return dateStr;
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <AdminSidebar />
      
      <div className="ml-0 md:ml-64 p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Manajemen Forum</h1>
            <p className="text-gray-600 dark:text-gray-400">Kelola thread diskusi di forum</p>
          </div>
          
          <div className="mt-4 md:mt-0 w-full md:w-64">
            <Input 
              placeholder="Cari thread..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-14 bg-gray-200 dark:bg-gray-700 rounded-md animate-pulse" />
            ))}
          </div>
        ) : filteredThreads.length === 0 ? (
          <div className="text-center p-12 bg-white dark:bg-gray-800 rounded-md shadow">
            <MessageSquare className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <h2 className="text-xl font-medium mb-2">Tidak ada thread ditemukan</h2>
            <p className="text-gray-500">
              {threads.length === 0 
                ? 'Belum ada thread diskusi di forum' 
                : 'Tidak ada thread yang sesuai dengan pencarian Anda'}
            </p>
          </div>
        ) : (
          <div className="bg-white dark:bg-gray-800 rounded-md shadow overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Judul</TableHead>
                  <TableHead>Divisi</TableHead>
                  <TableHead>Pembuat</TableHead>
                  <TableHead>Dibuat Pada</TableHead>
                  <TableHead>Balasan</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredThreads.map((thread) => (
                  <TableRow key={thread.id}>
                    <TableCell className="font-medium">{thread.title}</TableCell>
                    <TableCell>
                      {thread.division ? (
                        <Badge variant="outline">{thread.division}</Badge>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </TableCell>
                    <TableCell>{thread.author_name}</TableCell>
                    <TableCell>{formatDate(thread.created_at)}</TableCell>
                    <TableCell>{thread.reply_count}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          onClick={() => handleViewThread(thread.id)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          className="text-red-500 hover:text-red-600" 
                          onClick={() => handleDelete(thread.id)}
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminForumPage;
