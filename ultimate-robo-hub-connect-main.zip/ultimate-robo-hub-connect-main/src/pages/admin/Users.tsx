
import React from 'react';
import AdminSidebar from '@/components/Admin/AdminSidebar';
import UsersTable from '@/components/Admin/UsersTable';

const AdminUsers = () => {
  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <AdminSidebar />
      
      <div className="flex-1 ml-64 p-8">
        <h1 className="text-2xl font-bold mb-6">User Management</h1>
        
        <p className="mb-4 text-gray-600 dark:text-gray-400">
          Manage users and their roles within the application.
        </p>
        
        <UsersTable />
      </div>
    </div>
  );
};

export default AdminUsers;
