
import React from 'react';
import AdminSidebar from '@/components/Admin/AdminSidebar';
import RegistrationsTable from '@/components/Admin/RegistrationsTable';

const AdminRegistrations = () => {
  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <AdminSidebar />
      
      <div className="flex-1 ml-64 p-8">
        <h1 className="text-2xl font-bold mb-6">Pendaftaran Anggota</h1>
        
        <p className="mb-4 text-gray-600 dark:text-gray-400">
          Kelola pendaftaran anggota baru klub robotik.
        </p>
        
        <RegistrationsTable />
      </div>
    </div>
  );
};

export default AdminRegistrations;
