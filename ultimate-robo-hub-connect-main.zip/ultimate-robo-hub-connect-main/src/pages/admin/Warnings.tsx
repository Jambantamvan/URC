import React from 'react';
import AdminSidebar from '@/components/Admin/AdminSidebar';
import { UserWarningsManager } from '@/components/Admin/UserWarnings';

const AdminWarnings = () => {
  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <AdminSidebar />
      
      <div className="flex-1 ml-64 p-8">
        <UserWarningsManager />
      </div>
    </div>
  );
};

export default AdminWarnings;