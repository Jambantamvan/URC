import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import AdminSidebar from '@/components/Admin/AdminSidebar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { format, parseISO } from 'date-fns';
import { id } from 'date-fns/locale';
import { Calendar, Clock, CheckCircle, XCircle, Users } from 'lucide-react';
import { AttendanceEvent, AttendanceRecord, Profile } from '@/types/supabase';

interface Member {
  id: string;
  name: string;
  email: string;
  active_count?: number;
  inactive_count?: number;
}

const AttendanceAdmin = () => {
  const [attendances, setAttendances] = useState<AttendanceEvent[]>([]);
  const [activeMembers, setActiveMembers] = useState<Member[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isStatsDialogOpen, setIsStatsDialogOpen] = useState(false);
  const [currentAttendance, setCurrentAttendance] = useState<AttendanceEvent | null>(null);
  const [viewMode, setViewMode] = useState<'list' | 'activity'>('list');
  
  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  
  useEffect(() => {
    if (viewMode === 'list') {
      fetchAttendances();
    } else {
      fetchMembersActivity();
    }
  }, [viewMode]);
  
  const fetchAttendances = async () => {
    try {
      setIsLoading(true);
      
      const { data, error } = await supabase
        .from('attendances')
        .select('*')
        .order('date', { ascending: false });
      
      if (error) throw error;
      
      if (data) {
        // Get creator names and attendance counts
        const attendancesWithDetails = await Promise.all(data.map(async (attendance) => {
          let creatorName = 'Unknown';
          let attendanceCount = 0;
          
          // Get creator name
          if (attendance.created_by) {
            const { data: userData, error: userError } = await supabase
              .from('profiles')
              .select('name')
              .eq('id', attendance.created_by)
              .single();
              
            if (!userError && userData) {
              creatorName = userData.name || 'Unknown';
            }
          }
          
          // Get attendance count
          const { count, error: countError } = await supabase
            .from('attendance_records')
            .select('*', { count: 'exact', head: true })
            .eq('attendance_id', attendance.id)
            .eq('status', 'present');
            
          if (!countError) {
            attendanceCount = count || 0;
          }
          
          return {
            ...attendance,
            creator_name: creatorName,
            attendance_count: attendanceCount
          } as AttendanceEvent;
        }));
        
        setAttendances(attendancesWithDetails);
      }
      
    } catch (error) {
      console.error('Error fetching attendances:', error);
      toast.error('Gagal memuat data absensi');
    } finally {
      setIsLoading(false);
    }
  };
  
  const fetchMembersActivity = async () => {
    try {
      setIsLoading(true);
      
      // Get all members
      const { data: members, error: memberError } = await supabase
        .from('profiles')
        .select('id, name, email')
        .eq('role', 'member');
      
      if (memberError) throw memberError;
      
      if (members) {
        // Get activity stats for each member
        const membersWithActivity = await Promise.all(members.map(async (member) => {
          // Get present count
          const { count: activeCount, error: activeError } = await supabase
            .from('attendance_records')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', member.id)
            .eq('status', 'present');
            
          // Get absent count
          const { count: inactiveCount, error: inactiveError } = await supabase
            .from('attendance_records')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', member.id)
            .eq('status', 'absent');
            
          return {
            ...member,
            active_count: activeCount || 0,
            inactive_count: inactiveCount || 0
          };
        }));
        
        // Sort by activity (most active first)
        membersWithActivity.sort((a, b) => 
          (b.active_count || 0) - (a.active_count || 0)
        );
        
        setActiveMembers(membersWithActivity);
      }
      
    } catch (error) {
      console.error('Error fetching member activity:', error);
      toast.error('Gagal memuat data aktivitas anggota');
    } finally {
      setIsLoading(false);
    }
  };
  
  const generateVerificationCode = () => {
    const characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    setVerificationCode(result);
  };
  
  const resetForm = () => {
    setTitle('');
    setDescription('');
    setDate('');
    setVerificationCode('');
  };
  
  const handleAddAttendance = async () => {
    try {
      if (!title || !date || !verificationCode) {
        toast.error('Judul, tanggal, dan kode verifikasi wajib diisi');
        return;
      }
      
      // Get current user
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Anda harus login untuk menambahkan absensi');
        return;
      }
      
      const newAttendance = {
        title,
        description,
        date,
        verification_code: verificationCode,
        created_by: session.user.id
      };
      
      const { data, error } = await supabase
        .from('attendances')
        .insert(newAttendance)
        .select();
      
      if (error) throw error;
      
      toast.success('Absensi berhasil ditambahkan');
      resetForm();
      setIsAddDialogOpen(false);
      fetchAttendances();
      
    } catch (error) {
      console.error('Error adding attendance:', error);
      toast.error('Gagal menambahkan absensi');
    }
  };
  
  const handleDeleteAttendance = async (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus absensi ini?')) {
      try {
        // First delete all attendance records
        const { error: recordsError } = await supabase
          .from('attendance_records')
          .delete()
          .eq('attendance_id', id);
        
        if (recordsError) throw recordsError;
        
        // Then delete the attendance
        const { error } = await supabase
          .from('attendances')
          .delete()
          .eq('id', id);
        
        if (error) throw error;
        
        toast.success('Absensi berhasil dihapus');
        fetchAttendances();
        
      } catch (error) {
        console.error('Error deleting attendance:', error);
        toast.error('Gagal menghapus absensi');
      }
    }
  };
  
  const handleViewAttendanceStats = async (attendance: AttendanceEvent) => {
    setCurrentAttendance(attendance);
    setIsStatsDialogOpen(true);
    
    // Could fetch attendance records for this specific attendance here
  };
  
  const formatDate = (dateStr: string) => {
    try {
      const date = parseISO(dateStr);
      return format(date, 'dd MMM yyyy', { locale: id });
    } catch (e) {
      return dateStr;
    }
  };
  
  const filteredAttendances = attendances.filter(attendance => 
    attendance.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (attendance.description && attendance.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
    formatDate(attendance.date).toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const filteredMembers = activeMembers.filter(member => 
    member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.email.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <AdminSidebar />
      
      <div className="ml-0 md:ml-64 p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Kehadiran & Aktivitas</h1>
            <p className="text-gray-600 dark:text-gray-400">Kelola absensi dan pantau keaktifan anggota</p>
          </div>
          
          <div className="flex gap-4 mt-4 md:mt-0">
            <Select
              value={viewMode}
              onValueChange={(value) => setViewMode(value as 'list' | 'activity')}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Pilih tampilan" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="list">Daftar Absensi</SelectItem>
                <SelectItem value="activity">Keaktifan Anggota</SelectItem>
              </SelectContent>
            </Select>
            
            <Input 
              placeholder="Cari..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full md:w-64"
            />
            
            {viewMode === 'list' && (
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button>Tambah Absensi</Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Tambah Absensi Baru</DialogTitle>
                  </DialogHeader>
                  
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label htmlFor="title">Judul Kegiatan</label>
                        <Input
                          id="title"
                          value={title}
                          onChange={(e) => setTitle(e.target.value)}
                          placeholder="Masukkan judul kegiatan"
                          required
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <label htmlFor="date">Tanggal</label>
                        <Input
                          id="date"
                          type="datetime-local"
                          value={date}
                          onChange={(e) => setDate(e.target.value)}
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <label htmlFor="description">Deskripsi</label>
                      <Textarea
                        id="description"
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        placeholder="Masukkan deskripsi kegiatan"
                        rows={3}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label htmlFor="verificationCode">Kode Verifikasi</label>
                        <Button 
                          type="button" 
                          variant="outline" 
                          size="sm"
                          onClick={generateVerificationCode}
                        >
                          Generate Kode
                        </Button>
                      </div>
                      <Input
                        id="verificationCode"
                        value={verificationCode}
                        onChange={(e) => setVerificationCode(e.target.value.toUpperCase())}
                        placeholder="Masukkan kode verifikasi"
                        maxLength={6}
                        className="text-center text-lg tracking-widest uppercase font-bold"
                        required
                      />
                      <p className="text-sm text-gray-500">
                        Kode verifikasi akan digunakan anggota untuk absensi
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                      Batal
                    </Button>
                    <Button onClick={handleAddAttendance}>
                      Buat Absensi
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            )}
          </div>
        </div>
        
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-14 bg-gray-200 dark:bg-gray-700 rounded-md animate-pulse" />
            ))}
          </div>
        ) : viewMode === 'list' ? (
          <>
            {filteredAttendances.length === 0 ? (
              <div className="text-center p-12 bg-white dark:bg-gray-800 rounded-md shadow">
                <h2 className="text-xl font-medium mb-2">Tidak ada data absensi</h2>
                <p className="text-gray-500">
                  {attendances.length === 0 
                    ? 'Belum ada absensi yang ditambahkan' 
                    : 'Tidak ada absensi yang sesuai dengan pencarian Anda'}
                </p>
              </div>
            ) : (
              <div className="bg-white dark:bg-gray-800 rounded-md shadow overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Judul Kegiatan</TableHead>
                      <TableHead>Tanggal</TableHead>
                      <TableHead>Kode Verifikasi</TableHead>
                      <TableHead>Kehadiran</TableHead>
                      <TableHead>Dibuat Oleh</TableHead>
                      <TableHead className="text-right">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAttendances.map((attendance) => (
                      <TableRow key={attendance.id}>
                        <TableCell className="font-medium">{attendance.title}</TableCell>
                        <TableCell>{formatDate(attendance.date)}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="font-mono">
                            {attendance.verification_code}
                          </Badge>
                        </TableCell>
                        <TableCell>{attendance.attendance_count} hadir</TableCell>
                        <TableCell>{attendance.creator_name}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => handleViewAttendanceStats(attendance)}
                            >
                              Detail
                            </Button>
                            <Button 
                              size="sm" 
                              variant="destructive"
                              onClick={() => handleDeleteAttendance(attendance.id)}
                            >
                              Hapus
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </>
        ) : (
          <>
            {filteredMembers.length === 0 ? (
              <div className="text-center p-12 bg-white dark:bg-gray-800 rounded-md shadow">
                <h2 className="text-xl font-medium mb-2">Tidak ada data anggota</h2>
                <p className="text-gray-500">
                  {activeMembers.length === 0 
                    ? 'Belum ada anggota yang terdaftar' 
                    : 'Tidak ada anggota yang sesuai dengan pencarian Anda'}
                </p>
              </div>
            ) : (
              <div className="bg-white dark:bg-gray-800 rounded-md shadow overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nama Anggota</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Kehadiran</TableHead>
                      <TableHead>Ketidakhadiran</TableHead>
                      <TableHead>Persentase Keaktifan</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredMembers.map((member) => {
                      const totalAttendances = (member.active_count || 0) + (member.inactive_count || 0);
                      const activityPercentage = totalAttendances > 0 
                        ? ((member.active_count || 0) / totalAttendances) * 100 
                        : 0;
                        
                      return (
                        <TableRow key={member.id}>
                          <TableCell className="font-medium">{member.name}</TableCell>
                          <TableCell>{member.email}</TableCell>
                          <TableCell>{member.active_count || 0} kali</TableCell>
                          <TableCell>{member.inactive_count || 0} kali</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                                <div className={`h-2.5 rounded-full ${
                                  activityPercentage >= 75 ? 'bg-green-500' :
                                  activityPercentage >= 50 ? 'bg-yellow-500' :
                                  'bg-red-500'
                                }`} style={{ width: `${activityPercentage}%` }}></div>
                              </div>
                              <span>{activityPercentage.toFixed(0)}%</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge 
                              variant="outline" 
                              className={`${
                                activityPercentage >= 75 ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' :
                                activityPercentage >= 50 ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300' :
                                'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
                              }`}
                            >
                              {activityPercentage >= 75 ? 'Aktif' :
                               activityPercentage >= 50 ? 'Cukup Aktif' :
                               'Kurang Aktif'}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </>
        )}
      </div>
      
      {/* Attendance Stats Dialog */}
      <Dialog open={isStatsDialogOpen} onOpenChange={setIsStatsDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Detail Absensi: {currentAttendance?.title}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-gray-600">
                <Calendar className="h-4 w-4" />
                <span>{currentAttendance ? formatDate(currentAttendance.date) : ''}</span>
              </div>
              <Badge variant="outline" className="font-mono">
                Kode: {currentAttendance?.verification_code}
              </Badge>
            </div>
            
            <p className="text-gray-600 dark:text-gray-400">
              {currentAttendance?.description || 'Tidak ada deskripsi'}
            </p>
            
            <div className="border-t pt-4">
              <h3 className="font-medium mb-3">Statistik Kehadiran</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="bg-green-50 dark:bg-green-900/30 p-4 rounded-lg">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Hadir</p>
                      <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                        {currentAttendance?.attendance_count || 0}
                      </p>
                    </div>
                    <CheckCircle className="h-6 w-6 text-green-500" />
                  </div>
                </div>
                
                <div className="bg-red-50 dark:bg-red-900/30 p-4 rounded-lg">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Tidak Hadir</p>
                      <p className="text-2xl font-bold text-red-600 dark:text-red-400">
                        0
                      </p>
                    </div>
                    <XCircle className="h-6 w-6 text-red-500" />
                  </div>
                </div>
                
                <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-lg">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Total Anggota</p>
                      <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                        {/* Number would be fetched from actual data */}
                        {(currentAttendance?.attendance_count || 0) + 0}
                      </p>
                    </div>
                    <Users className="h-6 w-6 text-blue-500" />
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-2">Daftar Kehadiran</h4>
                <p className="text-sm text-gray-500">
                  Detail kehadiran akan ditampilkan di sini
                </p>
                {/* This would be implemented with a database query to show attendance details */}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AttendanceAdmin;
