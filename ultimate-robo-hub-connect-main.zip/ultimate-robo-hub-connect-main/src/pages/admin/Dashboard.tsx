
import React, { useEffect, useState } from 'react';
import AdminSidebar from '@/components/Admin/AdminSidebar';
import { supabase } from '@/integrations/supabase/custom-client';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Info, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

const AdminDashboard = () => {
  const [totalUsers, setTotalUsers] = useState<number>(0);
  const [totalMembers, setTotalMembers] = useState<number>(0);
  const [pendingRegistrations, setPendingRegistrations] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(true);
  const { profile } = useAuth();
  const navigate = useNavigate();

  // Redirect if not admin
  useEffect(() => {
    if (profile && profile.role !== 'admin') {
      toast.error('Anda tidak memiliki akses ke halaman admin');
      navigate('/');
    }
  }, [profile, navigate]);

  useEffect(() => {
    async function fetchStats() {
      try {
        console.log("Fetching dashboard stats...");
        // Fetch total users
        const { count: usersCount, error: usersError } = await supabase
          .from('profiles')
          .select('*', { count: 'exact', head: true });

        // Fetch members
        const { count: membersCount, error: membersError } = await supabase
          .from('profiles')
          .select('*', { count: 'exact', head: true })
          .eq('role', 'member');

        // Fetch pending registrations
        const { count: pendingCount, error: pendingError } = await supabase
          .from('registration_requests')
          .select('*', { count: 'exact', head: true })
          .eq('status', 'pending');

        if (usersError) {
          console.error("Error fetching users:", usersError);
          throw usersError;
        }
        if (membersError) {
          console.error("Error fetching members:", membersError);
          throw membersError;
        }
        if (pendingError) {
          console.error("Error fetching pending registrations:", pendingError);
          throw pendingError;
        }

        console.log("Stats fetched:", { 
          usersCount, 
          membersCount, 
          pendingCount 
        });
        
        setTotalUsers(usersCount || 0);
        setTotalMembers(membersCount || 0);
        setPendingRegistrations(pendingCount || 0);
      } catch (error) {
        console.error('Error fetching stats:', error);
      } finally {
        setIsLoading(false);
      }
    }

    fetchStats();
  }, []);

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <AdminSidebar />
      
      <div className="flex-1 ml-64 p-8">
        <h1 className="text-2xl font-bold mb-6">Admin Dashboard</h1>
        
        <Alert className="mb-6 border-blue-200 bg-blue-50 dark:border-blue-900 dark:bg-blue-950">
          <Info className="h-4 w-4" />
          <AlertTitle>Panduan Admin</AlertTitle>
          <AlertDescription>
            <p className="mb-2">Sebagai admin, Anda dapat:</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Melihat dan mengelola semua user di menu <strong>Users</strong></li>
              <li>Mengubah peran user menjadi Admin, Member, atau Non-Member dari menu <strong>Users</strong></li>
              <li>Menerima atau menolak pendaftaran anggota baru di menu <strong>Pendaftaran</strong></li>
            </ul>
          </AlertDescription>
        </Alert>
        
        {isLoading ? (
          <div className="flex justify-center items-center p-8">
            <Loader2 className="h-8 w-8 animate-spin text-robo-blue" />
            <span className="ml-2">Memuat data...</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-medium">Total Users</h2>
                <span className="text-2xl font-bold text-robo-blue">
                  {totalUsers}
                </span>
              </div>
            </div>
            
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-medium">Members</h2>
                <span className="text-2xl font-bold text-robo-blue">
                  {totalMembers}
                </span>
              </div>
            </div>
            
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-medium">Pending Registrations</h2>
                <span className="text-2xl font-bold text-robo-blue">
                  {pendingRegistrations}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
