
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/custom-client';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Info, ShieldAlert, CheckCircle, ArrowRight } from 'lucide-react';

const SetupAdmin = () => {
  const { user, profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [adminExists, setAdminExists] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    async function checkAdminExists() {
      try {
        console.log("Checking if admin exists...");
        const { count, error } = await supabase
          .from('profiles')
          .select('*', { count: 'exact', head: true })
          .eq('role', 'admin');
        
        if (error) {
          console.error("Error checking admin:", error);
          throw error;
        }
        
        console.log("Admin check result:", count);
        setAdminExists(!!count && count > 0);
      } catch (error) {
        console.error('Error checking admin existence:', error);
        toast.error('Gagal memeriksa keberadaan admin');
      } finally {
        setChecking(false);
      }
    }

    checkAdminExists();
  }, []);

  const becomeAdmin = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      // Check if we still don't have an admin
      const { count, error: checkError } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .eq('role', 'admin');
      
      if (checkError) {
        console.error("Error checking admin count:", checkError);
        throw checkError;
      }
      
      console.log("Admin count before update:", count);
      
      // Only proceed if there are no admins
      if (count === 0) {
        console.log("No admin exists, setting current user as admin");
        const { error } = await supabase
          .from('profiles')
          .update({ role: 'admin' })
          .eq('id', user.id);
        
        if (error) {
          console.error("Error updating profile:", error);
          throw error;
        }
        
        console.log("Admin role set successfully");
        toast.success('Anda sekarang menjadi Admin!');
        await refreshProfile();
        navigate('/admin');
      } else {
        setAdminExists(true);
        toast.error('Admin sudah ada di sistem');
      }
    } catch (error) {
      console.error('Error becoming admin:', error);
      toast.error('Gagal menjadi admin');
    } finally {
      setLoading(false);
    }
  };

  // Buat akun email kykoenak@gmail.com menjadi admin secara langsung
  const makeSpecificUserAdmin = async () => {
    setLoading(true);
    try {
      console.log("Setting kykoenak@gmail.com as admin");
      const { data: userData, error: userError } = await supabase
        .from('profiles')
        .select('id')
        .eq('email', 'kykoenak@gmail.com')
        .maybeSingle();
        
      if (userError) {
        console.error("Error finding user:", userError);
        throw userError;
      }
      
      if (!userData) {
        toast.error('User dengan email kykoenak@gmail.com tidak ditemukan');
        return;
      }
      
      console.log("Found user:", userData);
      
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ role: 'admin' })
        .eq('id', userData.id);
        
      if (updateError) {
        console.error("Error updating role:", updateError);
        throw updateError;
      }
      
      toast.success('User kykoenak@gmail.com sekarang menjadi Admin!');
      await refreshProfile();
      
      if (user?.email === 'kykoenak@gmail.com') {
        navigate('/admin');
      }
    } catch (error) {
      console.error('Error making user admin:', error);
      toast.error('Gagal membuat user menjadi admin');
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-900 p-4">
        <Card className="max-w-md w-full">
          <CardHeader>
            <CardTitle>Setup Admin</CardTitle>
            <CardDescription>
              Anda harus login terlebih dahulu
            </CardDescription>
          </CardHeader>
          <CardFooter>
            <Button className="w-full" onClick={() => navigate('/auth')}>
              Login
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-900 p-4">
      <Card className="max-w-md w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldAlert className="h-5 w-5" />
            Setup Admin
          </CardTitle>
          <CardDescription>
            Halaman ini memungkinkan setup admin pertama di sistem
          </CardDescription>
        </CardHeader>
        <CardContent>
          {checking ? (
            <div className="text-center p-4">Memeriksa status admin...</div>
          ) : (
            <>
              <Alert className="mb-4 border-blue-200 bg-blue-50 dark:border-blue-900 dark:bg-blue-950">
                <Info className="h-4 w-4" />
                <AlertTitle>Status Admin</AlertTitle>
                <AlertDescription>
                  {adminExists ? (
                    <p>Sistem sudah memiliki setidaknya satu akun admin.</p>
                  ) : (
                    <p>Sistem belum memiliki admin. User pertama yang mengklik tombol di bawah akan menjadi admin.</p>
                  )}
                </AlertDescription>
              </Alert>
              
              <div className="p-4 border rounded-md mb-4">
                <p className="font-medium mb-2">User saat ini:</p>
                <p>{profile?.name || user.email}</p>
                <p className="text-sm text-gray-500">Role: {profile?.role || 'non-member'}</p>
              </div>

              {user.email === 'kykoenak@gmail.com' && (
                <Alert className="mb-4 border-green-200 bg-green-50 dark:border-green-900 dark:bg-green-950">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertTitle>Pengguna Khusus Terdeteksi</AlertTitle>
                  <AlertDescription>
                    Akun Anda (kykoenak@gmail.com) dapat dijadikan admin dengan klik tombol khusus di bawah.
                  </AlertDescription>
                </Alert>
              )}
            </>
          )}
        </CardContent>
        <CardFooter className="flex flex-col gap-3">
          {!checking && !adminExists && (
            <Button 
              className="w-full" 
              onClick={becomeAdmin} 
              disabled={loading}
            >
              {loading ? 'Processing...' : 'Jadikan Saya Admin'}
              {!loading && <ArrowRight className="ml-2 h-4 w-4" />}
            </Button>
          )}
          
          {user.email === 'kykoenak@gmail.com' && (
            <Button 
              className="w-full bg-green-600 hover:bg-green-700" 
              onClick={makeSpecificUserAdmin}
              disabled={loading}
            >
              {loading ? 'Processing...' : 'Jadikan kykoenak@gmail.com Admin'}
              {!loading && <CheckCircle className="ml-2 h-4 w-4" />}
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
};

export default SetupAdmin;
