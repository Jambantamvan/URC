
import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import AdminSidebar from '@/components/Admin/AdminSidebar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { format, parseISO } from 'date-fns';
import { id } from 'date-fns/locale';
import { 
  Link, 
  File, 
  Video, 
  BookOpen, 
  Download,
  Trash, 
  Edit, 
  ExternalLink,
  Upload
} from 'lucide-react';

interface LearningMaterial {
  id: string;
  title: string;
  description: string | null;
  type: string;
  level: string;
  content: string | null;
  url: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string | null;
  creator_name?: string;
}

const AdminMaterials = () => {
  const [materials, setMaterials] = useState<LearningMaterial[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [levelFilter, setLevelFilter] = useState('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentMaterial, setCurrentMaterial] = useState<LearningMaterial | null>(null);
  
  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState('document');
  const [level, setLevel] = useState('beginner');
  const [url, setUrl] = useState('');
  const [content, setContent] = useState('');
  const [fileToUpload, setFileToUpload] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  
  useEffect(() => {
    fetchMaterials();
  }, []);
  
  const fetchMaterials = async () => {
    try {
      setIsLoading(true);
      
      const { data, error } = await supabase
        .from('learning_materials')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) {
        throw error;
      }
      
      if (data) {
        // Get creator names for each material
        const materialsWithCreatorNames = await Promise.all(data.map(async material => {
          let creatorName = 'Unknown';
          
          if (material.created_by) {
            const { data: userData, error: userError } = await supabase
              .from('profiles')
              .select('name')
              .eq('id', material.created_by)
              .single();
              
            if (!userError && userData && userData.name) {
              creatorName = userData.name;
            }
          }
          
          return {
            ...material,
            creator_name: creatorName
          };
        }));
        
        setMaterials(materialsWithCreatorNames);
      }
      
    } catch (error) {
      console.error('Error fetching materials:', error);
      toast.error('Gagal memuat data materi');
    } finally {
      setIsLoading(false);
    }
  };
  
  const resetForm = () => {
    setTitle('');
    setDescription('');
    setType('document');
    setLevel('beginner');
    setUrl('');
    setContent('');
    setFileToUpload(null);
  };
  
  const handleAddMaterial = async () => {
    try {
      if (!title) {
        toast.error('Judul wajib diisi');
        return;
      }
      
      setIsUploading(true);
      
      // Get current user
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Anda harus login untuk menambahkan materi');
        return;
      }
      
      let fileUrl = '';
      
      // If document type and file is selected, upload it first
      if (type === 'document' && fileToUpload) {
        const fileExt = fileToUpload.name.split('.').pop();
        const fileName = `${Math.random().toString(36).substring(2, 15)}.${fileExt}`;
        const filePath = `materials/${fileName}`;
        
        const { error: uploadError } = await supabase.storage
          .from('materials')
          .upload(filePath, fileToUpload);
        
        if (uploadError) throw uploadError;
        
        // Get the public URL
        const { data: urlData } = supabase.storage
          .from('materials')
          .getPublicUrl(filePath);
          
        fileUrl = urlData.publicUrl;
      } else if ((type === 'video' || type === 'link') && !url) {
        toast.error('URL wajib diisi untuk tipe video atau link');
        setIsUploading(false);
        return;
      }
      
      const newMaterial = {
        title,
        description,
        type,
        level,
        url: type === 'document' ? fileUrl : url,
        content,
        created_by: session.user.id
      };
      
      const { data, error } = await supabase
        .from('learning_materials')
        .insert(newMaterial)
        .select();
      
      if (error) throw error;
      
      toast.success('Materi berhasil ditambahkan');
      resetForm();
      setIsAddDialogOpen(false);
      fetchMaterials();
      
    } catch (error) {
      console.error('Error adding material:', error);
      toast.error('Gagal menambahkan materi');
    } finally {
      setIsUploading(false);
    }
  };
  
  const handleEditMaterial = async () => {
    try {
      if (!currentMaterial) return;
      
      if (!title) {
        toast.error('Judul wajib diisi');
        return;
      }
      
      setIsUploading(true);
      
      let fileUrl = currentMaterial.url;
      
      // If document type and new file is selected, upload it
      if (type === 'document' && fileToUpload) {
        const fileExt = fileToUpload.name.split('.').pop();
        const fileName = `${Math.random().toString(36).substring(2, 15)}.${fileExt}`;
        const filePath = `materials/${fileName}`;
        
        const { error: uploadError } = await supabase.storage
          .from('materials')
          .upload(filePath, fileToUpload);
        
        if (uploadError) throw uploadError;
        
        // Get the public URL
        const { data: urlData } = supabase.storage
          .from('materials')
          .getPublicUrl(filePath);
          
        fileUrl = urlData.publicUrl;
      } else if ((type === 'video' || type === 'link') && !url && !currentMaterial.url) {
        toast.error('URL wajib diisi untuk tipe video atau link');
        setIsUploading(false);
        return;
      }
      
      const updatedMaterial = {
        title,
        description,
        type,
        level,
        url: type === 'document' ? fileUrl : url || currentMaterial.url,
        content,
        updated_at: new Date().toISOString()
      };
      
      const { error } = await supabase
        .from('learning_materials')
        .update(updatedMaterial)
        .eq('id', currentMaterial.id);
      
      if (error) throw error;
      
      toast.success('Materi berhasil diperbarui');
      setIsEditDialogOpen(false);
      fetchMaterials();
      
    } catch (error) {
      console.error('Error updating material:', error);
      toast.error('Gagal memperbarui materi');
    } finally {
      setIsUploading(false);
    }
  };
  
  const handleDeleteMaterial = async (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus materi ini?')) {
      try {
        const { error } = await supabase
          .from('learning_materials')
          .delete()
          .eq('id', id);
        
        if (error) throw error;
        
        toast.success('Materi berhasil dihapus');
        fetchMaterials();
        
      } catch (error) {
        console.error('Error deleting material:', error);
        toast.error('Gagal menghapus materi');
      }
    }
  };
  
  const openEditDialog = (material: LearningMaterial) => {
    setCurrentMaterial(material);
    setTitle(material.title);
    setDescription(material.description || '');
    setType(material.type);
    setLevel(material.level);
    setUrl(material.url || '');
    setContent(material.content || '');
    setIsEditDialogOpen(true);
  };
  
  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'document':
        return <File className="h-4 w-4 text-blue-500" />;
      case 'video':
        return <Video className="h-4 w-4 text-red-500" />;
      case 'link':
        return <Link className="h-4 w-4 text-green-500" />;
      default:
        return <BookOpen className="h-4 w-4 text-gray-500" />;
    }
  };
  
  const getLevelBadge = (level: string) => {
    switch (level) {
      case 'beginner':
        return <Badge variant="outline" className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">Pemula</Badge>;
      case 'intermediate':
        return <Badge variant="outline" className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200">Menengah</Badge>;
      case 'advanced':
        return <Badge variant="outline" className="bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200">Lanjutan</Badge>;
      default:
        return <Badge variant="outline">{level}</Badge>;
    }
  };
  
  const formatDate = (dateStr: string) => {
    try {
      const date = parseISO(dateStr);
      return format(date, 'dd MMM yyyy', { locale: id });
    } catch (e) {
      return dateStr;
    }
  };
  
  const filteredMaterials = materials.filter(material => {
    let typeMatch = typeFilter === 'all' || material.type === typeFilter;
    let levelMatch = levelFilter === 'all' || material.level === levelFilter;
    let searchMatch = 
      material.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (material.description && material.description.toLowerCase().includes(searchQuery.toLowerCase()));
      
    return typeMatch && levelMatch && searchMatch;
  });
  
  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <AdminSidebar />
      
      <div className="ml-0 md:ml-64 p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Manajemen Materi</h1>
            <p className="text-gray-600 dark:text-gray-400">Kelola materi pembelajaran robotik</p>
          </div>
          
          <div className="flex flex-col md:flex-row gap-4 mt-4 md:mt-0">
            <div className="flex gap-2">
              <Select
                value={typeFilter}
                onValueChange={setTypeFilter}
              >
                <SelectTrigger className="w-[130px]">
                  <SelectValue placeholder="Tipe" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Tipe</SelectItem>
                  <SelectItem value="document">Dokumen</SelectItem>
                  <SelectItem value="video">Video</SelectItem>
                  <SelectItem value="link">Link</SelectItem>
                </SelectContent>
              </Select>
              
              <Select
                value={levelFilter}
                onValueChange={setLevelFilter}
              >
                <SelectTrigger className="w-[130px]">
                  <SelectValue placeholder="Level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Level</SelectItem>
                  <SelectItem value="beginner">Pemula</SelectItem>
                  <SelectItem value="intermediate">Menengah</SelectItem>
                  <SelectItem value="advanced">Lanjutan</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Input 
              placeholder="Cari materi..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full md:w-64"
            />
            
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button>Tambah Materi</Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Tambah Materi Baru</DialogTitle>
                </DialogHeader>
                
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="title">Judul Materi</label>
                      <Input
                        id="title"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        placeholder="Masukkan judul materi"
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label htmlFor="level">Level</label>
                      <Select value={level} onValueChange={setLevel}>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="beginner">Pemula</SelectItem>
                          <SelectItem value="intermediate">Menengah</SelectItem>
                          <SelectItem value="advanced">Lanjutan</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="description">Deskripsi</label>
                    <Textarea
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Masukkan deskripsi materi"
                      rows={3}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="type">Tipe Materi</label>
                    <Select value={type} onValueChange={setType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih tipe" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="document">Dokumen</SelectItem>
                        <SelectItem value="video">Video</SelectItem>
                        <SelectItem value="link">Link</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {type === 'document' ? (
                    <div className="space-y-2">
                      <label htmlFor="file">Unggah Dokumen</label>
                      <Input
                        id="file"
                        type="file"
                        onChange={(e) => setFileToUpload(e.target.files?.[0] || null)}
                        accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx"
                      />
                      <p className="text-xs text-gray-500">
                        Format yang didukung: PDF, Word, PowerPoint, Excel
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <label htmlFor="url">URL {type === 'video' ? 'Video' : 'Website'}</label>
                      <Input
                        id="url"
                        value={url}
                        onChange={(e) => setUrl(e.target.value)}
                        placeholder={`Masukkan URL ${type === 'video' ? 'video' : 'website'}`}
                      />
                    </div>
                  )}
                  
                  <div className="space-y-2">
                    <label htmlFor="content">Catatan Tambahan (Opsional)</label>
                    <Textarea
                      id="content"
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                      placeholder="Tambahkan catatan atau petunjuk tambahan"
                      rows={3}
                    />
                  </div>
                </div>
                
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                    Batal
                  </Button>
                  <Button 
                    onClick={handleAddMaterial}
                    disabled={isUploading}
                  >
                    {isUploading ? "Mengunggah..." : "Tambah Materi"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
        
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-14 bg-gray-200 dark:bg-gray-700 rounded-md animate-pulse" />
            ))}
          </div>
        ) : filteredMaterials.length === 0 ? (
          <div className="text-center p-12 bg-white dark:bg-gray-800 rounded-md shadow">
            <h2 className="text-xl font-medium mb-2">Tidak ada materi ditemukan</h2>
            <p className="text-gray-500">
              {materials.length === 0 
                ? 'Belum ada materi yang ditambahkan' 
                : 'Tidak ada materi yang sesuai dengan filter Anda'}
            </p>
          </div>
        ) : (
          <div className="bg-white dark:bg-gray-800 rounded-md shadow overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Judul</TableHead>
                  <TableHead>Tipe</TableHead>
                  <TableHead>Level</TableHead>
                  <TableHead>Dibuat Oleh</TableHead>
                  <TableHead>Tanggal</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredMaterials.map((material) => (
                  <TableRow key={material.id}>
                    <TableCell className="font-medium">{material.title}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        {getTypeIcon(material.type)}
                        <span className="capitalize">{material.type}</span>
                      </div>
                    </TableCell>
                    <TableCell>{getLevelBadge(material.level)}</TableCell>
                    <TableCell>{material.creator_name}</TableCell>
                    <TableCell>{formatDate(material.created_at)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        {material.url && (
                          <Button 
                            size="sm" 
                            variant="outline"
                            asChild
                          >
                            <a 
                              href={material.url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="flex items-center gap-1"
                            >
                              {material.type === 'document' ? (
                                <>
                                  <Download className="h-4 w-4" />
                                  <span>Unduh</span>
                                </>
                              ) : (
                                <>
                                  <ExternalLink className="h-4 w-4" />
                                  <span>Buka</span>
                                </>
                              )}
                            </a>
                          </Button>
                        )}
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => openEditDialog(material)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive"
                          onClick={() => handleDeleteMaterial(material.id)}
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
      
      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Materi</DialogTitle>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label htmlFor="edit-title">Judul Materi</label>
                <Input
                  id="edit-title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Masukkan judul materi"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <label htmlFor="edit-level">Level</label>
                <Select value={level} onValueChange={setLevel}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="beginner">Pemula</SelectItem>
                    <SelectItem value="intermediate">Menengah</SelectItem>
                    <SelectItem value="advanced">Lanjutan</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <label htmlFor="edit-description">Deskripsi</label>
              <Textarea
                id="edit-description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Masukkan deskripsi materi"
                rows={3}
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="edit-type">Tipe Materi</label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger>
                  <SelectValue placeholder="Pilih tipe" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="document">Dokumen</SelectItem>
                  <SelectItem value="video">Video</SelectItem>
                  <SelectItem value="link">Link</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {type === 'document' ? (
              <div className="space-y-2">
                {currentMaterial?.url && (
                  <div className="flex items-center gap-2 mb-2">
                    <File className="h-5 w-5 text-blue-500" />
                    <span className="text-sm">Dokumen saat ini:</span>
                    <a 
                      href={currentMaterial.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-500 hover:underline text-sm flex items-center gap-1"
                    >
                      <span>Lihat dokumen</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                )}
                
                <label htmlFor="edit-file">Unggah Dokumen Baru (Opsional)</label>
                <Input
                  id="edit-file"
                  type="file"
                  onChange={(e) => setFileToUpload(e.target.files?.[0] || null)}
                  accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx"
                />
                <p className="text-xs text-gray-500">
                  Format yang didukung: PDF, Word, PowerPoint, Excel
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                <label htmlFor="edit-url">URL {type === 'video' ? 'Video' : 'Website'}</label>
                <Input
                  id="edit-url"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder={`Masukkan URL ${type === 'video' ? 'video' : 'website'}`}
                />
              </div>
            )}
            
            <div className="space-y-2">
              <label htmlFor="edit-content">Catatan Tambahan (Opsional)</label>
              <Textarea
                id="edit-content"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Tambahkan catatan atau petunjuk tambahan"
                rows={3}
              />
            </div>
          </div>
          
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Batal
            </Button>
            <Button 
              onClick={handleEditMaterial}
              disabled={isUploading}
            >
              {isUploading ? "Menyimpan..." : "Simpan Perubahan"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminMaterials;
