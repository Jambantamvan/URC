
import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import Navigation from '@/components/Navigation';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ShieldCheck, UserPlus, ShieldAlert } from 'lucide-react';
import { Profile, UserRole } from '@/types/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { MembersList } from '@/components/Members/MembersList';

const MembersPanel = () => {
  const [members, setMembers] = useState<Profile[]>([]);
  const [admins, setAdmins] = useState<Profile[]>([]);
  const [nonMembers, setNonMembers] = useState<Profile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { profile } = useAuth();
  
  useEffect(() => {
    fetchUsers();
  }, []);
  
  const fetchUsers = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      
      if (data) {
        // Cast the data to the correct type and filter
        const typedData = data.map(user => ({
          ...user,
          role: user.role as UserRole
        }));
        
        setMembers(typedData.filter(user => user.role === 'member'));
        setAdmins(typedData.filter(user => user.role === 'admin'));
        setNonMembers(typedData.filter(user => user.role === 'non-member'));
      }
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error('Gagal memuat daftar pengguna');
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="flex-1 md:ml-64 pt-16 md:pt-0 pb-12">
        <div className="p-6 max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold mb-2">Panel Anggota</h1>
          <p className="mb-6 text-gray-600 dark:text-gray-300">
            Lihat daftar semua anggota klub robotik berdasarkan peran mereka
          </p>
          
          <Tabs defaultValue="members" className="mt-4">
            <TabsList className="mb-4">
              <TabsTrigger value="members" className="flex items-center">
                <ShieldCheck className="h-4 w-4 mr-2" />
                <span>Members</span>
                <Badge variant="outline" className="ml-2">{members.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="admins" className="flex items-center">
                <ShieldAlert className="h-4 w-4 mr-2" />
                <span>Admins</span>
                <Badge variant="outline" className="ml-2">{admins.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="non-members" className="flex items-center">
                <UserPlus className="h-4 w-4 mr-2" />
                <span>Non-Members</span>
                <Badge variant="outline" className="ml-2">{nonMembers.length}</Badge>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="members">
              <MembersList members={members} isLoading={isLoading} type="members" />
            </TabsContent>
            
            <TabsContent value="admins">
              <MembersList members={admins} isLoading={isLoading} type="admins" />
            </TabsContent>
            
            <TabsContent value="non-members">
              <MembersList members={nonMembers} isLoading={isLoading} type="non-members" />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default MembersPanel;
