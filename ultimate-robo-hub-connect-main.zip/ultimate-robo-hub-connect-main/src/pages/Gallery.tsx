
import { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  getAchievements,
  getAchievementById,
  createAchievement,
  updateAchievement,
  deleteAchievement,
  addMediaToEntity,
  getUserById
} from "@/services/api";
import { Achievement, Media } from "@/types";
import Navigation from "@/components/Navigation";
import { 
  Calendar,
  Image as ImageIcon,
  Plus, 
  Trophy, 
  Users,
  Trash,
  ArrowLeft,
  Video
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";

const GalleryListView = () => {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadAchievements();
  }, []);

  const loadAchievements = () => {
    try {
      const allAchievements = getAchievements();
      
      // Sort by date (newest first)
      const sortedAchievements = [...allAchievements].sort(
        (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
      );
      
      setAchievements(sortedAchievements);
    } catch (error) {
      console.error('Error loading achievements:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="flex-1 md:ml-64 pt-16 md:pt-0">
        <div className="p-6 max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
            <div>
              <h1 className="text-3xl font-bold">Galeri Prestasi</h1>
              <p className="text-gray-600 dark:text-gray-300 mt-1">
                Dokumentasi prestasi dan pencapaian tim robotik
              </p>
            </div>
            
            <Button className="bg-robo-blue hover:bg-robo-darkBlue" asChild>
              <Link to="/gallery/new">
                <Plus className="mr-2 h-5 w-5" />
                Prestasi Baru
              </Link>
            </Button>
          </div>
          
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((_, i) => (
                <div key={i} className="h-64 bg-gray-200 dark:bg-gray-700 rounded-lg animate-pulse"></div>
              ))}
            </div>
          ) : achievements.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {achievements.map((achievement) => (
                <Link key={achievement.id} to={`/gallery/${achievement.id}`}>
                  <div className="bg-white dark:bg-robo-dark rounded-lg overflow-hidden border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all duration-300 group">
                    <div className="h-48 overflow-hidden bg-gray-100 dark:bg-gray-800 relative">
                      {achievement.media.length > 0 ? (
                        achievement.media[0].type === 'image' ? (
                          <img 
                            src={achievement.media[0].url} 
                            alt={achievement.title} 
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        ) : achievement.media[0].type === 'video' ? (
                          <video 
                            src={achievement.media[0].url} 
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="flex items-center justify-center h-full">
                            <Trophy className="h-12 w-12 text-robo-blue" />
                          </div>
                        )
                      ) : (
                        <div className="flex items-center justify-center h-full">
                          <Trophy className="h-12 w-12 text-robo-blue" />
                        </div>
                      )}
                      
                      <div className="absolute top-2 right-2">
                        <Badge className={`${
                          achievement.type === 'competition' 
                            ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-400' 
                            : achievement.type === 'project' 
                              ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-400' 
                              : 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-400'
                        }`}>
                          {achievement.type === 'competition' && 'Kompetisi'}
                          {achievement.type === 'project' && 'Proyek'}
                          {achievement.type === 'other' && 'Lainnya'}
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="p-4">
                      <h3 className="font-semibold text-lg">{achievement.title}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-2 mt-1 mb-3">
                        {achievement.description}
                      </p>
                      
                      <div className="flex justify-between items-center text-xs text-gray-500">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          <span>{format(new Date(achievement.date), "d MMM yyyy")}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="h-3 w-3" />
                          <span>{achievement.participants.length} anggota</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center p-12 bg-white dark:bg-robo-dark rounded-lg">
              <div className="mb-4 text-robo-blue">
                <Trophy className="mx-auto h-12 w-12" />
              </div>
              <h3 className="text-lg font-medium mb-2">Belum ada prestasi yang didokumentasikan</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                Mulai dengan menambahkan prestasi baru tim robotik kita.
              </p>
              <Button className="bg-robo-blue hover:bg-robo-darkBlue" asChild>
                <Link to="/gallery/new">
                  <Plus className="mr-2 h-5 w-5" />
                  Tambah Prestasi
                </Link>
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const AchievementDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [achievement, setAchievement] = useState<Achievement | null>(null);
  const [participants, setParticipants] = useState<{ id: string; name: string }[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [fileToUpload, setFileToUpload] = useState<File | null>(null);
  const [fileTitle, setFileTitle] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  
  useEffect(() => {
    if (id) {
      loadAchievement(id);
    }
  }, [id]);
  
  const loadAchievement = (achievementId: string) => {
    try {
      const achievementData = getAchievementById(achievementId);
      if (achievementData) {
        setAchievement(achievementData);
        
        // Load participant names
        const participantDetails = achievementData.participants.map(participantId => {
          const user = getUserById(participantId);
          return user ? { id: user.id, name: user.name } : { id: participantId, name: "Unknown" };
        });
        setParticipants(participantDetails);
      }
    } catch (error) {
      console.error('Error loading achievement:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleUploadMedia = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !fileToUpload || !fileTitle.trim()) return;
    
    setIsUploading(true);
    
    try {
      await addMediaToEntity('achievement', id, fileToUpload, fileTitle);
      setFileToUpload(null);
      setFileTitle("");
      loadAchievement(id); // Reload achievement to get updated media
    } catch (error) {
      console.error('Error uploading media:', error);
    } finally {
      setIsUploading(false);
    }
  };
  
  const handleDeleteAchievement = () => {
    if (!id) return;
    
    if (window.confirm("Apakah Anda yakin ingin menghapus prestasi ini?")) {
      deleteAchievement(id);
      window.location.href = '/gallery';
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
        <Navigation />
        <div className="flex-1 md:ml-64 pt-16 md:pt-0 p-6 flex items-center justify-center">
          <div className="animate-pulse">Loading achievement...</div>
        </div>
      </div>
    );
  }
  
  if (!achievement) {
    return (
      <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
        <Navigation />
        <div className="flex-1 md:ml-64 pt-16 md:pt-0 p-6 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-bold mb-2">Prestasi tidak ditemukan</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">Prestasi ini mungkin telah dihapus atau tidak ada</p>
            <Link to="/gallery" className="text-robo-blue hover:underline">
              Kembali ke Galeri
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="flex-1 md:ml-64 pt-16 md:pt-0">
        <div className="p-6 max-w-7xl mx-auto">
          <Link to="/gallery" className="flex items-center text-robo-blue hover:underline mb-4">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Kembali ke Galeri
          </Link>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <div className="bg-white dark:bg-robo-dark rounded-lg shadow-sm overflow-hidden mb-6">
                <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                  <div className="flex justify-between items-start">
                    <div>
                      <h1 className="text-2xl font-bold mb-2">{achievement.title}</h1>
                      <div className="flex items-center text-gray-600 dark:text-gray-400 mb-2">
                        <Calendar className="h-4 w-4 mr-1" />
                        <span className="text-sm">{format(new Date(achievement.date), "d MMMM yyyy")}</span>
                      </div>
                      <Badge className={`${
                        achievement.type === 'competition' 
                          ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-400' 
                          : achievement.type === 'project' 
                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-400' 
                            : 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-400'
                      }`}>
                        {achievement.type === 'competition' && 'Kompetisi'}
                        {achievement.type === 'project' && 'Proyek'}
                        {achievement.type === 'other' && 'Lainnya'}
                      </Badge>
                    </div>
                    
                    <Button 
                      variant="destructive" 
                      size="icon" 
                      onClick={handleDeleteAchievement}
                    >
                      <Trash className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="p-6">
                  <h2 className="text-lg font-bold mb-2">Deskripsi</h2>
                  <p className="text-gray-700 dark:text-gray-300 mb-6">
                    {achievement.description}
                  </p>
                  
                  <h2 className="text-lg font-bold mb-4">Galeri Foto & Video</h2>
                  
                  {achievement.media.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                      {achievement.media.map((item: Media) => (
                        <div key={item.id} className="border rounded-lg overflow-hidden">
                          {item.type === 'image' ? (
                            <div className="aspect-video">
                              <img 
                                src={item.url} 
                                alt={item.title} 
                                className="w-full h-full object-cover"
                              />
                            </div>
                          ) : item.type === 'video' ? (
                            <div className="aspect-video">
                              <video 
                                src={item.url} 
                                controls 
                                className="w-full h-full object-cover"
                              />
                            </div>
                          ) : (
                            <div className="aspect-video flex items-center justify-center bg-gray-100 dark:bg-gray-800">
                              <Trophy className="h-12 w-12 text-gray-400" />
                            </div>
                          )}
                          <div className="p-3">
                            <h4 className="font-medium">{item.title}</h4>
                            <p className="text-sm text-gray-500">
                              Diunggah {format(new Date(item.createdAt), "d MMM yyyy")}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 mb-6">Belum ada media yang diunggah</p>
                  )}
                  
                  <form onSubmit={handleUploadMedia} className="border-t pt-4">
                    <h4 className="font-medium mb-3">Unggah Media Baru</h4>
                    <div className="grid grid-cols-1 gap-4">
                      <Input
                        type="text"
                        placeholder="Judul Media"
                        value={fileTitle}
                        onChange={(e) => setFileTitle(e.target.value)}
                        required
                      />
                      
                      <Input
                        type="file"
                        onChange={(e) => setFileToUpload(e.target.files?.[0] || null)}
                        required
                      />
                      
                      <Button 
                        type="submit" 
                        className="w-full md:w-auto" 
                        disabled={isUploading || !fileToUpload || !fileTitle.trim()}
                      >
                        {isUploading ? "Mengunggah..." : "Unggah Media"}
                      </Button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            
            <div>
              <div className="bg-white dark:bg-robo-dark rounded-lg shadow-sm overflow-hidden">
                <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                  <h2 className="text-lg font-bold">Tim Peserta</h2>
                </div>
                
                <div className="p-6">
                  <div className="space-y-3">
                    {participants.length > 0 ? (
                      participants.map(participant => (
                        <div 
                          key={participant.id} 
                          className="flex items-center gap-3"
                        >
                          <div className="w-8 h-8 rounded-full bg-robo-blue text-white flex items-center justify-center">
                            {participant.name.charAt(0)}
                          </div>
                          <span>{participant.name}</span>
                        </div>
                      ))
                    ) : (
                      <p className="text-gray-500">Tidak ada peserta terdaftar</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const NewAchievement = () => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [date, setDate] = useState("");
  const [type, setType] = useState<'competition' | 'project' | 'other'>('competition');
  const [participants, setParticipants] = useState<string[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const [fileTitle, setFileTitle] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  useEffect(() => {
    // Default to today's date
    const today = new Date();
    const formattedDate = formatDateForInput(today);
    setDate(formattedDate);
  }, []);
  
  const formatDateForInput = (date: Date): string => {
    return date.toISOString().split('T')[0];
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description || !date || !type) return;
    
    setIsSubmitting(true);
    
    try {
      const achievementData = {
        title,
        description,
        date: new Date(date).toISOString(),
        type,
        participants: [], // Currently not implementing participant selection UI
        media: []
      };
      
      const newAchievement = createAchievement(achievementData);
      
      // If there's a file to upload, add it
      if (newAchievement && file && fileTitle) {
        await addMediaToEntity('achievement', newAchievement.id, file, fileTitle);
      }
      
      window.location.href = `/gallery/${newAchievement.id}`;
    } catch (error) {
      console.error('Error creating achievement:', error);
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="flex-1 md:ml-64 pt-16 md:pt-0">
        <div className="p-6 max-w-3xl mx-auto">
          <div className="mb-8">
            <Link to="/gallery" className="text-robo-blue hover:underline flex items-center gap-1">
              <ArrowLeft className="h-4 w-4" />
              Kembali ke galeri
            </Link>
            <h1 className="text-3xl font-bold mt-2">Tambah Prestasi Baru</h1>
            <p className="text-gray-600 dark:text-gray-300 mt-1">
              Dokumentasikan prestasi dan pencapaian tim robotik
            </p>
          </div>
          
          <Card>
            <CardContent className="pt-6">
              <form onSubmit={handleSubmit}>
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label htmlFor="title" className="block text-sm font-medium">
                      Judul Prestasi <span className="text-red-500">*</span>
                    </label>
                    <Input
                      id="title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="Contoh: Juara 2 Lomba Robotik Nasional"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="description" className="block text-sm font-medium">
                      Deskripsi <span className="text-red-500">*</span>
                    </label>
                    <Textarea
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Ceritakan tentang prestasi ini..."
                      rows={4}
                      required
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label htmlFor="date" className="block text-sm font-medium">
                        Tanggal <span className="text-red-500">*</span>
                      </label>
                      <Input
                        id="date"
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label htmlFor="type" className="block text-sm font-medium">
                        Tipe <span className="text-red-500">*</span>
                      </label>
                      <select
                        id="type"
                        value={type}
                        onChange={(e) => setType(e.target.value as 'competition' | 'project' | 'other')}
                        className="w-full rounded-md border border-input bg-background px-3 py-2"
                        required
                      >
                        <option value="competition">Kompetisi</option>
                        <option value="project">Proyek</option>
                        <option value="other">Lainnya</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="block text-sm font-medium">
                      Media (Opsional)
                    </label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Input
                        type="text"
                        placeholder="Judul Media"
                        value={fileTitle}
                        onChange={(e) => setFileTitle(e.target.value)}
                      />
                      
                      <Input
                        type="file"
                        onChange={(e) => setFile(e.target.files?.[0] || null)}
                      />
                    </div>
                    <p className="text-xs text-gray-500">
                      Anda dapat mengunggah lebih banyak media setelah membuat prestasi
                    </p>
                  </div>
                  
                  <div className="pt-4 border-t">
                    <Button
                      type="submit"
                      className="w-full md:w-auto bg-robo-blue hover:bg-robo-darkBlue"
                      disabled={isSubmitting || !title || !description || !date || !type}
                    >
                      {isSubmitting ? "Menyimpan..." : "Tambah Prestasi"}
                    </Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

const Gallery = () => {
  const { id } = useParams<{ id: string }>();
  
  if (id === 'new') {
    return <NewAchievement />;
  } else if (id) {
    return <AchievementDetail />;
  } else {
    return <GalleryListView />;
  }
};

export default Gallery;
