
import React, { useState, useEffect } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay, addDays } from 'date-fns';
import { id } from 'date-fns/locale';
import { supabase } from '@/integrations/supabase/custom-client';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, PlusCircle } from 'lucide-react';
import { Card } from "@/components/ui/card";
import EventCard from '@/components/EventCard';
import Navigation from '@/components/Navigation';
import RoleBasedAccess from '@/components/RoleBasedAccess';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog';
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from 'sonner';

interface CalendarEvent {
  id: string;
  title: string;
  description: string | null;
  location: string | null;
  start_date: string;
  end_date: string;
  created_by: string | null;
  created_at: string | null;
}

const CalendarPage = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedDayEvents, setSelectedDayEvents] = useState<CalendarEvent[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { profile } = useAuth();
  
  // Dialog states
  const [dialogOpen, setDialogOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [startDate, setStartDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endDate, setEndDate] = useState('');
  const [endTime, setEndTime] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Get current month days
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const monthDays = eachDayOfInterval({ start: monthStart, end: monthEnd });
  
  // Get day of the week for first day (0 = Sunday, 6 = Saturday)
  const startDay = getDay(monthStart);
  
  // Add empty cells for days before the start of the month
  const blanks = Array(startDay).fill(null);
  
  // Create calendar days
  const calendarDays = [...blanks, ...monthDays];
  
  // Calendar rows (weeks)
  const rows = Math.ceil(calendarDays.length / 7);
  const calendarRows = Array.from({ length: rows }, (_, i) =>
    calendarDays.slice(i * 7, (i + 1) * 7)
  );

  useEffect(() => {
    fetchEvents();
  }, [currentDate]);

  const fetchEvents = async () => {
    try {
      setIsLoading(true);
      
      const startDate = format(startOfMonth(currentDate), 'yyyy-MM-dd');
      const endDate = format(endOfMonth(currentDate), 'yyyy-MM-dd');
      
      const { data, error } = await supabase
        .from('events')
        .select('*')
        .gte('start_date', `${startDate}T00:00:00`)
        .lte('start_date', `${endDate}T23:59:59`)
        .order('start_date', { ascending: true });
      
      if (error) {
        throw error;
      }
      
      setEvents(data || []);
    } catch (error) {
      console.error('Error fetching events:', error);
      toast.error('Gagal memuat data kegiatan');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePreviousMonth = () => {
    setCurrentDate(prev => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(prev => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
  };

  const handleDateClick = (date: Date | null) => {
    setSelectedDate(date);
    
    if (date) {
      const dateStr = format(date, 'yyyy-MM-dd');
      const filteredEvents = events.filter(event => 
        event.start_date.startsWith(dateStr)
      );
      setSelectedDayEvents(filteredEvents);
    } else {
      setSelectedDayEvents([]);
    }
  };

  const getDayEvents = (date: Date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    return events.filter(event => event.start_date.startsWith(dateStr));
  };
  
  const handleOpenDialog = () => {
    // Default to selected date or today
    const defaultDate = selectedDate || new Date();
    
    setTitle('');
    setDescription('');
    setLocation('');
    setStartDate(format(defaultDate, 'yyyy-MM-dd'));
    setStartTime('09:00');
    setEndDate(format(defaultDate, 'yyyy-MM-dd'));
    setEndTime('12:00');
    
    setDialogOpen(true);
  };
  
  const handleCreateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (!title || !startDate || !startTime || !endDate || !endTime) {
        toast.error('Mohon isi semua field yang diperlukan');
        return;
      }
      
      setIsSubmitting(true);
      
      // Combine date and time
      const startDateTime = `${startDate}T${startTime}:00`;
      const endDateTime = `${endDate}T${endTime}:00`;
      
      if (new Date(endDateTime) <= new Date(startDateTime)) {
        toast.error('Waktu selesai harus setelah waktu mulai');
        setIsSubmitting(false);
        return;
      }
      
      const { data: userData } = await supabase.auth.getUser();
      
      const { error } = await supabase
        .from('events')
        .insert({
          title,
          description,
          location,
          start_date: startDateTime,
          end_date: endDateTime,
          created_by: userData.user?.id
        });
      
      if (error) throw error;
      
      toast.success('Kegiatan berhasil ditambahkan');
      setDialogOpen(false);
      
      // Refresh events
      fetchEvents();
      
      // If we created an event for the selected date, update the selected day events
      if (selectedDate && startDate === format(selectedDate, 'yyyy-MM-dd')) {
        const { data } = await supabase
          .from('events')
          .select('*')
          .eq('start_date', `${format(selectedDate, 'yyyy-MM-dd')}T${startTime}:00`);
          
        if (data) {
          setSelectedDayEvents(prev => [...prev, ...data]);
        }
      }
      
    } catch (error) {
      console.error('Error creating event:', error);
      toast.error('Terjadi kesalahan saat menambahkan kegiatan');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <RoleBasedAccess 
      allowedRoles={['admin', 'member']}
      fallbackMessage="Hanya member yang dapat mengakses kalender kegiatan. Silakan daftar menjadi member terlebih dahulu."
    >
      <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
        <Navigation />
        
        <div className="flex-1 md:ml-64 pt-16 md:pt-0 pb-12">
          <div className="p-4 md:p-6 max-w-7xl mx-auto">
            <div className="flex items-center justify-between mb-6">
              <h1 className="text-2xl md:text-3xl font-bold">Kalender Kegiatan</h1>
              
              <Button onClick={handleOpenDialog} className="hidden md:flex">
                <PlusCircle className="h-4 w-4 mr-2" /> Tambah Kegiatan
              </Button>
            </div>

            {/* ... keep existing code (calendar content) */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card className="overflow-hidden">
                  <div className="bg-robo-blue text-white p-4 flex items-center justify-between">
                    <Button 
                      variant="ghost" 
                      onClick={handlePreviousMonth} 
                      className="text-white hover:bg-robo-blue/50"
                    >
                      <ChevronLeft className="h-5 w-5" />
                    </Button>
                    
                    <h2 className="text-xl font-medium">
                      {format(currentDate, 'MMMM yyyy', { locale: id })}
                    </h2>
                    
                    <Button 
                      variant="ghost" 
                      onClick={handleNextMonth} 
                      className="text-white hover:bg-robo-blue/50"
                    >
                      <ChevronRight className="h-5 w-5" />
                    </Button>
                  </div>
                  
                  <div className="p-2">
                    <div className="grid grid-cols-7 mb-2 text-center">
                      {['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'].map((day, idx) => (
                        <div key={idx} className="py-2 font-medium text-sm text-gray-500">
                          {day}
                        </div>
                      ))}
                    </div>
                    
                    <div className="bg-white dark:bg-gray-800 rounded-md">
                      {calendarRows.map((row, rowIdx) => (
                        <div key={rowIdx} className="grid grid-cols-7">
                          {row.map((day, colIdx) => {
                            if (day === null) {
                              return <div key={colIdx} className="aspect-square p-1 border border-gray-100 dark:border-gray-700"></div>;
                            }
                            
                            const isToday = format(day, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd');
                            const isSelected = selectedDate && format(day, 'yyyy-MM-dd') === format(selectedDate, 'yyyy-MM-dd');
                            const dayEvents = getDayEvents(day);
                            const hasEvents = dayEvents.length > 0;
                            
                            return (
                              <div 
                                key={colIdx} 
                                className={`
                                  aspect-square p-1 border border-gray-100 dark:border-gray-700
                                  hover:bg-gray-50 dark:hover:bg-gray-700/50 cursor-pointer
                                  ${isToday ? 'bg-blue-50 dark:bg-blue-900/20' : ''}
                                  ${isSelected ? 'ring-2 ring-robo-blue' : ''}
                                `}
                                onClick={() => handleDateClick(day)}
                              >
                                <div className="h-full flex flex-col">
                                  <div className={`
                                    w-6 h-6 flex items-center justify-center rounded-full text-sm
                                    ${isToday ? 'bg-robo-blue text-white' : ''}
                                  `}>
                                    {format(day, 'd')}
                                  </div>
                                  
                                  {hasEvents && (
                                    <div className="mt-auto">
                                      {dayEvents.length <= 2 ? (
                                        dayEvents.map((event, i) => (
                                          <div key={i} className="text-xs truncate mt-1 bg-robo-blue/10 text-robo-blue px-1 rounded">
                                            {event.title}
                                          </div>
                                        ))
                                      ) : (
                                        <Badge variant="outline" className="mt-1 text-xs">
                                          {dayEvents.length} kegiatan
                                        </Badge>
                                      )}
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      ))}
                    </div>
                  </div>
                </Card>

                <Button onClick={handleOpenDialog} className="w-full mt-4 md:hidden">
                  <PlusCircle className="h-4 w-4 mr-2" /> Tambah Kegiatan
                </Button>
              </div>
              
              {/* ... keep existing code (selected day events) */}
              <div>
                <Card className="h-full">
                  <div className="p-4 border-b dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
                    <div className="flex items-center">
                      <CalendarIcon className="mr-2 h-5 w-5 text-robo-blue" />
                      <h3 className="font-medium">
                        {selectedDate ? (
                          format(selectedDate, 'EEEE, d MMMM yyyy', { locale: id })
                        ) : (
                          'Kegiatan Terbaru'
                        )}
                      </h3>
                    </div>
                  </div>
                  
                  <div className="p-4">
                    {isLoading ? (
                      <div className="animate-pulse space-y-3">
                        <div className="h-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
                        <div className="h-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
                      </div>
                    ) : selectedDate && selectedDayEvents.length > 0 ? (
                      <div className="space-y-3">
                        {selectedDayEvents.map(event => (
                          <EventCard
                            key={event.id}
                            event={{
                              id: event.id,
                              title: event.title,
                              description: event.description || '',
                              location: event.location || '',
                              startDate: event.start_date,
                              endDate: event.end_date,
                              attendees: [],
                              createdBy: event.created_by || '',
                              createdAt: event.created_at || '',
                              updatedAt: event.created_at || ''
                            }}
                          />
                        ))}
                      </div>
                    ) : selectedDate ? (
                      <div className="text-center py-8 text-gray-500">
                        <p>Tidak ada kegiatan pada tanggal ini</p>
                      </div>
                    ) : events.length > 0 ? (
                      <div className="space-y-3">
                        {events.slice(0, 3).map(event => (
                          <EventCard
                            key={event.id}
                            event={{
                              id: event.id,
                              title: event.title,
                              description: event.description || '',
                              location: event.location || '',
                              startDate: event.start_date,
                              endDate: event.end_date,
                              attendees: [],
                              createdBy: event.created_by || '',
                              createdAt: event.created_at || '',
                              updatedAt: event.created_at || ''
                            }}
                            compact
                          />
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        <p>Tidak ada kegiatan terjadwal</p>
                      </div>
                    )}
                  </div>
                </Card>
              </div>
            </div>
          </div>
        </div>
        
        {/* Add Event Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Tambah Kegiatan Baru</DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleCreateEvent}>
              <div className="grid gap-4 py-4">
                <div>
                  <label htmlFor="title" className="block text-sm font-medium mb-1">
                    Judul <span className="text-red-500">*</span>
                  </label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Masukkan judul kegiatan"
                    required
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="startDate" className="block text-sm font-medium mb-1">
                      Tanggal Mulai <span className="text-red-500">*</span>
                    </label>
                    <Input
                      id="startDate"
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="startTime" className="block text-sm font-medium mb-1">
                      Jam Mulai <span className="text-red-500">*</span>
                    </label>
                    <Input
                      id="startTime"
                      type="time"
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="endDate" className="block text-sm font-medium mb-1">
                      Tanggal Selesai <span className="text-red-500">*</span>
                    </label>
                    <Input
                      id="endDate"
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="endTime" className="block text-sm font-medium mb-1">
                      Jam Selesai <span className="text-red-500">*</span>
                    </label>
                    <Input
                      id="endTime"
                      type="time"
                      value={endTime}
                      onChange={(e) => setEndTime(e.target.value)}
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="location" className="block text-sm font-medium mb-1">
                    Lokasi
                  </label>
                  <Input
                    id="location"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="Masukkan lokasi kegiatan"
                  />
                </div>
                
                <div>
                  <label htmlFor="description" className="block text-sm font-medium mb-1">
                    Deskripsi
                  </label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Masukkan deskripsi kegiatan"
                    rows={3}
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="secondary" 
                  onClick={() => setDialogOpen(false)}
                >
                  Batal
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? 'Menyimpan...' : 'Tambah Kegiatan'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </RoleBasedAccess>
  );
};

export default CalendarPage;
