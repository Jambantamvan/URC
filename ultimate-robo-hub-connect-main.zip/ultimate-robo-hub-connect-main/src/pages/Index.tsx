import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { supabase } from '@/integrations/supabase/custom-client';
import Navigation from "@/components/Navigation";
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Project } from "@/types/supabase";
import { ChevronRight, Users, Calendar, BookOpen, Code } from "lucide-react";

interface Event {
  id: string;
  title: string;
  description: string | null;
  start_date: string;
  end_date: string;
  location: string | null;
}

const Index = () => {
  const { user, profile } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({
    totalProjects: 0,
    totalMembers: 0,
    totalEvents: 0
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch recent projects
        const { data: projectsData } = await supabase
          .from('projects')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(3);

        // Fetch events
        const { data: eventsData } = await supabase
          .from('events')
          .select('*')
          .gte('start_date', new Date().toISOString())
          .order('start_date', { ascending: true })
          .limit(3);

        // Get stats
        const { count: projectCount } = await supabase
          .from('projects')
          .select('id', { count: 'exact' });

        const { count: memberCount } = await supabase
          .from('profiles')
          .select('id', { count: 'exact' })
          .in('role', ['member', 'admin']);

        const { count: eventCount } = await supabase
          .from('events')
          .select('id', { count: 'exact' })
          .gte('start_date', new Date().toISOString());

        setProjects(projectsData || []);
        setEvents(eventsData || []);
        setStats({
          totalProjects: projectCount || 0,
          totalMembers: memberCount || 0,
          totalEvents: eventCount || 0
        });

      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-50">
      <Navigation />
      
      <div className="flex-1 md:ml-64 pt-16 md:pt-0 pb-12">
        <div className="p-6 max-w-7xl mx-auto">
          {/* Welcome Header */}
          <header className="mb-10">
            <div className="max-w-xl">
              <h1 className="text-3xl font-bold mb-3">
                {user ? `Selamat Datang, ${profile?.name || 'Member'}!` : 'Selamat Datang di UltimateRoboClub'}
              </h1>
              <p className="text-gray-600 dark:text-gray-300">
                {user 
                  ? `Platform ekskul robotik untuk mengembangkan proyek dan belajar bersama. Role: ${profile?.role}`
                  : 'Platform ekskul robotik SMA PKP Jakarta untuk proyek, pembelajaran, dan kolaborasi.'
                }
              </p>
            </div>
            
            {user && (
              <div className="mt-6 flex flex-wrap gap-3">
                <Button className="bg-robo-blue hover:bg-robo-darkBlue" asChild>
                  <Link to="/projects/new">Proyek Baru</Link>
                </Button>
                <Button variant="outline" className="text-robo-blue border-robo-blue hover:bg-robo-blue/10" asChild>
                  <Link to="/playground">Coding Playground</Link>
                </Button>
                <Button variant="outline" className="text-robo-blue border-robo-blue hover:bg-robo-blue/10" asChild>
                  <Link to="/learn">Materi Belajar</Link>
                </Button>
                {profile?.role === 'admin' && (
                  <Button variant="outline" className="text-orange-600 border-orange-600 hover:bg-orange-50" asChild>
                    <Link to="/admin">Admin Dashboard</Link>
                  </Button>
                )}
              </div>
            )}
          </header>

          {/* Auth prompt for guests */}
          {!user && (
            <Card className="mb-8 border-robo-blue/20 bg-robo-blue/5">
              <CardContent className="p-6">
                <div className="text-center">
                  <h2 className="text-xl font-semibold mb-2">Bergabung dengan UltimateRoboClub</h2>
                  <p className="text-gray-600 dark:text-gray-300 mb-4">
                    Login untuk mengakses semua fitur seperti membuat proyek, forum diskusi, dan materi pembelajaran.
                  </p>
                  <div className="flex gap-3 justify-center">
                    <Button className="bg-robo-blue hover:bg-robo-darkBlue" asChild>
                      <Link to="/auth">Login / Daftar</Link>
                    </Button>
                    <Button variant="outline" asChild>
                      <Link to="/registration">Daftar Member</Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Proyek</CardTitle>
                <Code className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalProjects}</div>
                <p className="text-xs text-muted-foreground">Proyek aktif dan selesai</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Member</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalMembers}</div>
                <p className="text-xs text-muted-foreground">Member aktif</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Kegiatan Mendatang</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalEvents}</div>
                <p className="text-xs text-muted-foreground">Event dan workshop</p>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              {/* Projects Section */}
              <section>
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold">Proyek Terbaru</h2>
                  <Button variant="link" asChild>
                    <Link to="/projects" className="flex items-center text-robo-blue">
                      Lihat Semua
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Link>
                  </Button>
                </div>
                
                {isLoading ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[1, 2].map((_, i) => (
                      <div key={i} className="h-40 bg-gray-200 dark:bg-gray-700 rounded-lg animate-pulse"></div>
                    ))}
                  </div>
                ) : projects.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {projects.map((project) => (
                      <Card key={project.id} className="hover:shadow-lg transition-shadow">
                        <CardContent className="p-4">
                          <h3 className="font-semibold text-lg mb-2">{project.title}</h3>
                          <p className="text-gray-600 dark:text-gray-300 text-sm mb-3 line-clamp-2">
                            {project.description}
                          </p>
                          <div className="flex items-center justify-between">
                            <span className="px-2 py-1 bg-robo-blue/10 text-robo-blue rounded-full text-xs">
                              {project.status}
                            </span>
                            <Button variant="ghost" size="sm" asChild>
                              <Link to={`/projects/${project.id}`}>Lihat Detail</Link>
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <Card>
                    <CardContent className="p-6 text-center">
                      <p>Belum ada proyek. Mulai buat proyek pertamamu!</p>
                      {user && (
                        <Button className="mt-4 bg-robo-blue hover:bg-robo-darkBlue" asChild>
                          <Link to="/projects/new">Buat Proyek</Link>
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                )}
              </section>

              {/* Recent Activities */}
              <section>
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold">Aktivitas Terbaru</h2>
                </div>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm">Sistem keamanan telah diperbarui</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        <span className="text-sm">Coding playground dengan output simulator tersedia</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                        <span className="text-sm">Dashboard admin untuk monitoring keamanan ditambahkan</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </section>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-8">
              {/* Upcoming Events Section */}
              <section>
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold">Kegiatan Mendatang</h2>
                  <Button variant="link" asChild>
                    <Link to="/calendar" className="flex items-center text-robo-blue">
                      Kalender
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Link>
                  </Button>
                </div>
                
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2].map((_, i) => (
                      <div key={i} className="h-24 bg-gray-200 dark:bg-gray-700 rounded-lg animate-pulse"></div>
                    ))}
                  </div>
                ) : events.length > 0 ? (
                  <div className="space-y-4">
                    {events.map((event) => (
                      <Card key={event.id}>
                        <CardContent className="p-4">
                          <h4 className="font-medium mb-1">{event.title}</h4>
                          <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">
                            {event.description}
                          </p>
                          <div className="text-xs text-gray-500">
                            {new Date(event.start_date).toLocaleDateString('id-ID')}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <Card>
                    <CardContent className="p-6 text-center">
                      <p>Tidak ada kegiatan mendatang.</p>
                    </CardContent>
                  </Card>
                )}
              </section>
              
              {/* Quick Links Section */}
              <section>
                <Card>
                  <CardHeader>
                    <CardTitle>Akses Cepat</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Link to="/playground" className="block p-3 bg-robo-blue/10 rounded-md hover:bg-robo-blue/20 text-robo-blue">
                      <div className="flex items-center">
                        <Code className="h-4 w-4 mr-2" />
                        Coding Playground
                      </div>
                    </Link>
                    <Link to="/forum" className="block p-3 bg-robo-blue/10 rounded-md hover:bg-robo-blue/20 text-robo-blue">
                      <div className="flex items-center">
                        <BookOpen className="h-4 w-4 mr-2" />
                        Forum Diskusi
                      </div>
                    </Link>
                    <Link to="/gallery" className="block p-3 bg-robo-blue/10 rounded-md hover:bg-robo-blue/20 text-robo-blue">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2" />
                        Galeri Prestasi
                      </div>
                    </Link>
                    <Link to="/learn" className="block p-3 bg-robo-blue/10 rounded-md hover:bg-robo-blue/20 text-robo-blue">
                      <div className="flex items-center">
                        <BookOpen className="h-4 w-4 mr-2" />
                        Materi Belajar
                      </div>
                    </Link>
                  </CardContent>
                </Card>
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
