
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { 
  getCodeSnippets, 
  createCodeSnippet, 
  deleteCodeSnippet 
} from '@/services/api';
import { CodeSnippet as CodeSnippetType } from '@/types';
import Navigation from '@/components/Navigation';
import CodeEditor from '@/components/CodeEditor';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Trash } from 'lucide-react';
import { format } from 'date-fns';

const Playground = () => {
  const [snippets, setSnippets] = useState<CodeSnippetType[]>([]);
  const [selectedSnippet, setSelectedSnippet] = useState<CodeSnippetType | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadSnippets();
  }, []);

  const loadSnippets = () => {
    try {
      const allSnippets = getCodeSnippets();
      setSnippets(allSnippets);
    } catch (error) {
      console.error('Error loading code snippets:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteSnippet = (id: string) => {
    if (window.confirm('Are you sure you want to delete this code snippet?')) {
      deleteCodeSnippet(id);
      if (selectedSnippet?.id === id) {
        setSelectedSnippet(null);
      }
      loadSnippets();
    }
  };

  const filteredSnippets = snippets.filter(snippet =>
    snippet.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    snippet.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    snippet.language.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="flex-1 md:ml-64 pt-16 md:pt-0">
        <div className="p-6 max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">MicroPython Playground</h1>
          
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
            <div className="xl:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>
                    {selectedSnippet ? `Edit: ${selectedSnippet.title}` : 'New Code Snippet'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <CodeEditor initialSnippet={selectedSnippet} />
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Saved Snippets</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <Input
                      placeholder="Search snippets..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  
                  <Tabs defaultValue="python">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="python">Python</TabsTrigger>
                      <TabsTrigger value="arduino">Arduino</TabsTrigger>
                      <TabsTrigger value="cpp">C/C++</TabsTrigger>
                    </TabsList>
                    
                    {['python', 'arduino', 'cpp'].map(lang => (
                      <TabsContent key={lang} value={lang} className="space-y-2 mt-2">
                        {isLoading ? (
                          <div className="animate-pulse space-y-2">
                            <div className="h-12 bg-gray-200 dark:bg-gray-700 rounded"></div>
                            <div className="h-12 bg-gray-200 dark:bg-gray-700 rounded"></div>
                          </div>
                        ) : (
                          filteredSnippets
                            .filter(snippet => 
                              lang === 'cpp' 
                                ? (snippet.language === 'c' || snippet.language === 'cpp')
                                : snippet.language === lang
                            )
                            .map(snippet => (
                              <div
                                key={snippet.id}
                                className={`p-3 border rounded-md cursor-pointer flex justify-between items-center ${
                                  selectedSnippet?.id === snippet.id
                                    ? 'border-robo-blue bg-robo-blue/5'
                                    : 'hover:border-robo-blue/50'
                                }`}
                                onClick={() => setSelectedSnippet(snippet)}
                              >
                                <div className="flex-1 overflow-hidden">
                                  <h3 className="font-medium truncate">{snippet.title}</h3>
                                  <p className="text-xs text-gray-500 truncate">
                                    {format(new Date(snippet.updatedAt), "d MMM yyyy")}
                                  </p>
                                </div>
                                
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeleteSnippet(snippet.id);
                                  }}
                                  className="text-red-500 hover:text-red-700 hover:bg-red-50"
                                >
                                  <Trash className="h-4 w-4" />
                                </Button>
                              </div>
                            ))
                        )}
                        
                        {!isLoading && filteredSnippets.filter(snippet => 
                          lang === 'cpp' 
                            ? (snippet.language === 'c' || snippet.language === 'cpp')
                            : snippet.language === lang
                        ).length === 0 && (
                          <div className="text-center py-8">
                            <p className="text-gray-500 mb-2">No {lang} snippets found</p>
                            <Button
                              variant="outline"
                              onClick={() => {
                                setSelectedSnippet(null);
                                // Give focus to code editor (simulate)
                                document.querySelector('textarea')?.focus();
                              }}
                            >
                              Create New Snippet
                            </Button>
                          </div>
                        )}
                      </TabsContent>
                    ))}
                  </Tabs>
                </CardContent>
              </Card>
              
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Help & Resources</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium mb-1">MicroPython Documentation</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Learn about MicroPython for microcontrollers and embedded systems
                      </p>
                      <a 
                        href="https://docs.micropython.org/" 
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-robo-blue hover:underline text-sm"
                      >
                        Visit Documentation
                      </a>
                    </div>
                    
                    <div>
                      <h3 className="font-medium mb-1">Arduino Reference</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Arduino programming language reference and tutorials
                      </p>
                      <a 
                        href="https://www.arduino.cc/reference/en/" 
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-robo-blue hover:underline text-sm"
                      >
                        Visit Reference
                      </a>
                    </div>
                    
                    <div>
                      <h3 className="font-medium mb-1">Common Libraries</h3>
                      <ul className="list-disc list-inside text-sm text-gray-600 dark:text-gray-400 space-y-1">
                        <li>machine - Hardware control</li>
                        <li>utime - Time functions</li>
                        <li>network - Network interfaces</li>
                        <li>esp32 - ESP32 specific functions</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Playground;
