import { useState, useEffect } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/custom-client";
import Navigation from "@/components/Navigation";
import ProjectCard from "@/components/ProjectCard";
import RoleBasedAccess from "@/components/RoleBasedAccess";
import { ProjectMembersDisplay } from "@/components/Projects/ProjectMembersDisplay";
import { 
  Archive, 
  Clock, 
  Download, 
  File, 
  FilePlus, 
  Image, 
  Search, 
  Send, 
  Tag,
  Calendar,
  Video,
} from "lucide-react";
import { format, parseISO } from "date-fns";
import { id } from "date-fns/locale";

interface Profile {
  id: string;
  name: string | null;
  email: string | null;
  role: string | null;
}

interface Project {
  id: string;
  title: string;
  description: string | null;
  status: string;
  tags: string[] | null;
  leader_id: string | null;
  created_at: string;
  updated_at: string | null;
  leader_name?: string;
  media?: Media[];
}

interface Media {
  id: string;
  type: string;
  url: string;
  title: string | null;
  created_at: string;
  creator_id: string | null;
}

interface Comment {
  id: string;
  content: string;
  user_id: string;
  created_at: string;
  user_name?: string;
}

const ProjectsListView = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [filteredProjects, setFilteredProjects] = useState<Project[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadProjects();
  }, []);

  useEffect(() => {
    filterProjects();
  }, [searchQuery, statusFilter, projects]);

  const loadProjects = async () => {
    try {
      setIsLoading(true);
      
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      if (data) {
        setProjects(data);
        setFilteredProjects(data);
      }
    } catch (error) {
      console.error('Error loading projects:', error);
      toast.error('Gagal memuat data proyek');
    } finally {
      setIsLoading(false);
    }
  };

  const filterProjects = () => {
    let filtered = [...projects];
    
    if (searchQuery) {
      filtered = filtered.filter(
        project => 
          project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (project.description && project.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
          (project.tags && project.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase())))
      );
    }
    
    if (statusFilter !== "all") {
      filtered = filtered.filter(project => project.status === statusFilter);
    }
    
    setFilteredProjects(filtered);
  };

  const handleProjectClick = (id: string) => {
    navigate(`/projects/${id}`);
  };

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="flex-1 md:ml-64 pt-16 md:pt-0">
        <div className="p-6 max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
            <div>
              <h1 className="text-3xl font-bold">Repository Proyek</h1>
              <p className="text-gray-600 dark:text-gray-300 mt-1">
                Lihat dan kelola semua proyek robotik tim
              </p>
            </div>
            
            <Button className="bg-robo-blue hover:bg-robo-darkBlue" asChild>
              <Link to="/projects/new">
                <FilePlus className="mr-2 h-5 w-5" />
                Proyek Baru
              </Link>
            </Button>
          </div>
          
          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input 
                placeholder="Cari proyek..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select
              value={statusFilter}
              onValueChange={setStatusFilter}
            >
              <SelectTrigger className="w-full md:w-[180px]">
                <SelectValue placeholder="Filter status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Status</SelectItem>
                <SelectItem value="planning">Planning</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="archived">Archived</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((_, i) => (
                <div key={i} className="h-64 bg-gray-200 dark:bg-gray-700 rounded-lg animate-pulse"></div>
              ))}
            </div>
          ) : filteredProjects.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {filteredProjects.map((project) => (
                <div 
                  key={project.id} 
                  className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => handleProjectClick(project.id)}
                >
                  <div className="p-5">
                    <h3 className="text-xl font-medium mb-2 line-clamp-1">{project.title}</h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-4 text-sm line-clamp-3">
                      {project.description || "Tidak ada deskripsi"}
                    </p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.tags && project.tags.map((tag, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        project.status === 'planning' ? 'bg-amber-100 text-amber-600' :
                        project.status === 'in_progress' ? 'bg-blue-100 text-blue-600' :
                        project.status === 'completed' ? 'bg-green-100 text-green-600' :
                        'bg-gray-100 text-gray-600'
                      }`}>
                        {project.status === 'planning' && 'Planning'}
                        {project.status === 'in_progress' && 'In Progress'}
                        {project.status === 'completed' && 'Completed'}
                        {project.status === 'archived' && 'Archived'}
                      </span>
                      <span className="text-gray-500 flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        {format(parseISO(project.created_at), "dd MMM yyyy")}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center p-12 bg-white dark:bg-gray-800 rounded-lg">
              <div className="mb-4 text-gray-400">
                <Archive className="mx-auto h-12 w-12" />
              </div>
              <h3 className="text-lg font-medium mb-2">Tidak ada proyek ditemukan</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                {projects.length === 0
                  ? "Belum ada proyek dibuat. Mulai dengan membuat proyek baru!"
                  : "Tidak ada proyek yang sesuai dengan filter pencarian Anda."}
              </p>
              {projects.length === 0 && (
                <Button className="bg-blue-600 hover:bg-blue-700" asChild>
                  <Link to="/projects/new">
                    <FilePlus className="mr-2 h-5 w-5" />
                    Buat Proyek Baru
                  </Link>
                </Button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const ProjectDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [project, setProject] = useState<Project | null>(null);
  const [comment, setComment] = useState("");
  const [comments, setComments] = useState<Comment[]>([]);
  const [media, setMedia] = useState<Media[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<Profile | null>(null);
  const [fileToUpload, setFileToUpload] = useState<File | null>(null);
  const [fileTitle, setFileTitle] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const navigate = useNavigate();
  
  useEffect(() => {
    const fetchCurrentUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();
          
        if (!error && data) {
          setCurrentUser(data);
        }
      }
    };
    
    fetchCurrentUser();
  }, []);
  
  useEffect(() => {
    if (id) {
      loadProject(id);
      loadComments(id);
      loadMedia(id);
    }
  }, [id]);
  
  const loadProject = async (projectId: string) => {
    try {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('id', projectId)
        .single();
      
      if (error) throw error;
      
      if (data) {
        // Get leader name
        if (data.leader_id) {
          const { data: leaderData, error: leaderError } = await supabase
            .from('profiles')
            .select('name')
            .eq('id', data.leader_id)
            .single();
            
          if (!leaderError && leaderData) {
            setProject({
              ...data,
              leader_name: leaderData.name
            });
          } else {
            setProject(data);
          }
        } else {
          setProject(data);
        }
      }
    } catch (error) {
      console.error('Error loading project:', error);
      toast.error('Gagal memuat data proyek');
      navigate('/projects');
    } finally {
      setIsLoading(false);
    }
  };
  
  const loadComments = async (projectId: string) => {
    try {
      const { data, error } = await supabase
        .from('project_comments')
        .select('*')
        .eq('project_id', projectId)
        .order('created_at', { ascending: true });
      
      if (error) throw error;
      
      if (data) {
        // Get user names for comments
        const commentsWithUsernames = await Promise.all(data.map(async (comment) => {
          let userName = 'Unknown';
          
          if (comment.user_id) {
            const { data: userData, error: userError } = await supabase
              .from('profiles')
              .select('name')
              .eq('id', comment.user_id)
              .single();
              
            if (!userError && userData && userData.name) {
              userName = userData.name;
            }
          }
          
          return {
            ...comment,
            user_name: userName
          };
        }));
        
        setComments(commentsWithUsernames);
      }
    } catch (error) {
      console.error('Error loading comments:', error);
    }
  };
  
  const loadMedia = async (projectId: string) => {
    try {
      const { data, error } = await supabase
        .from('media')
        .select('*')
        .eq('related_id', projectId)
        .eq('related_type', 'project');
      
      if (error) throw error;
      
      if (data) {
        setMedia(data);
      }
    } catch (error) {
      console.error('Error loading media:', error);
    }
  };
  
  const handleAddComment = async () => {
    if (!id || !comment.trim() || !currentUser) {
      toast.error('Anda harus login untuk menambahkan komentar');
      return;
    }
    
    try {
      const newComment = {
        content: comment,
        project_id: id,
        user_id: currentUser.id
      };
      
      const { data, error } = await supabase
        .from('project_comments')
        .insert(newComment)
        .select();
      
      if (error) throw error;
      
      setComment("");
      loadComments(id);
      toast.success('Komentar berhasil ditambahkan');
    } catch (error) {
      console.error('Error adding comment:', error);
      toast.error('Gagal menambahkan komentar');
    }
  };

  const handleUploadMedia = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !fileToUpload || !fileTitle.trim() || !currentUser) {
      toast.error('Semua field wajib diisi');
      return;
    }
    
    setIsUploading(true);
    
    try {
      // Upload file to storage
      const fileExt = fileToUpload.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2, 15)}.${fileExt}`;
      const filePath = `projects/${id}/${fileName}`;
      
      // Determine type based on file extension
      let fileType = 'document';
      if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(fileExt || '')) {
        fileType = 'image';
      } else if (['mp4', 'webm', 'avi', 'mov'].includes(fileExt || '')) {
        fileType = 'video';
      }
      
      const { error: uploadError } = await supabase.storage
        .from('uploads')
        .upload(filePath, fileToUpload);
      
      if (uploadError) throw uploadError;
      
      // Get the public URL
      const { data: urlData } = supabase.storage
        .from('uploads')
        .getPublicUrl(filePath);
      
      // Save media metadata to database
      const newMedia = {
        type: fileType,
        url: urlData.publicUrl,
        title: fileTitle,
        related_id: id,
        related_type: 'project',
        creator_id: currentUser.id
      };
      
      const { error: dbError } = await supabase
        .from('media')
        .insert(newMedia);
      
      if (dbError) throw dbError;
      
      toast.success('Media berhasil diunggah');
      setFileToUpload(null);
      setFileTitle("");
      loadMedia(id);
      
    } catch (error) {
      console.error('Error uploading media:', error);
      toast.error('Gagal mengunggah media');
    } finally {
      setIsUploading(false);
    }
  };
  
  const handleStatusChange = async (newStatus: string) => {
    if (!id || !project) return;
    
    try {
      const { error } = await supabase
        .from('projects')
        .update({ 
          status: newStatus,
          updated_at: new Date().toISOString()
        })
        .eq('id', id);
      
      if (error) throw error;
      
      setProject({
        ...project,
        status: newStatus,
        updated_at: new Date().toISOString()
      });
      
      toast.success('Status proyek berhasil diperbarui');
    } catch (error) {
      console.error('Error updating project status:', error);
      toast.error('Gagal memperbarui status proyek');
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
        <Navigation />
        <div className="flex-1 md:ml-64 pt-16 md:pt-0 p-6 flex items-center justify-center">
          <div className="animate-pulse">Loading project...</div>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
        <Navigation />
        <div className="flex-1 md:ml-64 pt-16 md:pt-0 p-6">
          <div className="text-center">
            <h2 className="text-xl">Proyek tidak ditemukan</h2>
            <Button className="mt-4" asChild>
              <Link to="/projects">Kembali ke daftar proyek</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="flex-1 md:ml-64 pt-16 md:pt-0">
        <div className="p-6 max-w-7xl mx-auto">
          {/* Project Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Link to="/projects" className="text-gray-500 hover:text-blue-600">
                  Projects
                </Link>
                <span className="text-gray-500">/</span>
                <span className="text-gray-800 dark:text-gray-200 font-medium truncate">
                  {project.title}
                </span>
              </div>
              
              <h1 className="text-3xl font-bold">{project.title}</h1>
            </div>
            
            <div className="flex items-center gap-2">
              {currentUser && (currentUser.id === project.leader_id || currentUser.role === 'admin') && (
                <Button variant="outline" asChild>
                  <Link to={`/projects/${project.id}/edit`}>
                    Edit Proyek
                  </Link>
                </Button>
              )}
              <Select
                value={project.status}
                onValueChange={(value) => handleStatusChange(value)}
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="planning">Planning</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="archived">Archived</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Left Column - Project Details */}
            <div className="md:col-span-2">
              {/* Description */}
              <div className="bg-white dark:bg-gray-800 rounded-lg p-6 mb-6 shadow-sm">
                <h2 className="text-xl font-bold mb-4">Deskripsi Proyek</h2>
                <p className="text-gray-700 dark:text-gray-300">
                  {project.description || "Tidak ada deskripsi untuk proyek ini."}
                </p>
                
                <div className="mt-6 flex flex-wrap gap-2">
                  {project.tags && project.tags.map((tag, index) => (
                    <Badge key={index} variant="outline" className="flex items-center gap-1">
                      <Tag className="h-3 w-3" />
                      {tag}
                    </Badge>
                  ))}
                </div>
                
                <div className="mt-6 flex items-center text-sm text-gray-500">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>Terakhir diperbarui: {project.updated_at ? format(parseISO(project.updated_at), "d MMM yyyy, HH:mm") : format(parseISO(project.created_at), "d MMM yyyy, HH:mm")}</span>
                </div>
              </div>
              
              {/* Media Section */}
              <div className="bg-white dark:bg-gray-800 rounded-lg p-6 mb-6 shadow-sm">
                <h2 className="text-xl font-bold mb-4">Media & Dokumentasi</h2>
                
                {media.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                    {media.map((item) => (
                      <div key={item.id} className="border rounded-lg overflow-hidden">
                        {item.type === 'image' ? (
                          <div className="aspect-video relative group">
                            <img 
                              src={item.url} 
                              alt={item.title || ''} 
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center">
                              <a 
                                href={item.url} 
                                target="_blank" 
                                rel="noopener noreferrer" 
                                className="text-white bg-blue-600 rounded-full p-2"
                              >
                                <Image className="h-5 w-5" />
                              </a>
                            </div>
                          </div>
                        ) : item.type === 'video' ? (
                          <div className="aspect-video relative group">
                            <video 
                              src={item.url} 
                              controls 
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center">
                              <a 
                                href={item.url} 
                                target="_blank" 
                                rel="noopener noreferrer" 
                                className="text-white bg-blue-600 rounded-full p-2"
                              >
                                <Video className="h-5 w-5" />
                              </a>
                            </div>
                          </div>
                        ) : (
                          <div className="aspect-video flex items-center justify-center bg-gray-100 dark:bg-gray-800 group relative">
                            <File className="h-12 w-12 text-gray-400" />
                            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                              <a 
                                href={item.url} 
                                target="_blank" 
                                rel="noopener noreferrer" 
                                className="text-white bg-blue-600 rounded-full p-2"
                              >
                                <Download className="h-5 w-5" />
                              </a>
                            </div>
                          </div>
                        )}
                        <div className="p-3">
                          <h4 className="font-medium">{item.title}</h4>
                          <p className="text-sm text-gray-500">
                            Diunggah {format(parseISO(item.created_at), "d MMM yyyy")}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 mb-6">Belum ada media yang diunggah</p>
                )}
                
                {currentUser ? (
                  <form onSubmit={handleUploadMedia} className="border-t pt-4">
                    <h4 className="font-medium mb-3">Unggah Media Baru</h4>
                    <div className="grid grid-cols-1 gap-4">
                      <Input
                        type="text"
                        placeholder="Judul Media"
                        value={fileTitle}
                        onChange={(e) => setFileTitle(e.target.value)}
                        required
                      />
                      
                      <Input
                        type="file"
                        onChange={(e) => setFileToUpload(e.target.files?.[0] || null)}
                        required
                      />
                      
                      <Button 
                        type="submit" 
                        className="w-full md:w-auto" 
                        disabled={isUploading || !fileToUpload || !fileTitle.trim()}
                      >
                        {isUploading ? "Mengunggah..." : "Unggah Media"}
                      </Button>
                    </div>
                  </form>
                ) : (
                  <p className="text-sm text-gray-500 border-t pt-4">
                    Login untuk mengunggah media
                  </p>
                )}
              </div>
              
              {/* Comments Section */}
              <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
                <h2 className="text-xl font-bold mb-4">Komentar & Diskusi</h2>
                
                <div className="space-y-4 mb-6">
                  {comments.length > 0 ? (
                    comments.map((comment) => (
                      <div key={comment.id} className="flex gap-3">
                        <div className="w-8 h-8 bg-blue-600 rounded-full text-white flex items-center justify-center">
                          {comment.user_name ? comment.user_name.charAt(0) : '?'}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-baseline gap-2">
                            <span className="font-medium">{comment.user_name}</span>
                            <span className="text-xs text-gray-500">
                              {format(parseISO(comment.created_at), "d MMM yyyy, HH:mm")}
                            </span>
                          </div>
                          <p className="text-gray-700 dark:text-gray-300 mt-1">
                            {comment.content}
                          </p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500">Belum ada komentar</p>
                  )}
                </div>
                
                {currentUser ? (
                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-blue-600 rounded-full text-white flex items-center justify-center">
                      {currentUser.name ? currentUser.name.charAt(0) : '?'}
                    </div>
                    <div className="flex-1">
                      <Textarea
                        placeholder="Tambahkan komentar..."
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        className="mb-2"
                      />
                      <Button 
                        onClick={handleAddComment}
                        className="flex items-center gap-1"
                        disabled={!comment.trim()}
                      >
                        <Send className="h-4 w-4" />
                        Kirim
                      </Button>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-gray-500">
                    Login untuk menambahkan komentar
                  </p>
                )}
              </div>
            </div>
            
            {/* Right Column - Project Info */}
            <div>
              {/* Project Details */}
              <div className="bg-white dark:bg-gray-800 rounded-lg p-6 mb-6 shadow-sm">
                <h2 className="text-lg font-bold mb-4">Informasi Proyek</h2>
                
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Status</h3>
                    <div className="mt-1">
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                        project.status === 'planning' ? 'bg-amber-100 text-amber-600' :
                        project.status === 'in_progress' ? 'bg-blue-100 text-blue-600' :
                        project.status === 'completed' ? 'bg-green-100 text-green-600' :
                        'bg-gray-100 text-gray-600'
                      }`}>
                        {project.status === 'planning' && 'Planning'}
                        {project.status === 'in_progress' && 'In Progress'}
                        {project.status === 'completed' && 'Completed'}
                        {project.status === 'archived' && 'Archived'}
                      </span>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Ketua Proyek</h3>
                    <div className="mt-1 flex items-center gap-2">
                      <div className="w-6 h-6 bg-blue-700 rounded-full text-white flex items-center justify-center text-xs">
                        {project.leader_name ? project.leader_name.charAt(0) : '?'}
                      </div>
                      <span>{project.leader_name || "Belum ada leader"}</span>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Tanggal Dibuat</h3>
                    <div className="mt-1 flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-gray-500" />
                      <span>{format(parseISO(project.created_at), "d MMMM yyyy")}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Project Members Section */}
              <ProjectMembersDisplay 
                projectId={project.id}
                projectLeaderId={project.leader_id || undefined}
                projectLeaderName={project.leader_name || undefined}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const NewProject = () => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState("");
  const [division, setDivision] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentUser, setCurrentUser] = useState<Profile | null>(null);
  const navigate = useNavigate();
  
  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session) {
          const { data, error } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', session.user.id)
            .single();
            
          if (!error && data) {
            setCurrentUser(data);
          }
        } else {
          // Redirect to login without any waiting
          navigate('/auth', { replace: true });
        }
      } catch (error) {
        console.error('Error fetching user:', error);
        toast.error('Tidak dapat memverifikasi sesi Anda');
      }
    };
    
    fetchCurrentUser();
  }, [navigate]);
  
  const handleAddTag = () => {
    if (tagInput && !tags.includes(tagInput)) {
      setTags([...tags, tagInput]);
      setTagInput("");
    }
  };
  
  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentUser) {
      toast.error('Anda harus login untuk membuat proyek');
      navigate('/auth', { replace: true });
      return;
    }
    
    if (!title || !description) {
      toast.error('Judul dan deskripsi wajib diisi');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const newProject = {
        title,
        description,
        status: 'planning',
        tags,
        leader_id: currentUser.id
      };
      
      const { data, error } = await supabase
        .from('projects')
        .insert(newProject)
        .select();
      
      if (error) throw error;
      
      toast.success('Proyek berhasil dibuat');
      
      // Use replace: true for immediate navigation without history stacking
      navigate('/projects', { replace: true });
      
    } catch (error) {
      console.error('Error creating project:', error);
      toast.error('Gagal membuat proyek');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (!currentUser) {
    return (
      <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
        <Navigation />
        <div className="flex-1 md:ml-64 pt-16 md:pt-0 p-6 flex items-center justify-center">
          <div className="animate-pulse">Loading...</div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="flex-1 md:ml-64 pt-16 md:pt-0">
        <div className="p-6 max-w-3xl mx-auto">
          <div className="mb-8">
            <Link to="/projects" className="text-blue-600 hover:underline flex items-center gap-1">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M10 12L6 8L10 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Kembali ke proyek
            </Link>
            <h1 className="text-3xl font-bold mt-2">Buat Proyek Baru</h1>
            <p className="text-gray-600 dark:text-gray-300 mt-1">
              Mulai proyek robotik baru untuk tim Anda
            </p>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
            <form onSubmit={handleSubmit}>
              <div className="space-y-6">
                <div className="space-y-2">
                  <label htmlFor="title" className="block text-sm font-medium">
                    Judul Proyek <span className="text-red-500">*</span>
                  </label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Masukkan judul proyek"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="description" className="block text-sm font-medium">
                    Deskripsi Proyek <span className="text-red-500">*</span>
                  </label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Jelaskan tentang proyek ini..."
                    rows={5}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="division" className="block text-sm font-medium">
                    Divisi
                  </label>
                  <Select value={division || ''} onValueChange={setDivision}>
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih divisi" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Tidak ada divisi</SelectItem>
                      <SelectItem value="programming">Programming</SelectItem>
                      <SelectItem value="mechanical">Mechanical</SelectItem>
                      <SelectItem value="electrical">Electrical</SelectItem>
                      <SelectItem value="web">Web Development</SelectItem>
                      <SelectItem value="mobile">Mobile Development</SelectItem>
                      <SelectItem value="data">Data Science</SelectItem>
                      <SelectItem value="ai">Artificial Intelligence</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="tags" className="block text-sm font-medium">
                    Tag Proyek
                  </label>
                  <div className="flex gap-2">
                    <Input
                      id="tags"
                      value={tagInput}
                      onChange={(e) => setTagInput(e.target.value)}
                      placeholder="Arduino, ESP32, IoT, dll"
                    />
                    <Button 
                      type="button" 
                      variant="outline"
                      onClick={handleAddTag}
                      className="whitespace-nowrap"
                    >
                      Tambah Tag
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {tags.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="px-3 py-1 flex items-center gap-2">
                        {tag}
                        <button
                          type="button"
                          onClick={() => handleRemoveTag(tag)}
                          className="text-gray-400 hover:text-gray-600"
                        >
                          &times;
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="pt-4 border-t">
                  <Button
                    type="submit"
                    className="w-full md:w-auto bg-blue-600 hover:bg-blue-700"
                    disabled={isSubmitting || !title || !description}
                  >
                    {isSubmitting ? "Menyimpan..." : "Buat Proyek"}
                  </Button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

const Projects = () => {
  const { id } = useParams<{ id: string }>();
  
  return (
    <RoleBasedAccess 
      allowedRoles={['admin', 'member']}
      fallbackMessage="Hanya member yang dapat mengakses proyek. Silakan daftar menjadi member terlebih dahulu."
    >
      {id === 'new' ? (
        <NewProject />
      ) : id ? (
        <ProjectDetail />
      ) : (
        <ProjectsListView />
      )}
    </RoleBasedAccess>
  );
};

export default Projects;
