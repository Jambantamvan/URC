
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import Navigation from '@/components/Navigation';
import RoleBasedAccess from '@/components/RoleBasedAccess';
import AddMaterialForm from '@/components/LearningMaterials/AddMaterialForm';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { format, parseISO } from 'date-fns';
import { id } from 'date-fns/locale';
import { 
  Search, 
  BookOpen, 
  File, 
  Video, 
  Link as LinkIcon, 
  Download, 
  ExternalLink,
  AlertCircle
} from 'lucide-react';

interface LearningMaterial {
  id: string;
  title: string;
  description: string | null;
  type: string;
  level: string;
  content: string | null;
  url: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string | null;
  creator_name?: string;
}

const Learn = () => {
  const [materials, setMaterials] = useState<LearningMaterial[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [levelFilter, setLevelFilter] = useState('all');
  
  useEffect(() => {
    fetchMaterials();
  }, []);
  
  const fetchMaterials = async () => {
    try {
      setIsLoading(true);
      
      const { data, error } = await supabase
        .from('learning_materials')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) {
        throw error;
      }
      
      if (data) {
        // Get creator names for each material
        const materialsWithCreatorNames = await Promise.all(data.map(async material => {
          let creatorName = 'Unknown';
          
          if (material.created_by) {
            const { data: userData, error: userError } = await supabase
              .from('profiles')
              .select('name')
              .eq('id', material.created_by)
              .single();
              
            if (!userError && userData && userData.name) {
              creatorName = userData.name;
            }
          }
          
          return {
            ...material,
            creator_name: creatorName
          };
        }));
        
        setMaterials(materialsWithCreatorNames);
      }
      
    } catch (error) {
      console.error('Error fetching materials:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const getTypeIcon = (type: string, className = 'h-5 w-5') => {
    switch (type) {
      case 'document':
        return <File className={`${className} text-blue-500`} />;
      case 'video':
        return <Video className={`${className} text-red-500`} />;
      case 'link':
        return <LinkIcon className={`${className} text-green-500`} />;
      default:
        return <BookOpen className={`${className} text-gray-500`} />;
    }
  };
  
  const getLevelBadge = (level: string) => {
    switch (level) {
      case 'beginner':
        return <Badge variant="outline" className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">Pemula</Badge>;
      case 'intermediate':
        return <Badge variant="outline" className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200">Menengah</Badge>;
      case 'advanced':
        return <Badge variant="outline" className="bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200">Lanjutan</Badge>;
      default:
        return <Badge variant="outline">{level}</Badge>;
    }
  };
  
  const formatDate = (dateStr: string) => {
    try {
      const date = parseISO(dateStr);
      return format(date, 'dd MMM yyyy', { locale: id });
    } catch (e) {
      return dateStr;
    }
  };
  
  const filteredMaterials = materials.filter(material => {
    let typeMatch = typeFilter === 'all' || material.type === typeFilter;
    let levelMatch = levelFilter === 'all' || material.level === levelFilter;
    let searchMatch = 
      material.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (material.description && material.description.toLowerCase().includes(searchQuery.toLowerCase()));
      
    return typeMatch && levelMatch && searchMatch;
  });
  
  return (
    <RoleBasedAccess 
      allowedRoles={['admin', 'member']}
      fallbackMessage="Hanya member yang dapat mengakses materi pembelajaran. Silakan daftar menjadi member terlebih dahulu."
    >
      <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
        <Navigation />
        
        <div className="flex-1 md:ml-64 pt-16 md:pt-0">
          <div className="p-6 max-w-7xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold">Materi Pembelajaran</h1>
              <p className="text-gray-600 dark:text-gray-300 mt-1">
                Pelajari dasar-dasar robotik melalui materi pembelajaran berikut
              </p>
            </div>
            
            <AddMaterialForm onMaterialAdded={fetchMaterials} />
            
            {/* ... keep existing code */}
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input 
                  placeholder="Cari materi..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-2 sm:flex">
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-full sm:w-[140px]">
                    <SelectValue placeholder="Tipe" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Tipe</SelectItem>
                    <SelectItem value="document">Dokumen</SelectItem>
                    <SelectItem value="video">Video</SelectItem>
                    <SelectItem value="link">Link</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select value={levelFilter} onValueChange={setLevelFilter}>
                  <SelectTrigger className="w-full sm:w-[140px]">
                    <SelectValue placeholder="Level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Level</SelectItem>
                    <SelectItem value="beginner">Pemula</SelectItem>
                    <SelectItem value="intermediate">Menengah</SelectItem>
                    <SelectItem value="advanced">Lanjutan</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {/* ... keep existing code (materials display) */}
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="h-52 bg-gray-200 dark:bg-gray-700 rounded-lg animate-pulse"></div>
                ))}
              </div>
            ) : filteredMaterials.length === 0 ? (
              <div className="text-center p-12 bg-white dark:bg-gray-800 rounded-lg shadow">
                <AlertCircle className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium mb-2">Tidak ada materi ditemukan</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  {materials.length === 0 
                    ? "Belum ada materi pembelajaran yang ditambahkan" 
                    : "Tidak ada materi yang sesuai dengan pencarian Anda"}
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredMaterials.map((material) => (
                  <Card key={material.id} className="overflow-hidden">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          {getTypeIcon(material.type)}
                          {getLevelBadge(material.level)}
                        </div>
                      </div>
                      <CardTitle className="mt-2">{material.title}</CardTitle>
                      <CardDescription>
                        Ditambahkan oleh {material.creator_name} pada {formatDate(material.created_at)}
                      </CardDescription>
                    </CardHeader>
                    
                    <CardContent>
                      <p className="text-gray-700 dark:text-gray-300 line-clamp-2">
                        {material.description || "Tidak ada deskripsi"}
                      </p>
                      
                      {material.content && (
                        <div className="mt-4 text-sm text-gray-500 dark:text-gray-400 border-t pt-3">
                          <p className="line-clamp-2">{material.content}</p>
                        </div>
                      )}
                    </CardContent>
                    
                    <CardFooter className="border-t pt-4">
                      {material.url ? (
                        <Button className="w-full flex items-center justify-center gap-2" asChild>
                          <a href={material.url} target="_blank" rel="noopener noreferrer">
                            {material.type === 'document' ? (
                              <>
                                <Download className="h-4 w-4" />
                                <span>Unduh Dokumen</span>
                              </>
                            ) : (
                              <>
                                <ExternalLink className="h-4 w-4" />
                                <span>Buka {material.type === 'video' ? 'Video' : 'Link'}</span>
                              </>
                            )}
                          </a>
                        </Button>
                      ) : (
                        <p className="text-sm text-gray-500 w-full text-center">
                          Tidak ada tautan tersedia
                        </p>
                      )}
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </RoleBasedAccess>
  );
};

export default Learn;
