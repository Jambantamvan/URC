
import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import Navigation from '@/components/Navigation';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { CalendarPlus } from 'lucide-react';
import {
  Dialog,
} from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { Card } from '@/components/ui/card';
import { AttendanceEvent, AttendanceRecord, Profile } from '@/types/supabase';

// Import refactored components
import { AttendanceCard } from '@/components/Attendance/AttendanceCard';
import { AttendanceForm } from '@/components/Attendance/AttendanceForm';
import { AbsenceForm } from '@/components/Attendance/AbsenceForm';
import { AttendanceCodeForm } from '@/components/Attendance/AttendanceCodeForm';

const Attendance = () => {
  const [loading, setLoading] = useState(true);
  const [attendances, setAttendances] = useState<AttendanceEvent[]>([]);
  const [currentUser, setCurrentUser] = useState<Profile | null>(null);
  const [attendanceCode, setAttendanceCode] = useState('');
  const [selectedAttendance, setSelectedAttendance] = useState<AttendanceEvent | null>(null);
  const [absenceReason, setAbsenceReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isAbsenceDialogOpen, setIsAbsenceDialogOpen] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  
  // Form states for adding/editing attendance
  const [formTitle, setFormTitle] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formDate, setFormDate] = useState('');
  const [formStartTime, setFormStartTime] = useState('');
  const [formEndTime, setFormEndTime] = useState('');
  const [formVerificationCode, setFormVerificationCode] = useState('');
  
  useEffect(() => {
    fetchCurrentUser();
  }, []);

  useEffect(() => {
    if (currentUser) {
      fetchAttendances();
    }
  }, [currentUser]);
  
  const fetchCurrentUser = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session) {
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();
          
        if (error) {
          console.error('Error fetching user profile:', error);
          toast.error('Gagal memuat data pengguna');
        } else {
          setCurrentUser(data as Profile);
        }
      } else {
        setCurrentUser(null);
        setLoading(false);
      }
    } catch (error) {
      console.error('Error in fetchCurrentUser:', error);
      setLoading(false);
    }
  };
  
  const fetchAttendances = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('attendances')
        .select('*')
        .order('date', { ascending: false });
      
      if (error) {
        console.error('Error fetching attendances:', error);
        toast.error('Gagal memuat data absensi');
        setAttendances([]);
        return;
      }
      
      // For each attendance, fetch the creator name
      const enhancedAttendances = await Promise.all(
        data.map(async (attendance: any) => {
          let creatorName = 'Unknown';
          
          if (attendance.created_by) {
            const { data: userData, error: userError } = await supabase
              .from('profiles')
              .select('name')
              .eq('id', attendance.created_by)
              .single();
              
            if (!userError && userData) {
              creatorName = userData.name || 'Unknown';
            }
          }
          
          // Check if user has already attended
          const { data: records } = await supabase
            .from('attendance_records')
            .select('*')
            .eq('attendance_id', attendance.id)
            .eq('user_id', currentUser?.id || '')
            .maybeSingle();
            
          return {
            ...attendance,
            creator_name: creatorName,
            user_attended: !!records
          } as AttendanceEvent;
        })
      );
      
      setAttendances(enhancedAttendances);
    } catch (error) {
      console.error('Error in fetchAttendances:', error);
      toast.error('Terjadi kesalahan saat memuat data absensi');
    } finally {
      setLoading(false);
    }
  };
  
  const handleAttendance = async () => {
    if (!currentUser) {
      toast.error('Anda harus login untuk isi absensi');
      return;
    }
    
    if (!attendanceCode.trim()) {
      toast.error('Silakan masukkan kode verifikasi');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Find the attendance with matching code
      const attendance = attendances.find(
        a => a.verification_code.toLowerCase() === attendanceCode.toLowerCase()
      );
      
      if (!attendance) {
        toast.error('Kode verifikasi tidak valid');
        return;
      }
      
      // Check if user has already attended
      const { data: existingRecord } = await supabase
        .from('attendance_records')
        .select('*')
        .eq('attendance_id', attendance.id)
        .eq('user_id', currentUser.id)
        .maybeSingle();
        
      if (existingRecord) {
        toast.error('Anda sudah mengisi absensi untuk kegiatan ini');
        return;
      }
      
      // Mark attendance
      const { error } = await supabase
        .from('attendance_records')
        .insert({
          attendance_id: attendance.id,
          user_id: currentUser.id,
          status: 'present'
        });
        
      if (error) {
        console.error('Error marking attendance:', error);
        toast.error('Gagal mengisi absensi');
        return;
      }
      
      toast.success('Absensi berhasil diisi');
      setAttendanceCode('');
      setIsDialogOpen(false);
      fetchAttendances();
      
    } catch (error) {
      console.error('Error in handleAttendance:', error);
      toast.error('Terjadi kesalahan saat mengisi absensi');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleAbsence = async () => {
    if (!currentUser) {
      toast.error('Anda harus login untuk mencatat ketidakhadiran');
      return;
    }
    
    if (!selectedAttendance) {
      toast.error('Tidak ada absensi yang dipilih');
      return;
    }
    
    if (!absenceReason.trim()) {
      toast.error('Silakan berikan alasan ketidakhadiran Anda');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Check if user has already recorded attendance
      const { data: existingRecord } = await supabase
        .from('attendance_records')
        .select('*')
        .eq('attendance_id', selectedAttendance.id)
        .eq('user_id', currentUser.id)
        .maybeSingle();
        
      if (existingRecord) {
        toast.error('Anda sudah mencatat kehadiran/ketidakhadiran untuk kegiatan ini');
        return;
      }
      
      // Record absence
      const { error } = await supabase
        .from('attendance_records')
        .insert({
          attendance_id: selectedAttendance.id,
          user_id: currentUser.id,
          status: 'absent',
          reason: absenceReason
        });
        
      if (error) {
        console.error('Error marking absence:', error);
        toast.error('Gagal mencatat ketidakhadiran');
        return;
      }
      
      toast.success('Ketidakhadiran berhasil dicatat');
      setAbsenceReason('');
      setSelectedAttendance(null);
      setIsAbsenceDialogOpen(false);
      fetchAttendances();
      
    } catch (error) {
      console.error('Error in handleAbsence:', error);
      toast.error('Terjadi kesalahan saat mencatat ketidakhadiran');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const generateVerificationCode = () => {
    const characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    setFormVerificationCode(result);
  };
  
  const handleAddAttendance = async () => {
    if (!currentUser) {
      toast.error('Anda harus login untuk menambahkan absensi');
      return;
    }
    
    if (!formTitle.trim() || !formDate || !formVerificationCode.trim()) {
      toast.error('Judul, tanggal, dan kode verifikasi wajib diisi');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Combine date and time to create datetime strings
      const startDateTime = formStartTime ? `${formDate}T${formStartTime}:00` : null;
      const endDateTime = formEndTime ? `${formDate}T${formEndTime}:00` : null;
      
      const newAttendance = {
        title: formTitle,
        description: formDescription,
        date: `${formDate}T00:00:00`,
        start_time: startDateTime,
        end_time: endDateTime,
        verification_code: formVerificationCode,
        created_by: currentUser.id
      };
      
      const { error } = await supabase
        .from('attendances')
        .insert(newAttendance);
        
      if (error) {
        console.error('Error adding attendance:', error);
        toast.error('Gagal menambahkan absensi');
        return;
      }
      
      toast.success('Absensi berhasil ditambahkan');
      resetForm();
      setIsAddDialogOpen(false);
      fetchAttendances();
      
    } catch (error) {
      console.error('Error in handleAddAttendance:', error);
      toast.error('Terjadi kesalahan saat menambahkan absensi');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleEditAttendance = async () => {
    if (!currentUser) {
      toast.error('Anda harus login untuk mengedit absensi');
      return;
    }
    
    if (!selectedAttendance) {
      toast.error('Tidak ada absensi yang dipilih untuk diedit');
      return;
    }
    
    if (!formTitle.trim() || !formDate || !formVerificationCode.trim()) {
      toast.error('Judul, tanggal, dan kode verifikasi wajib diisi');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Combine date and time to create datetime strings
      const startDateTime = formStartTime ? `${formDate}T${formStartTime}:00` : null;
      const endDateTime = formEndTime ? `${formDate}T${formEndTime}:00` : null;
      
      const updatedAttendance = {
        title: formTitle,
        description: formDescription,
        date: `${formDate}T00:00:00`,
        start_time: startDateTime,
        end_time: endDateTime,
        verification_code: formVerificationCode
      };
      
      const { error } = await supabase
        .from('attendances')
        .update(updatedAttendance)
        .eq('id', selectedAttendance.id);
        
      if (error) {
        console.error('Error updating attendance:', error);
        toast.error('Gagal memperbarui absensi');
        return;
      }
      
      toast.success('Absensi berhasil diperbarui');
      resetForm();
      setIsEditDialogOpen(false);
      fetchAttendances();
      
    } catch (error) {
      console.error('Error in handleEditAttendance:', error);
      toast.error('Terjadi kesalahan saat memperbarui absensi');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const prepareEditAttendance = (attendance: AttendanceEvent) => {
    setSelectedAttendance(attendance);
    setFormTitle(attendance.title);
    setFormDescription(attendance.description || '');
    
    // Extract date from the existing date field
    const dateOnly = attendance.date.split('T')[0];
    setFormDate(dateOnly);
    
    // Extract start and end times if they exist
    if (attendance.start_time) {
      const startTime = new Date(attendance.start_time).toTimeString().slice(0, 5);
      setFormStartTime(startTime);
    }
    if (attendance.end_time) {
      const endTime = new Date(attendance.end_time).toTimeString().slice(0, 5);
      setFormEndTime(endTime);
    }
    
    setFormVerificationCode(attendance.verification_code);
    setIsEditDialogOpen(true);
  };
  
  const resetForm = () => {
    setFormTitle('');
    setFormDescription('');
    setFormDate('');
    setFormStartTime('');
    setFormEndTime('');
    setFormVerificationCode('');
    setSelectedAttendance(null);
  };
  
  const isAdmin = currentUser?.role === 'admin';
  
  return (
    <div className="flex min-h-screen bg-background">
      <Navigation />
      
      <div className="flex-1 md:ml-64 pt-16 md:pt-0">
        <div className="container mx-auto px-4 pt-6 pb-10">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold">Kehadiran</h1>
            <p className="text-muted-foreground">
              Absensi untuk acara dan pertemuan URC Robotics
            </p>
          </div>
          
          <div className="mt-4 md:mt-0 space-x-2 flex flex-wrap gap-2">
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <Button onClick={() => setIsDialogOpen(true)}>
                Isi Absensi
              </Button>
              {isDialogOpen && (
                <AttendanceCodeForm
                  attendanceCode={attendanceCode}
                  isSubmitting={isSubmitting}
                  setAttendanceCode={setAttendanceCode}
                  onCancel={() => setIsDialogOpen(false)}
                  onSubmit={handleAttendance}
                />
              )}
            </Dialog>
            
            {isAdmin && (
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(true)}>
                  <CalendarPlus className="mr-2 h-4 w-4" />
                  Buat Absensi
                </Button>
                {isAddDialogOpen && (
                  <AttendanceForm
                    isEdit={false}
                    formTitle={formTitle}
                    formDescription={formDescription}
                    formDate={formDate}
                    formStartTime={formStartTime}
                    formEndTime={formEndTime}
                    formVerificationCode={formVerificationCode}
                    isSubmitting={isSubmitting}
                    generateVerificationCode={generateVerificationCode}
                    setFormTitle={setFormTitle}
                    setFormDescription={setFormDescription}
                    setFormDate={setFormDate}
                    setFormStartTime={setFormStartTime}
                    setFormEndTime={setFormEndTime}
                    setFormVerificationCode={setFormVerificationCode}
                    onCancel={() => setIsAddDialogOpen(false)}
                    onSubmit={handleAddAttendance}
                  />
                )}
              </Dialog>
            )}
          </div>
        </div>
        
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="h-[200px] w-full" />
              </Card>
            ))}
          </div>
        ) : attendances.length === 0 ? (
          <div className="text-center p-12 bg-muted/30 rounded-lg border">
            <h2 className="text-xl font-medium mb-2">Tidak ada data absensi</h2>
            <p className="text-muted-foreground">
              Belum ada absensi yang tersedia saat ini
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {attendances.map((attendance) => (
              <AttendanceCard
                key={attendance.id}
                attendance={attendance}
                isAdmin={isAdmin}
                onEdit={prepareEditAttendance}
                onMarkPresent={() => setIsDialogOpen(true)}
                onMarkAbsent={(attendance) => {
                  setSelectedAttendance(attendance);
                  setIsAbsenceDialogOpen(true);
                }}
              />
            ))}
          </div>
        )}
        </div>
      </div>
      
      {/* Absence Dialog */}
      <Dialog open={isAbsenceDialogOpen} onOpenChange={setIsAbsenceDialogOpen}>
        {isAbsenceDialogOpen && (
          <AbsenceForm
            absenceReason={absenceReason}
            isSubmitting={isSubmitting}
            setAbsenceReason={setAbsenceReason}
            onCancel={() => setIsAbsenceDialogOpen(false)}
            onSubmit={handleAbsence}
            attendanceTitle={selectedAttendance?.title}
          />
        )}
      </Dialog>
      
      {/* Edit Attendance Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        {isEditDialogOpen && (
          <AttendanceForm
            isEdit={true}
            formTitle={formTitle}
            formDescription={formDescription}
            formDate={formDate}
            formStartTime={formStartTime}
            formEndTime={formEndTime}
            formVerificationCode={formVerificationCode}
            isSubmitting={isSubmitting}
            generateVerificationCode={generateVerificationCode}
            setFormTitle={setFormTitle}
            setFormDescription={setFormDescription}
            setFormDate={setFormDate}
            setFormStartTime={setFormStartTime}
            setFormEndTime={setFormEndTime}
            setFormVerificationCode={setFormVerificationCode}
            onCancel={() => setIsEditDialogOpen(false)}
            onSubmit={handleEditAttendance}
          />
        )}
      </Dialog>
    </div>
  );
};

export default Attendance;
