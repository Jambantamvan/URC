import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import { useAuth } from '@/contexts/AuthContext';
import Navigation from '@/components/Navigation';
import ProfileHeader from '@/components/Profile/ProfileHeader';
import ProfileTabs from '@/components/Profile/ProfileTabs';
import ProfileSkeleton from '@/components/Profile/ProfileSkeleton';
import ProfileNotFound from '@/components/Profile/ProfileNotFound';

const Profile = () => {
  const { profile: authProfile, isLoading: authLoading } = useAuth();
  const [projects, setProjects] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadUserProjects = async () => {
      if (!authProfile) {
        setIsLoading(false);
        return;
      }

      try {
        // Get projects where user is the leader
        const { data: leaderProjects, error: leaderError } = await supabase
          .from('projects')
          .select('*')
          .eq('leader_id', authProfile.id);

        // Get projects where user is a member
        const { data: memberProjects, error: memberError } = await supabase
          .from('project_members')
          .select(`
            project_id,
            projects (*)
          `)
          .eq('user_id', authProfile.id);

        if (leaderError) throw leaderError;
        if (memberError) throw memberError;

        const allProjects = [
          ...(leaderProjects || []),
          ...(memberProjects?.map(pm => pm.projects).filter(Boolean) || [])
        ];

        // Remove duplicates based on project id
        const uniqueProjects = allProjects.filter((project, index, self) =>
          index === self.findIndex(p => p.id === project.id)
        );

        setProjects(uniqueProjects);
      } catch (error) {
        console.error('Error loading user projects:', error);
      } finally {
        setIsLoading(false);
      }
    };

    if (!authLoading) {
      loadUserProjects();
    }
  }, [authProfile, authLoading]);

  if (authLoading || isLoading) {
    return <ProfileSkeleton />;
  }

  if (!authProfile) {
    return (
      <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
        <Navigation />
        <ProfileNotFound />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="flex-1 md:ml-64 pt-16 md:pt-0">
        <div className="p-6 max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">Profil Anggota</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Left Column - Profile Info */}
            <ProfileHeader user={authProfile} />
            
            {/* Right Column - Profile Tabs */}
            <div className="md:col-span-2">
              <ProfileTabs userProjects={projects} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
