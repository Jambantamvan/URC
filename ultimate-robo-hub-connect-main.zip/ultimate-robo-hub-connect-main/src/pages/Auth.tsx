
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AuthForm from '@/components/Auth/AuthForm';
import { useAuth } from '@/contexts/AuthContext';

const Auth = () => {
  const { user, isLoading, signOut } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user && !isLoading) {
      navigate('/', { replace: true });
    }
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-900">
        <div className="text-center">
          <div className="animate-pulse text-lg mb-4">Loading...</div>
          <div className="space-y-2">
            <button 
              onClick={() => window.location.reload()} 
              className="block w-full px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
            >
              Refresh Page
            </button>
            <button 
              onClick={async () => {
                await signOut();
                window.location.reload();
              }} 
              className="block w-full px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
            >
              Force Logout & Refresh
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-900 p-4">
      <div className="w-full max-w-md text-center mb-6">
        <h1 className="text-3xl font-bold text-robo-blue mb-2">Ultimate Robo Club</h1>
        <p className="text-gray-600 dark:text-gray-300">
          Masuk atau daftar untuk mengakses semua fitur
        </p>
      </div>
      
      <AuthForm />
      
      <div className="mt-8 text-center text-sm text-gray-500 dark:text-gray-400">
        <p>Ultimate Robo Club © {new Date().getFullYear()}</p>
      </div>
    </div>
  );
};

export default Auth;
