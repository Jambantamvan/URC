
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/custom-client';
import Navigation from '@/components/Navigation';
import RoleBasedAccess from '@/components/RoleBasedAccess';
import { ProjectFormEnhanced } from '@/components/Projects/ProjectFormEnhanced';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

const NewProject = () => {
  const { profile } = useAuth();
  
  return (
    <RoleBasedAccess 
      allowedRoles={['admin', 'member']}
      fallbackMessage="Hanya member yang dapat membuat proyek. Silakan daftar menjadi member terlebih dahulu."
    >
      <div className="min-h-screen bg-background">
        <Navigation />
        
        <div className="flex-1 md:ml-64 pt-16 md:pt-0">
          <div className="container mx-auto px-4 pt-6 pb-10">
            <h1 className="text-3xl font-bold mb-6">Buat Proyek Baru</h1>
            
            {profile && <ProjectFormEnhanced currentUser={profile} />}
          </div>
        </div>
      </div>
    </RoleBasedAccess>
  );
};

export default NewProject;
