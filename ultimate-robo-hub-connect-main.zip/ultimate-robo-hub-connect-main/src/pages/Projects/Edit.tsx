import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/custom-client';
import Navigation from '@/components/Navigation';
import RoleBasedAccess from '@/components/RoleBasedAccess';
import { ProjectFormEnhanced } from '@/components/Projects/ProjectFormEnhanced';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { Project } from '@/types/supabase';

const EditProject = () => {
  const { id } = useParams<{ id: string }>();
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [project, setProject] = useState<Project | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (id) {
      loadProject();
    }
  }, [id]);

  const loadProject = async () => {
    if (!id) return;

    try {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;

      // Check if user has permission to edit
      if (profile && data) {
        if (data.leader_id !== profile.id && profile.role !== 'admin') {
          toast.error('Anda tidak memiliki izin untuk mengedit proyek ini');
          navigate('/projects');
          return;
        }
        setProject(data);
      }
    } catch (error) {
      console.error('Error loading project:', error);
      toast.error('Gagal memuat data proyek');
      navigate('/projects');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="flex-1 md:ml-64 pt-16 md:pt-0">
          <div className="container mx-auto px-4 pt-6 pb-10 flex items-center justify-center">
            <div className="animate-pulse">Memuat proyek...</div>
          </div>
        </div>
      </div>
    );
  }

  if (!project || !profile) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="flex-1 md:ml-64 pt-16 md:pt-0">
          <div className="container mx-auto px-4 pt-6 pb-10">
            <p className="text-center text-muted-foreground">Proyek tidak ditemukan</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <RoleBasedAccess 
      allowedRoles={['admin', 'member']}
      fallbackMessage="Hanya member yang dapat mengedit proyek. Silakan daftar menjadi member terlebih dahulu."
    >
      <div className="min-h-screen bg-background">
        <Navigation />
        
        <div className="flex-1 md:ml-64 pt-16 md:pt-0">
          <div className="container mx-auto px-4 pt-6 pb-10">
            <h1 className="text-3xl font-bold mb-6">Edit Proyek</h1>
            
            <ProjectFormEnhanced 
              currentUser={profile}
              project={project}
              isEditing={true}
            />
          </div>
        </div>
      </div>
    </RoleBasedAccess>
  );
};

export default EditProject;