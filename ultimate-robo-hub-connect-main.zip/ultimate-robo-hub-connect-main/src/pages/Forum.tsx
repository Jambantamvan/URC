import { useState, useEffect } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/custom-client";
import Navigation from "@/components/Navigation";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { 
  MessageSquare, 
  Plus, 
  Search, 
  Send, 
  Clock,
  MessageCircle,
  ArrowLeft,
  Trash
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ForumThread {
  id: string;
  title: string;
  content: string;
  division: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
  creator_name?: string;
  replies_count?: number;
}

interface ForumReply {
  id: string;
  thread_id: string;
  user_id: string | null;
  content: string;
  created_at: string;
  updated_at: string;
  user_name?: string;
}

const ForumListView = () => {
  const [threads, setThreads] = useState<ForumThread[]>([]);
  const [filteredThreads, setFilteredThreads] = useState<ForumThread[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [divisionFilter, setDivisionFilter] = useState("all");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadThreads();
  }, []);

  useEffect(() => {
    filterThreads();
  }, [searchQuery, divisionFilter, threads]);

  const loadThreads = async () => {
    try {
      setIsLoading(true);
      
      // Fetch threads
      const { data: threadsData, error } = await supabase
        .from('forum_threads')
        .select('*')
        .order('updated_at', { ascending: false });
      
      if (error) throw error;
      
      if (threadsData) {
        // Get creator names and replies count for each thread
        const threadsWithDetails = await Promise.all(threadsData.map(async (thread) => {
          let creatorName = 'Unknown';
          let repliesCount = 0;
          
          // Get creator name
          if (thread.created_by) {
            const { data: userData, error: userError } = await supabase
              .from('profiles')
              .select('name')
              .eq('id', thread.created_by)
              .single();
              
            if (!userError && userData && userData.name) {
              creatorName = userData.name;
            }
          }
          
          // Get replies count
          const { count, error: countError } = await supabase
            .from('forum_replies')
            .select('id', { count: 'exact' })
            .eq('thread_id', thread.id);
            
          if (!countError) {
            repliesCount = count || 0;
          }
          
          return {
            ...thread,
            creator_name: creatorName,
            replies_count: repliesCount
          };
        }));
        
        setThreads(threadsWithDetails);
        setFilteredThreads(threadsWithDetails);
      }
    } catch (error) {
      console.error('Error loading threads:', error);
      toast.error('Gagal memuat forum diskusi');
    } finally {
      setIsLoading(false);
    }
  };

  const filterThreads = () => {
    let filtered = [...threads];
    
    if (searchQuery) {
      filtered = filtered.filter(
        thread => 
          thread.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          thread.content.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    if (divisionFilter !== "all") {
      filtered = filtered.filter(thread => thread.division === divisionFilter);
    }
    
    setFilteredThreads(filtered);
  };

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="flex-1 md:ml-64 pt-16 md:pt-0">
        <div className="p-6 max-w-5xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
            <div>
              <h1 className="text-3xl font-bold">Forum Diskusi</h1>
              <p className="text-gray-600 dark:text-gray-300 mt-1">
                Diskusi dan berbagi ide dengan sesama anggota ekskul
              </p>
            </div>
            
            <Button className="bg-robo-blue hover:bg-robo-darkBlue" asChild>
              <Link to="/forum/new">
                <Plus className="mr-2 h-5 w-5" />
                Thread Baru
              </Link>
            </Button>
          </div>
          
          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input 
                placeholder="Cari diskusi..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select
              value={divisionFilter}
              onValueChange={setDivisionFilter}
            >
              <SelectTrigger className="w-full md:w-[180px]">
                <SelectValue placeholder="Filter divisi" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Divisi</SelectItem>
                <SelectItem value="Programming">Programming</SelectItem>
                <SelectItem value="Mekanik">Mekanik</SelectItem>
                <SelectItem value="Elektronik">Elektronik</SelectItem>
                <SelectItem value="AI">AI</SelectItem>
                <SelectItem value="IoT">IoT</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3, 4, 5].map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 dark:bg-gray-700 rounded-lg animate-pulse"></div>
              ))}
            </div>
          ) : filteredThreads.length > 0 ? (
            <div className="space-y-4">
              {filteredThreads.map((thread) => (
                <Link key={thread.id} to={`/forum/${thread.id}`}>
                  <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-slate-200 dark:border-slate-700 hover:border-robo-blue dark:hover:border-robo-blue transition-colors">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold text-lg">{thread.title}</h3>
                      {thread.division && (
                        <Badge variant="outline" className="text-xs">
                          {thread.division}
                        </Badge>
                      )}
                    </div>
                    <p className="text-gray-600 dark:text-gray-300 line-clamp-2 mb-4">{thread.content}</p>
                    <div className="flex justify-between items-center text-xs text-gray-500">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          <span>{format(new Date(thread.updated_at), "d MMM yyyy, HH:mm")}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <MessageCircle className="h-3 w-3" />
                          <span>{thread.replies_count || 0} balasan</span>
                        </div>
                      </div>
                      <span className="text-gray-400">oleh {thread.creator_name}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center p-12 bg-white dark:bg-gray-800 rounded-lg">
              <div className="mb-4 text-robo-blue">
                <MessageSquare className="mx-auto h-12 w-12" />
              </div>
              <h3 className="text-lg font-medium mb-2">Tidak ada diskusi ditemukan</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                {threads.length === 0
                  ? "Belum ada diskusi yang dibuat. Mulai diskusi pertamamu!"
                  : "Tidak ada diskusi yang sesuai dengan filter pencarian Anda."}
              </p>
              {threads.length === 0 && (
                <Button className="bg-robo-blue hover:bg-robo-darkBlue" asChild>
                  <Link to="/forum/new">
                    <Plus className="mr-2 h-5 w-5" />
                    Mulai Diskusi
                  </Link>
                </Button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const ThreadDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [thread, setThread] = useState<ForumThread | null>(null);
  const [replies, setReplies] = useState<ForumReply[]>([]);
  const [reply, setReply] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  
  useEffect(() => {
    if (id) {
      loadThread(id);
      loadReplies(id);
    }
  }, [id]);
  
  const loadThread = async (threadId: string) => {
    try {
      const { data, error } = await supabase
        .from('forum_threads')
        .select('*')
        .eq('id', threadId)
        .single();
      
      if (error) throw error;
      
      if (data) {
        // Get creator name
        let creatorName = 'Unknown';
        if (data.created_by) {
          const { data: userData, error: userError } = await supabase
            .from('profiles')
            .select('name')
            .eq('id', data.created_by)
            .single();
            
          if (!userError && userData && userData.name) {
            creatorName = userData.name;
          }
        }
        
        setThread({
          ...data,
          creator_name: creatorName
        });
      }
    } catch (error) {
      console.error('Error loading thread:', error);
      toast.error('Thread tidak ditemukan');
      navigate('/forum');
    } finally {
      setIsLoading(false);
    }
  };
  
  const loadReplies = async (threadId: string) => {
    try {
      const { data, error } = await supabase
        .from('forum_replies')
        .select('*')
        .eq('thread_id', threadId)
        .order('created_at', { ascending: true });
      
      if (error) throw error;
      
      if (data) {
        // Get user names for replies
        const repliesWithUsernames = await Promise.all(data.map(async (reply) => {
          let userName = 'Unknown';
          
          if (reply.user_id) {
            const { data: userData, error: userError } = await supabase
              .from('profiles')
              .select('name')
              .eq('id', reply.user_id)
              .single();
              
            if (!userError && userData && userData.name) {
              userName = userData.name;
            }
          }
          
          return {
            ...reply,
            user_name: userName
          };
        }));
        
        setReplies(repliesWithUsernames);
      }
    } catch (error) {
      console.error('Error loading replies:', error);
    }
  };
  
  const handleAddReply = async () => {
    if (!id || !reply.trim() || !user) {
      toast.error('Anda harus login untuk menambahkan balasan');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const newReply = {
        thread_id: id,
        user_id: user.id,
        content: reply.trim()
      };
      
      const { error } = await supabase
        .from('forum_replies')
        .insert(newReply);
      
      if (error) throw error;
      
      // Update thread's updated_at
      await supabase
        .from('forum_threads')
        .update({ updated_at: new Date().toISOString() })
        .eq('id', id);
      
      setReply("");
      loadReplies(id);
      toast.success('Balasan berhasil ditambahkan');
      
    } catch (error) {
      console.error('Error adding reply:', error);
      toast.error('Gagal menambahkan balasan');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleDeleteThread = async () => {
    if (!id || !thread) return;
    
    if (window.confirm("Apakah Anda yakin ingin menghapus diskusi ini?")) {
      try {
        // Delete replies first
        await supabase
          .from('forum_replies')
          .delete()
          .eq('thread_id', id);
        
        // Delete thread
        const { error } = await supabase
          .from('forum_threads')
          .delete()
          .eq('id', id);
        
        if (error) throw error;
        
        toast.success('Thread berhasil dihapus');
        navigate('/forum');
        
      } catch (error) {
        console.error('Error deleting thread:', error);
        toast.error('Gagal menghapus thread');
      }
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
        <Navigation />
        <div className="flex-1 md:ml-64 pt-16 md:pt-0 p-6 flex items-center justify-center">
          <div className="animate-pulse">Loading thread...</div>
        </div>
      </div>
    );
  }
  
  if (!thread) {
    return (
      <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
        <Navigation />
        <div className="flex-1 md:ml-64 pt-16 md:pt-0 p-6 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-bold mb-2">Diskusi tidak ditemukan</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">Diskusi ini mungkin telah dihapus atau tidak ada</p>
            <Link to="/forum" className="text-robo-blue hover:underline">
              Kembali ke Forum
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="flex-1 md:ml-64 pt-16 md:pt-0">
        <div className="p-6 max-w-5xl mx-auto">
          <Link to="/forum" className="flex items-center text-robo-blue hover:underline mb-4">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Kembali ke Forum
          </Link>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm mb-8 overflow-hidden">
            <div className="p-6 border-b">
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-2">
                    <h1 className="text-2xl font-bold">{thread.title}</h1>
                    {thread.division && (
                      <Badge variant="outline">{thread.division}</Badge>
                    )}
                  </div>
                  <div className="text-sm text-gray-500 mt-1">
                    Diposting pada {format(new Date(thread.created_at), "d MMM yyyy, HH:mm")} oleh {thread.creator_name}
                  </div>
                </div>
                
                {(user?.id === thread.created_by || profile?.role === 'admin') && (
                  <Button 
                    variant="destructive" 
                    size="icon" 
                    onClick={handleDeleteThread}
                  >
                    <Trash className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
            
            <div className="p-6">
              <p className="text-gray-700 dark:text-gray-300 whitespace-pre-line">{thread.content}</p>
            </div>
          </div>
          
          <h2 className="text-xl font-bold mb-4">Diskusi ({replies.length})</h2>
          
          <div className="space-y-6 mb-8">
            {replies.length > 0 ? (
              replies.map((reply) => (
                <div key={reply.id} className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-slate-200 dark:border-slate-700">
                  <div className="flex gap-3">
                    <div className="w-10 h-10 bg-robo-blue rounded-full text-white flex items-center justify-center">
                      {reply.user_name?.charAt(0) || 'U'}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-baseline gap-2">
                        <span className="font-medium">{reply.user_name}</span>
                        <span className="text-xs text-gray-500">
                          {format(new Date(reply.created_at), "d MMM yyyy, HH:mm")}
                        </span>
                      </div>
                      <p className="text-gray-700 dark:text-gray-300 mt-2 whitespace-pre-line">{reply.content}</p>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-white dark:bg-gray-800 rounded-lg p-6 text-center">
                <p className="text-gray-500">Belum ada balasan. Jadilah yang pertama!</p>
              </div>
            )}
          </div>
          
          {user ? (
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-slate-200 dark:border-slate-700">
              <h2 className="text-xl font-bold mb-4">Tambah Balasan</h2>
              
              <div className="flex gap-3">
                <div className="w-10 h-10 bg-robo-blue rounded-full text-white flex items-center justify-center">
                  {profile?.name?.charAt(0) || 'U'}
                </div>
                <div className="flex-1">
                  <Textarea
                    placeholder="Tulis balasan Anda..."
                    value={reply}
                    onChange={(e) => setReply(e.target.value)}
                    className="mb-3"
                    rows={4}
                  />
                  <Button 
                    onClick={handleAddReply}
                    className="flex items-center gap-2"
                    disabled={!reply.trim() || isSubmitting}
                  >
                    <Send className="h-4 w-4" />
                    {isSubmitting ? 'Mengirim...' : 'Kirim Balasan'}
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-slate-200 dark:border-slate-700 text-center">
              <p className="text-gray-500 mb-4">Anda harus login untuk menambahkan balasan</p>
              <Button asChild>
                <Link to="/auth">Login / Register</Link>
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const NewThread = () => {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [division, setDivision] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast.error('Anda harus login untuk membuat thread');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const threadData = {
        title: title.trim(),
        content: content.trim(),
        division: division === "none" ? null : division,
        created_by: user.id
      };
      
      const { data, error } = await supabase
        .from('forum_threads')
        .insert(threadData)
        .select()
        .single();
      
      if (error) throw error;
      
      if (data) {
        toast.success('Thread berhasil dibuat');
        navigate(`/forum/${data.id}`);
      }
      
    } catch (error) {
      console.error("Error creating thread:", error);
      toast.error('Gagal membuat thread');
      setIsSubmitting(false);
    }
  };
  
  if (!user) {
    return (
      <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
        <Navigation />
        <div className="flex-1 md:ml-64 pt-16 md:pt-0 p-6 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-bold mb-2">Login Diperlukan</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">Anda harus login untuk membuat thread baru</p>
            <Button asChild>
              <Link to="/auth">Login / Register</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="flex-1 md:ml-64 pt-16 md:pt-0">
        <div className="p-6 max-w-3xl mx-auto">
          <div className="mb-8">
            <Link to="/forum" className="text-robo-blue hover:underline flex items-center gap-1">
              <ArrowLeft className="h-4 w-4" />
              Kembali ke forum
            </Link>
            <h1 className="text-3xl font-bold mt-2">Buat Thread Baru</h1>
            <p className="text-gray-600 dark:text-gray-300 mt-1">
              Mulai diskusi baru dengan anggota ekskul lainnya
            </p>
          </div>
          
          <Card>
            <CardContent className="pt-6">
              <form onSubmit={handleSubmit}>
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label htmlFor="title" className="block text-sm font-medium">
                      Judul Thread <span className="text-red-500">*</span>
                    </label>
                    <Input
                      id="title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="Masukkan judul thread"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="division" className="block text-sm font-medium">
                      Divisi (Opsional)
                    </label>
                    <Select
                      value={division || "none"}
                      onValueChange={(value) => setDivision(value === "none" ? null : value)}
                    >
                      <SelectTrigger id="division">
                        <SelectValue placeholder="Pilih divisi" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Umum</SelectItem>
                        <SelectItem value="Programming">Programming</SelectItem>
                        <SelectItem value="Mekanik">Mekanik</SelectItem>
                        <SelectItem value="Elektronik">Elektronik</SelectItem>
                        <SelectItem value="AI">AI</SelectItem>
                        <SelectItem value="IoT">IoT</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="content" className="block text-sm font-medium">
                      Konten <span className="text-red-500">*</span>
                    </label>
                    <Textarea
                      id="content"
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                      placeholder="Tulis konten thread Anda..."
                      rows={8}
                      required
                    />
                  </div>
                  
                  <div className="pt-4 border-t">
                    <Button
                      type="submit"
                      className="w-full md:w-auto bg-robo-blue hover:bg-robo-darkBlue"
                      disabled={isSubmitting || !title.trim() || !content.trim()}
                    >
                      {isSubmitting ? "Menyimpan..." : "Buat Thread"}
                    </Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

const Forum = () => {
  const { id } = useParams<{ id: string }>();
  
  if (id === 'new') {
    return <NewThread />;
  } else if (id) {
    return <ThreadDetail />;
  } else {
    return <ForumListView />;
  }
};

export default Forum;