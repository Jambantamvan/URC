
import React from 'react';
import Navigation from '@/components/Navigation';
import EnhancedRegistrationForm from '@/components/Registration/EnhancedRegistrationForm';

const Registration = () => {
  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="flex-1 md:ml-64 pt-16 md:pt-0">
        <div className="p-6 max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">Pendaftaran Anggota</h1>
          <EnhancedRegistrationForm />
        </div>
      </div>
    </div>
  );
};

export default Registration;
