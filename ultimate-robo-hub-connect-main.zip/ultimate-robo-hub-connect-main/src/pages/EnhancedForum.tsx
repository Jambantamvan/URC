import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link, useLocation } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/custom-client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { MessageCircle, Plus, User, Calendar, ArrowLeft, Trash2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import Navigation from '@/components/Navigation';
import RoleBasedAccess from '@/components/RoleBasedAccess';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { UserMentions, renderMentions } from '@/components/Forum/UserMentions';
import { UserPresenceManager } from '@/components/Forum/UserPresence';
import { MentionTextarea } from '@/components/Forum/MentionTextarea';

interface ForumThread {
  id: string;
  title: string;
  content: string;
  division: string | null;
  created_by: string | null;
  created_at: string | null;
  updated_at: string | null;
  creator_name?: string;
  replies_count?: number;
}

interface ForumReply {
  id: string;
  thread_id: string;
  user_id: string;
  content: string;
  created_at: string;
  updated_at: string;
  user_name?: string;
}

const ForumListView = () => {
  const [threads, setThreads] = useState<ForumThread[]>([]);
  const [filteredThreads, setFilteredThreads] = useState<ForumThread[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [divisionFilter, setDivisionFilter] = useState("all");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadThreads();
  }, []);

  useEffect(() => {
    filterThreads();
  }, [searchQuery, divisionFilter, threads]);

  const loadThreads = async () => {
    try {
      setIsLoading(true);
      
      const { data: threadsData, error } = await supabase
        .from('forum_threads')
        .select('*')
        .order('updated_at', { ascending: false });
      
      if (error) throw error;
      
      if (threadsData) {
        const threadsWithDetails = await Promise.all(threadsData.map(async (thread) => {
          let creatorName = 'Unknown';
          let repliesCount = 0;
          
          if (thread.created_by) {
            const { data: userData, error: userError } = await supabase
              .from('profiles')
              .select('name')
              .eq('id', thread.created_by)
              .maybeSingle();
              
            if (!userError && userData && userData.name) {
              creatorName = userData.name;
            }
          }
          
          const { count, error: countError } = await supabase
            .from('forum_replies')
            .select('id', { count: 'exact' })
            .eq('thread_id', thread.id);
            
          if (!countError) {
            repliesCount = count || 0;
          }
          
          return {
            ...thread,
            creator_name: creatorName,
            replies_count: repliesCount
          };
        }));
        
        setThreads(threadsWithDetails);
        setFilteredThreads(threadsWithDetails);
      }
    } catch (error) {
      console.error('Error loading threads:', error);
      toast.error('Gagal memuat data forum');
    } finally {
      setIsLoading(false);
    }
  };

  const filterThreads = () => {
    let filtered = threads;
    
    if (searchQuery.trim()) {
      filtered = filtered.filter(thread =>
        thread.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        thread.content.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    if (divisionFilter !== "all") {
      filtered = filtered.filter(thread => thread.division === divisionFilter);
    }
    
    setFilteredThreads(filtered);
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading) {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="flex">
          <div className="flex-1 md:ml-64 pt-16 md:pt-0">
            <div className="container mx-auto px-4 py-6">
              <div className="animate-pulse space-y-4">
                <div className="h-8 bg-muted rounded w-1/4"></div>
                <div className="h-32 bg-muted rounded"></div>
                <div className="h-32 bg-muted rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="flex">
        <div className="flex-1 md:ml-64 pt-16 md:pt-0">
          <div className="container mx-auto px-4 py-6">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-3xl font-bold">Forum Diskusi</h1>
              <Link to="/forum/new">
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Thread Baru
                </Button>
              </Link>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              <div className="lg:col-span-3">
                <div className="mb-6 flex flex-col sm:flex-row gap-4">
                  <Input
                    placeholder="Cari thread..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="flex-1"
                  />
                  <Select value={divisionFilter} onValueChange={setDivisionFilter}>
                    <SelectTrigger className="w-full sm:w-48">
                      <SelectValue placeholder="Filter divisi" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Divisi</SelectItem>
                      <SelectItem value="web">Web Development</SelectItem>
                      <SelectItem value="mobile">Mobile Development</SelectItem>
                      <SelectItem value="ui_ux">UI/UX Design</SelectItem>
                      <SelectItem value="data">Data Science</SelectItem>
                      <SelectItem value="ai">Artificial Intelligence</SelectItem>
                      <SelectItem value="game">Game Development</SelectItem>
                      <SelectItem value="iot">Internet of Things</SelectItem>
                      <SelectItem value="robotics">Robotics</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-4">
                  {filteredThreads.length > 0 ? (
                    filteredThreads.map((thread) => (
                      <Card key={thread.id} className="hover:shadow-md transition-shadow">
                        <CardHeader>
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <CardTitle className="text-lg mb-2">
                                <Link 
                                  to={`/forum/thread/${thread.id}`}
                                  className="hover:text-primary transition-colors"
                                >
                                  {thread.title}
                                </Link>
                              </CardTitle>
                              <CardDescription className="line-clamp-2">
                                {renderMentions(thread.content)}
                              </CardDescription>
                            </div>
                            {thread.division && (
                              <Badge variant="secondary" className="ml-4">
                                {thread.division}
                              </Badge>
                            )}
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="flex items-center justify-between text-sm text-muted-foreground">
                            <div className="flex items-center gap-4">
                              <div className="flex items-center gap-1">
                                <User className="w-4 h-4" />
                                {thread.creator_name}
                              </div>
                              <div className="flex items-center gap-1">
                                <MessageCircle className="w-4 h-4" />
                                {thread.replies_count || 0} balasan
                              </div>
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {formatDate(thread.updated_at)}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <Card>
                      <CardContent className="text-center py-12">
                        <MessageCircle className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                        <p className="text-muted-foreground">
                          {searchQuery || divisionFilter !== "all" 
                            ? "Tidak ada thread yang sesuai dengan filter"
                            : "Belum ada thread di forum. Jadilah yang pertama membuat thread!"
                          }
                        </p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </div>

              <div className="lg:col-span-1">
                <UserPresenceManager showMembersList={true} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const ThreadDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [thread, setThread] = useState<ForumThread | null>(null);
  const [replies, setReplies] = useState<ForumReply[]>([]);
  const [reply, setReply] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  
  useEffect(() => {
    if (id) {
      loadThread(id);
      loadReplies(id);
    }
  }, [id]);
  
  const loadThread = async (threadId: string) => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('forum_threads')
        .select('*')
        .eq('id', threadId)
        .maybeSingle();
      
      if (error) throw error;
      
      if (data) {
        let creatorName = 'Unknown';
        if (data.created_by) {
          const { data: userData, error: userError } = await supabase
            .from('profiles')
            .select('name')
            .eq('id', data.created_by)
            .maybeSingle();
            
          if (!userError && userData && userData.name) {
            creatorName = userData.name;
          }
        }
        
        setThread({
          ...data,
          creator_name: creatorName
        });
      } else {
        toast.error('Thread tidak ditemukan');
        navigate('/forum');
      }
    } catch (error) {
      console.error('Error loading thread:', error);
      toast.error('Thread tidak ditemukan');
      navigate('/forum');
    }
  };
  
  const loadReplies = async (threadId: string) => {
    try {
      const { data, error } = await supabase
        .from('forum_replies')
        .select('*')
        .eq('thread_id', threadId)
        .order('created_at', { ascending: true });
      
      if (error) throw error;
      
      if (data) {
        const repliesWithUserNames = await Promise.all(data.map(async (reply) => {
          let userName = 'Unknown';
          if (reply.user_id) {
            const { data: userData, error: userError } = await supabase
              .from('profiles')
              .select('name')
              .eq('id', reply.user_id)
              .maybeSingle();
              
            if (!userError && userData && userData.name) {
              userName = userData.name;
            }
          }
          
          return {
            ...reply,
            user_name: userName
          };
        }));
        
        setReplies(repliesWithUserNames);
      }
    } catch (error) {
      console.error('Error loading replies:', error);
    } finally {
      setIsLoading(false);
    }
  };

const handleMention = async (userId: string) => {
    console.log('User mentioned:', userId);
    
    try {
      // Create mention record in database
      await supabase
        .from('forum_mentions')
        .insert({
          mentioned_user_id: userId,
          mentioner_user_id: user?.id,
          thread_id: id,
          reply_id: null // This will be set to the reply ID when available
        });
    } catch (error) {
      console.error('Error creating mention:', error);
    }
  };
  
  const submitReply = async () => {
    if (!user || !reply.trim() || !id) return;
    
    setIsSubmitting(true);
    
    try {
      const { data, error } = await supabase
        .from('forum_replies')
        .insert({
          thread_id: id,
          user_id: user.id,
          content: reply.trim()
        })
        .select()
        .maybeSingle();
      
      if (error) throw error;
      
      // Process mentions in the reply content and create mention records
      const mentionMatches = reply.match(/@(\w+)/g);
      if (mentionMatches && data) {
        for (const mention of mentionMatches) {
          const username = mention.substring(1); // Remove @ symbol
          try {
            // Find user by name
            const { data: userData } = await supabase
              .from('profiles')
              .select('id')
              .eq('name', username)
              .maybeSingle();
            
            if (userData) {
              await supabase
                .from('forum_mentions')
                .insert({
                  mentioned_user_id: userData.id,
                  mentioner_user_id: user.id,
                  thread_id: id,
                  reply_id: data.id
                });
            }
          } catch (mentionError) {
            console.error('Error creating mention for', username, mentionError);
          }
        }
      }
      
      toast.success('Balasan berhasil ditambahkan');
      setReply("");
      loadReplies(id);
      
      await supabase
        .from('forum_threads')
        .update({ updated_at: new Date().toISOString() })
        .eq('id', id);
        
    } catch (error) {
      console.error('Error submitting reply:', error);
      toast.error('Gagal menambahkan balasan');
    } finally {
      setIsSubmitting(false);
    }
  };

  const deleteThread = async () => {
    if (!user || !thread || !id) return;
    
    try {
      const { error } = await supabase
        .from('forum_threads')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      
      toast.success('Thread berhasil dihapus');
      navigate('/forum');
    } catch (error) {
      console.error('Error deleting thread:', error);
      toast.error('Gagal menghapus thread');
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading) {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="flex">
          <div className="flex-1 md:ml-64 pt-16 md:pt-0">
            <div className="container mx-auto px-4 py-6">
              <div className="animate-pulse space-y-4">
                <div className="h-8 bg-muted rounded w-1/4"></div>
                <div className="h-32 bg-muted rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!thread) {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="flex">
          <div className="flex-1 md:ml-64 pt-16 md:pt-0">
            <div className="container mx-auto px-4 py-6">
              <p className="text-center text-muted-foreground">Thread tidak ditemukan</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="flex">
        <div className="flex-1 md:ml-64 pt-16 md:pt-0">
          <div className="container mx-auto px-4 py-6">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              <div className="lg:col-span-3">
                <div className="mb-6">
                  <Button variant="ghost" asChild className="mb-4">
                    <Link to="/forum">
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Kembali ke Forum
                    </Link>
                  </Button>

                  <Card>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <CardTitle className="text-2xl mb-2">{thread.title}</CardTitle>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <User className="w-4 h-4" />
                              {thread.creator_name}
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {formatDate(thread.created_at!)}
                            </div>
                            {thread.division && (
                              <Badge variant="secondary">{thread.division}</Badge>
                            )}
                          </div>
                        </div>
                        {(user?.id === thread.created_by || profile?.role === 'admin') && (
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="sm" className="text-destructive">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Hapus Thread</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Apakah Anda yakin ingin menghapus thread ini? Tindakan ini tidak dapat dibatalkan.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Batal</AlertDialogCancel>
                                <AlertDialogAction onClick={deleteThread} className="bg-destructive text-destructive-foreground">
                                  Hapus
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="prose max-w-none">
                        {renderMentions(thread.content)}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="space-y-4 mb-6">
                  {replies.map((replyItem) => {
                    const isMentioned = replyItem.content.includes(`@${profile?.name}`);
                    return (
                      <Card 
                        key={replyItem.id} 
                        className={isMentioned ? 'border-yellow-500 bg-yellow-50 dark:bg-yellow-950/20' : ''}
                      >
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 text-sm">
                              <User className="w-4 h-4" />
                              <span className="font-medium">{replyItem.user_name}</span>
                              <span className="text-muted-foreground">•</span>
                              <span className="text-muted-foreground">{formatDate(replyItem.created_at)}</span>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pt-0">
                          <div className="prose max-w-none">
                            {renderMentions(replyItem.content)}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>

                {user && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Tambah Balasan</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <MentionTextarea
                        value={reply}
                        onChange={setReply}
                        onMention={handleMention}
                      />
                      <div className="flex justify-end">
                        <Button onClick={submitReply} disabled={isSubmitting || !reply.trim()}>
                          {isSubmitting ? 'Mengirim...' : 'Kirim Balasan'}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {!user && (
                  <Card>
                    <CardContent className="text-center py-8">
                      <p className="text-muted-foreground mb-4">
                        Masuk untuk ikut berdiskusi di forum
                      </p>
                      <Button asChild>
                        <Link to="/auth">Masuk</Link>
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </div>

              <div className="lg:col-span-1">
                <UserPresenceManager showMembersList={true} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const NewThread = () => {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [division, setDivision] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleMention = async (userId: string) => {
    console.log('User mentioned in new thread:', userId);
    // For new threads, we'll handle mentions after thread creation
  };

  const submitThread = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast.error('Anda harus login untuk membuat thread');
      return;
    }
    
    if (!title.trim() || !content.trim()) {
      toast.error('Judul dan konten harus diisi');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const { data, error } = await supabase
        .from('forum_threads')
        .insert({
          title: title.trim(),
          content: content.trim(),
          division: (division && division !== 'none') ? division : null,
          created_by: user.id
        })
        .select()
        .maybeSingle();
      
      if (error) throw error;
      
      // Process mentions in the thread content and create mention records
      const mentionMatches = content.match(/@(\w+)/g);
      if (mentionMatches && data) {
        for (const mention of mentionMatches) {
          const username = mention.substring(1); // Remove @ symbol
          try {
            // Find user by name
            const { data: userData } = await supabase
              .from('profiles')
              .select('id')
              .eq('name', username)
              .maybeSingle();
            
            if (userData) {
              await supabase
                .from('forum_mentions')
                .insert({
                  mentioned_user_id: userData.id,
                  mentioner_user_id: user.id,
                  thread_id: data.id,
                  reply_id: null
                });
            }
          } catch (mentionError) {
            console.error('Error creating mention for', username, mentionError);
          }
        }
      }
      
      toast.success('Thread berhasil dibuat');
      navigate(`/forum/thread/${data?.id}`);
    } catch (error) {
      console.error('Error creating thread:', error);
      toast.error('Gagal membuat thread');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!user) {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="flex">
          <div className="flex-1 md:ml-64 pt-16 md:pt-0">
            <div className="container mx-auto px-4 py-6">
              <Card>
                <CardContent className="text-center py-12">
                  <p className="text-muted-foreground mb-4">
                    Anda harus login untuk membuat thread baru
                  </p>
                  <Button asChild>
                    <Link to="/auth">Masuk</Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="flex">
        <div className="flex-1 md:ml-64 pt-16 md:pt-0">
          <div className="container mx-auto px-4 py-6 max-w-4xl">
            <div className="mb-6">
              <Button variant="ghost" asChild className="mb-4">
                <Link to="/forum">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Kembali ke Forum
                </Link>
              </Button>
              
              <h1 className="text-3xl font-bold">Buat Thread Baru</h1>
            </div>

            <Card>
              <form onSubmit={submitThread}>
                <CardHeader>
                  <CardTitle>Thread Baru</CardTitle>
                  <CardDescription>
                    Bagikan pertanyaan, ide, atau topik diskusi dengan komunitas
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label htmlFor="title" className="text-sm font-medium">
                      Judul Thread
                    </label>
                    <Input
                      id="title"
                      placeholder="Masukkan judul yang menarik..."
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="division" className="text-sm font-medium">
                      Divisi (Opsional)
                    </label>
                    <Select value={division} onValueChange={setDivision}>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih divisi yang relevan" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Tidak ada divisi spesifik</SelectItem>
                        <SelectItem value="web">Web Development</SelectItem>
                        <SelectItem value="mobile">Mobile Development</SelectItem>
                        <SelectItem value="ui_ux">UI/UX Design</SelectItem>
                        <SelectItem value="data">Data Science</SelectItem>
                        <SelectItem value="ai">Artificial Intelligence</SelectItem>
                        <SelectItem value="game">Game Development</SelectItem>
                        <SelectItem value="iot">Internet of Things</SelectItem>
                        <SelectItem value="robotics">Robotics</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="content" className="text-sm font-medium">
                      Konten
                    </label>
                    <MentionTextarea
                      value={content}
                      onChange={setContent}
                      onMention={handleMention}
                      placeholder="Jelaskan topik diskusi Anda dengan detail... (gunakan @ untuk mention)"
                      className="min-h-[200px]"
                    />
                  </div>
                </CardContent>
                <CardContent className="pt-0">
                  <div className="flex gap-4">
                    <Button type="submit" disabled={isSubmitting}>
                      {isSubmitting ? 'Membuat...' : 'Buat Thread'}
                    </Button>
                    <Button type="button" variant="outline" asChild>
                      <Link to="/forum">Batal</Link>
                    </Button>
                  </div>
                </CardContent>
              </form>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

const EnhancedForum = () => {
  const location = useLocation();
  const pathname = location.pathname;
  
  return (
    <RoleBasedAccess 
      allowedRoles={['admin', 'member']}
      fallbackMessage="Hanya member yang dapat mengakses forum. Silakan daftar menjadi member terlebih dahulu."
    >
      {pathname === '/forum/new' ? (
        <NewThread />
      ) : pathname.startsWith('/forum/thread/') ? (
        <ThreadDetail />
      ) : (
        <ForumListView />
      )}
    </RoleBasedAccess>
  );
};

export default EnhancedForum;