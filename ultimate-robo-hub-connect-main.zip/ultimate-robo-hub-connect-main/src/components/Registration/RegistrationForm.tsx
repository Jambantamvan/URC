
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/custom-client';
import { useAuth } from '@/contexts/AuthContext';
import { SkillSelection, SKILL_OPTIONS } from './SkillSelection';
import { NoUserState, RegistrationStatus } from './RegistrationStatus';

const formSchema = z.object({
  name: z.string().min(2, { message: 'Nama minimal 2 karakter' }),
  birthDate: z.string().min(1, { message: 'Tanggal lahir wajib diisi' }),
  class: z.string().min(1, { message: 'Kelas wajib diisi' }),
  reason: z.string().min(10, { message: 'Alasan minimal 10 karakter' }),
  // We'll handle skills separately
});

type FormValues = z.infer<typeof formSchema>;

const RegistrationForm = () => {
  const { user, profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasRegistered, setHasRegistered] = useState(false);
  const [registrationStatus, setRegistrationStatus] = useState<string | null>(null);
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: profile?.name || '',
      birthDate: '',
      class: profile?.class || '',
      reason: '',
    },
  });

  // Check if user already has a registration request
  useEffect(() => {
    const checkExistingRegistration = async () => {
      if (!user) return;

      try {
        const { data, error } = await supabase
          .from('registration_requests')
          .select('status')
          .eq('user_id', user.id)
          .single();

        if (error && error.code !== 'PGRST116') {
          console.error('Error checking registration status:', error);
          return;
        }

        if (data) {
          setHasRegistered(true);
          setRegistrationStatus(data.status);
        }
      } catch (error) {
        console.error('Error checking registration status:', error);
      }
    };

    checkExistingRegistration();
  }, [user]);

  // Update form fields when profile is loaded
  useEffect(() => {
    if (profile) {
      form.setValue('name', profile.name);
      if (profile.class) {
        form.setValue('class', profile.class);
      }
    }
  }, [profile, form]);

  const toggleSkill = (skill: string) => {
    setSelectedSkills((prev) => {
      if (prev.includes(skill)) {
        return prev.filter(s => s !== skill);
      } else {
        return [...prev, skill];
      }
    });
  };

  const onSubmit = async (values: FormValues) => {
    if (!user) {
      toast.error('Anda harus login terlebih dahulu!');
      return;
    }

    if (selectedSkills.length === 0) {
      toast.error('Pilih minimal satu skill yang ingin dikembangkan!');
      return;
    }

    setIsSubmitting(true);

    try {
      console.log('Submitting registration with values:', { ...values, skills: selectedSkills });
      
      // Debug logs
      console.log('User ID:', user.id);
      console.log('Selected skills:', selectedSkills);
      
      const { data, error } = await supabase.from('registration_requests').insert({
        user_id: user.id,
        name: values.name,
        birth_date: values.birthDate,
        class: values.class,
        reason: values.reason,
        skills_to_develop: selectedSkills,
        status: 'pending'
      }).select();

      if (error) {
        console.error('Registration error details:', error);
        toast.error(`Gagal mendaftar: ${error.message}`);
        return;
      }

      console.log('Registration successful:', data);
      toast.success('Pendaftaran berhasil dikirimkan! Mohon tunggu persetujuan dari admin.');
      setHasRegistered(true);
      setRegistrationStatus('pending');

      // Update profile with name and class
      if (profile) {
        const { error: updateError } = await supabase
          .from('profiles')
          .update({ 
            name: values.name,
            class: values.class 
          })
          .eq('id', user.id);

        if (updateError) {
          console.error('Error updating profile:', updateError);
        } else {
          refreshProfile();
        }
      }
    } catch (error: any) {
      console.error('Error submitting registration:', error);
      toast.error(`Terjadi kesalahan saat mendaftar: ${error?.message || 'Unknown error'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!user) {
    return <NoUserState />;
  }

  if (hasRegistered) {
    return <RegistrationStatus registrationStatus={registrationStatus} />;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Formulir Pendaftaran Anggota</CardTitle>
        <CardDescription>
          Isi formulir berikut untuk mendaftar menjadi anggota klub robotik
        </CardDescription>
      </CardHeader>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardContent className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nama Lengkap</FormLabel>
                  <FormControl>
                    <Input placeholder="Masukkan nama lengkap" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="birthDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tanggal Lahir</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="class"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Kelas</FormLabel>
                  <FormControl>
                    <Input placeholder="Contoh: 10 MIPA 3" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="reason"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Alasan ingin masuk robotik</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Jelaskan alasanmu ingin bergabung dengan klub robotik" 
                      className="min-h-[100px]" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <SkillSelection 
              selectedSkills={selectedSkills}
              toggleSkill={toggleSkill}
            />
          </CardContent>
          
          <CardFooter>
            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? 'Mengirim...' : 'Kirim Pendaftaran'}
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
};

export default RegistrationForm;
