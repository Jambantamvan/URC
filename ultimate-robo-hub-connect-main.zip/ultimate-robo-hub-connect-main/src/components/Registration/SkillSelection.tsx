
import React from 'react';
import { Badge } from '@/components/ui/badge';
import { FormLabel } from '@/components/ui/form';

interface SkillSelectionProps {
  selectedSkills: string[];
  toggleSkill: (skill: string) => void;
}

// Predefined skills that users can choose from
export const SKILL_OPTIONS = [
  'AI & Machine Learning',
  'Hardware',
  'Software Development',
  'Electronics',
  'Mechanics',
  'IoT',
  'Programming',
  'Design',
  'Project Management'
];

export const SkillSelection = ({ selectedSkills, toggleSkill }: SkillSelectionProps) => {
  return (
    <div>
      <FormLabel className="block mb-2">Skill yang ingin dikembangkan</FormLabel>
      <div className="flex flex-wrap gap-2 mt-2">
        {SKILL_OPTIONS.map(skill => (
          <Badge 
            key={skill}
            variant={selectedSkills.includes(skill) ? "default" : "outline"} 
            className={`cursor-pointer ${
              selectedSkills.includes(skill) 
                ? "bg-primary" 
                : "hover:bg-primary/10"
            }`}
            onClick={() => toggleSkill(skill)}
          >
            {skill}
          </Badge>
        ))}
      </div>
      {selectedSkills.length === 0 && (
        <p className="text-sm text-red-500 mt-2">Pilih minimal satu skill</p>
      )}
    </div>
  );
};
