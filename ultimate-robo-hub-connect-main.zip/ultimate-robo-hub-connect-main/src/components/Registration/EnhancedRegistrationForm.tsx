import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/custom-client';
import { useAuth } from '@/contexts/AuthContext';
import { SkillSelection } from './SkillSelection';
import { NoUserState, RegistrationStatus } from './RegistrationStatus';

const formSchema = z.object({
  fullName: z.string().min(2, { message: 'Nama lengkap minimal 2 karakter' }),
  birthDate: z.string().min(1, { message: 'Tanggal lahir wajib diisi' }),
  birthPlace: z.string().min(2, { message: 'Tempat lahir wajib diisi' }),
  age: z.number().min(10).max(25, { message: 'Umur harus antara 10-25 tahun' }),
  class: z.string().min(1, { message: 'Kelas wajib diisi' }),
  gender: z.string().min(1, { message: 'Jenis kelamin wajib dipilih' }),
  phone: z.string().min(10, { message: 'Nomor telepon minimal 10 digit' }),
  hobbies: z.string().min(5, { message: 'Hobi minimal 5 karakter' }),
  reason: z.string().min(20, { message: 'Alasan minimal 20 karakter' }),
});

type FormValues = z.infer<typeof formSchema>;

const EnhancedRegistrationForm = () => {
  const { user, profile } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasRegistered, setHasRegistered] = useState(false);
  const [registrationStatus, setRegistrationStatus] = useState<string | null>(null);
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: profile?.name || '',
      birthDate: '',
      birthPlace: '',
      age: 15,
      class: profile?.class || '',
      gender: '',
      phone: '',
      hobbies: '',
      reason: '',
    },
  });

  // Check if user already has a registration request
  useEffect(() => {
    const checkExistingRegistration = async () => {
      if (!user) return;

      try {
        const { data, error } = await supabase
          .from('registration_requests')
          .select('status')
          .eq('user_id', user.id)
          .single();

        if (error && error.code !== 'PGRST116') {
          console.error('Error checking registration status:', error);
          return;
        }

        if (data) {
          setHasRegistered(true);
          setRegistrationStatus(data.status);
        }
      } catch (error) {
        console.error('Error checking registration status:', error);
      }
    };

    checkExistingRegistration();
  }, [user]);

  const toggleSkill = (skill: string) => {
    setSelectedSkills((prev) => {
      if (prev.includes(skill)) {
        return prev.filter(s => s !== skill);
      } else {
        return [...prev, skill];
      }
    });
  };

  const onSubmit = async (values: FormValues) => {
    if (!user) {
      toast.error('Anda harus login terlebih dahulu!');
      return;
    }

    if (selectedSkills.length === 0) {
      toast.error('Pilih minimal satu skill yang ingin dikembangkan!');
      return;
    }

    setIsSubmitting(true);

    try {
      const { data, error } = await supabase.from('registration_requests').insert({
        user_id: user.id,
        full_name: values.fullName,
        name: values.fullName, // for backward compatibility
        birth_date: values.birthDate,
        birth_place: values.birthPlace,
        age: values.age,
        class: values.class,
        gender: values.gender,
        phone: values.phone,
        hobbies: values.hobbies,
        reason: values.reason,
        skills_to_develop: selectedSkills,
        status: 'pending'
      }).select();

      if (error) {
        console.error('Registration error details:', error);
        toast.error(`Gagal mendaftar: ${error.message}`);
        return;
      }

      toast.success('Pendaftaran berhasil dikirimkan! Mohon tunggu persetujuan dari admin.');
      setHasRegistered(true);
      setRegistrationStatus('pending');

      // Update profile with basic info
      if (profile) {
        const { error: updateError } = await supabase
          .from('profiles')
          .update({ 
            name: values.fullName,
            class: values.class,
            birth_date: values.birthDate
          })
          .eq('id', user.id);

        if (updateError) {
          console.error('Error updating profile:', updateError);
        }
      }
    } catch (error: any) {
      console.error('Error submitting registration:', error);
      toast.error(`Terjadi kesalahan saat mendaftar: ${error?.message || 'Unknown error'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!user) {
    return <NoUserState />;
  }

  if (hasRegistered) {
    return <RegistrationStatus registrationStatus={registrationStatus} />;
  }

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>Formulir Pendaftaran Anggota Robotik</CardTitle>
        <CardDescription>
          Isi formulir berikut untuk mendaftar menjadi anggota klub robotik. Semua field wajib diisi.
        </CardDescription>
      </CardHeader>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nama Lengkap</FormLabel>
                    <FormControl>
                      <Input placeholder="Masukkan nama lengkap" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="class"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Kelas</FormLabel>
                    <FormControl>
                      <Input placeholder="Contoh: 10 MIPA 3" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="birthPlace"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tempat Lahir</FormLabel>
                    <FormControl>
                      <Input placeholder="Contoh: Jakarta" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="birthDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tanggal Lahir</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="age"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Umur</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="15" 
                        {...field} 
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="gender"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Jenis Kelamin</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih jenis kelamin" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="male">Laki-laki</SelectItem>
                        <SelectItem value="female">Perempuan</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nomor Telepon</FormLabel>
                    <FormControl>
                      <Input placeholder="08123456789" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="hobbies"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Hobi</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Ceritakan hobi-hobi Anda" 
                      className="min-h-[80px]" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="reason"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Alasan ingin bergabung dengan klub robotik</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Jelaskan alasan dan motivasi Anda bergabung dengan klub robotik" 
                      className="min-h-[120px]" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <SkillSelection 
              selectedSkills={selectedSkills}
              toggleSkill={toggleSkill}
            />
          </CardContent>
          
          <CardFooter>
            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? 'Mengirim...' : 'Kirim Pendaftaran'}
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
};

export default EnhancedRegistrationForm;