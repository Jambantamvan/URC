
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

interface RegistrationStatusProps {
  registrationStatus: string | null;
}

export const RegistrationStatus = ({ registrationStatus }: RegistrationStatusProps) => {
  const navigate = useNavigate();
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Status Pendaftaran</CardTitle>
        <CardDescription>
          Anda telah mengirimkan formulir pendaftaran
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-md">
          <p className="mb-2 font-medium">Status:</p>
          {registrationStatus === 'pending' ? (
            <div className="flex items-center text-yellow-600 dark:text-yellow-400">
              <span className="relative flex h-3 w-3 mr-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-yellow-500"></span>
              </span>
              Menunggu persetujuan
            </div>
          ) : registrationStatus === 'approved' ? (
            <div className="flex items-center text-green-600 dark:text-green-400">
              <span className="relative flex h-3 w-3 mr-2">
                <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
              </span>
              Disetujui
            </div>
          ) : (
            <div className="flex items-center text-red-600 dark:text-red-400">
              <span className="relative flex h-3 w-3 mr-2">
                <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
              </span>
              Ditolak
            </div>
          )}
          <p className="mt-4 text-sm text-gray-600 dark:text-gray-400">
            Silahkan cek status pendaftaran secara berkala untuk mengetahui hasil seleksi.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export const NoUserState = () => {
  const navigate = useNavigate();
  
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="text-center">
          <p className="mb-4">Anda harus login untuk mendaftar menjadi anggota.</p>
          <Button onClick={() => navigate('/auth')}>Login / Daftar</Button>
        </div>
      </CardContent>
    </Card>
  );
};
