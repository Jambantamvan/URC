import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Lock, UserX } from 'lucide-react';

interface RoleBasedAccessProps {
  children: React.ReactNode;
  allowedRoles?: ('admin' | 'member' | 'non-member')[];
  requireAuth?: boolean;
  fallbackMessage?: string;
}

const RoleBasedAccess: React.FC<RoleBasedAccessProps> = ({
  children,
  allowedRoles = ['admin', 'member'],
  requireAuth = true,
  fallbackMessage = 'Anda tidak memiliki akses ke halaman ini.'
}) => {
  const { user, profile, isLoading } = useAuth();

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-pulse text-lg">Loading...</div>
      </div>
    );
  }

  // Check if user needs to be authenticated
  if (requireAuth && !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <Lock className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-xl font-semibold mb-2">Login Diperlukan</h2>
            <p className="text-muted-foreground mb-4">
              Anda harus login untuk mengakses halaman ini.
            </p>
            <div className="space-y-2">
              <Button asChild className="w-full">
                <Link to="/auth">Login / Daftar</Link>
              </Button>
              <Button variant="outline" asChild className="w-full">
                <Link to="/">Kembali ke Beranda</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Check role-based access
  if (user && profile && !allowedRoles.includes(profile.role as any)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <UserX className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-xl font-semibold mb-2">Akses Ditolak</h2>
            <p className="text-muted-foreground mb-2">
              {fallbackMessage}
            </p>
            <p className="text-sm text-muted-foreground mb-4">
              Role Anda: <span className="font-medium capitalize">{profile.role || 'unknown'}</span>
            </p>
            <div className="space-y-2">
              {profile.role === 'non-member' && (
                <Button asChild className="w-full">
                  <Link to="/registration">Daftar Menjadi Member</Link>
                </Button>
              )}
              <Button variant="outline" asChild className="w-full">
                <Link to="/">Kembali ke Beranda</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // If all checks pass, render the children
  return <>{children}</>;
};

export default RoleBasedAccess;