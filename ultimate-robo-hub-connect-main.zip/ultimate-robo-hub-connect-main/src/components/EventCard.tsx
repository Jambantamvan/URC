
import { Event } from "@/types";
import { Calendar } from "lucide-react";
import { format } from "date-fns";
import { id } from "date-fns/locale";

interface EventCardProps {
  event: Event;
  compact?: boolean;
}

const EventCard = ({ event, compact = false }: EventCardProps) => {
  const startDate = new Date(event.startDate);
  const endDate = new Date(event.endDate);
  
  const isSameDay = startDate.toDateString() === endDate.toDateString();

  return (
    <div className="bg-white dark:bg-robo-dark rounded-lg border border-slate-200 dark:border-slate-700 overflow-hidden">
      <div className="p-4">
        <h3 className="font-semibold text-lg mb-2">{event.title}</h3>
        
        {!compact && (
          <p className="text-gray-700 dark:text-gray-300 text-sm mb-3">{event.description}</p>
        )}
        
        <div className="flex items-center gap-2 text-robo-blue mb-2">
          <Calendar className="h-4 w-4" />
          <span className="text-sm">
            {isSameDay ? (
              <>
                {format(startDate, "EEEE, d MMMM yyyy", { locale: id })}
                <br />
                {format(startDate, "HH:mm", { locale: id })} - {format(endDate, "HH:mm", { locale: id })}
              </>
            ) : (
              <>
                {format(startDate, "d MMM", { locale: id })} {format(startDate, "HH:mm", { locale: id })} - 
                {format(endDate, "d MMM", { locale: id })} {format(endDate, "HH:mm", { locale: id })}
              </>
            )}
          </span>
        </div>
        
        <div className="text-sm text-gray-600 dark:text-gray-400">
          <span>Lokasi: {event.location}</span>
        </div>
        
        {!compact && (
          <div className="mt-3">
            <div className="text-xs text-gray-500 mb-1">
              {event.attendees.length} orang menghadiri
            </div>
            <div className="flex -space-x-2">
              {event.attendees.slice(0, 5).map((attendee, index) => (
                <div 
                  key={index} 
                  className="h-6 w-6 rounded-full bg-robo-blue text-white flex items-center justify-center text-xs"
                  title={attendee.userName}
                >
                  {attendee.userName.charAt(0)}
                </div>
              ))}
              {event.attendees.length > 5 && (
                <div className="h-6 w-6 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 flex items-center justify-center text-xs">
                  +{event.attendees.length - 5}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EventCard;
