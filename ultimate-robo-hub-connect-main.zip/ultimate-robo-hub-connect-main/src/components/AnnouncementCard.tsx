
import { Announcement } from "@/types";
import { format } from "date-fns";

interface AnnouncementCardProps {
  announcement: Announcement;
}

const AnnouncementCard = ({ announcement }: AnnouncementCardProps) => {
  return (
    <div className={`p-4 rounded-lg ${announcement.important ? 'bg-robo-blue/20 border border-robo-blue/40' : 'bg-white dark:bg-robo-dark border border-slate-200 dark:border-slate-700'}`}>
      <div className="flex justify-between items-start mb-2">
        <h3 className="font-semibold text-lg">{announcement.title}</h3>
        {announcement.important && (
          <span className="bg-robo-blue text-white text-xs px-2 py-1 rounded-full">
            Penting
          </span>
        )}
      </div>
      
      <p className="text-gray-700 dark:text-gray-300 text-sm mb-3">{announcement.content}</p>
      
      <div className="text-xs text-gray-500">
        {format(new Date(announcement.createdAt), "d MMM yyyy, HH:mm")}
      </div>
    </div>
  );
};

export default AnnouncementCard;
