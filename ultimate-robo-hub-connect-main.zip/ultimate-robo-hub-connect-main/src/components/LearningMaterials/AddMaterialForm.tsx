import { useState } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { toast } from 'sonner';
import { Loader2, Plus } from 'lucide-react';

interface AddMaterialFormProps {
  onMaterialAdded: () => void;
}

const AddMaterialForm = ({ onMaterialAdded }: AddMaterialFormProps) => {
  const { profile } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<'document' | 'video' | 'link'>('document');
  const [level, setLevel] = useState<'beginner' | 'intermediate' | 'advanced'>('beginner');
  const [url, setUrl] = useState('');
  const [content, setContent] = useState('');

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setType('document');
    setLevel('beginner');
    setUrl('');
    setContent('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!profile) {
      toast.error('Anda harus login untuk menambahkan materi');
      return;
    }

    if (!title.trim()) {
      toast.error('Judul harus diisi');
      return;
    }

    setIsSubmitting(true);

    try {
      const materialData = {
        title: title.trim(),
        description: description.trim() || null,
        type,
        level,
        url: url.trim() || null,
        content: content.trim() || null,
        created_by: profile.id,
      };

      const { error } = await supabase
        .from('learning_materials')
        .insert(materialData);

      if (error) {
        throw error;
      }

      toast.success('Materi pembelajaran berhasil ditambahkan');
      resetForm();
      setIsOpen(false);
      onMaterialAdded();

    } catch (error: any) {
      console.error('Error adding material:', error);
      toast.error(error.message || 'Gagal menambahkan materi pembelajaran');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!profile || (profile.role !== 'admin' && profile.role !== 'member')) {
    return null;
  }

  if (!isOpen) {
    return (
      <Button onClick={() => setIsOpen(true)} className="mb-6">
        <Plus className="h-4 w-4 mr-2" />
        Tambah Materi Baru
      </Button>
    );
  }

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle>Tambah Materi Pembelajaran</CardTitle>
        <CardDescription>
          Tambahkan materi pembelajaran baru untuk anggota URC
        </CardDescription>
      </CardHeader>
      
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="title">Judul</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Judul materi"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="type">Tipe</Label>
              <Select value={type} onValueChange={(value: any) => setType(value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Pilih tipe" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="document">Dokumen</SelectItem>
                  <SelectItem value="video">Video</SelectItem>
                  <SelectItem value="link">Link</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="level">Level</Label>
            <Select value={level} onValueChange={(value: any) => setLevel(value)}>
              <SelectTrigger>
                <SelectValue placeholder="Pilih level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="beginner">Pemula</SelectItem>
                <SelectItem value="intermediate">Menengah</SelectItem>
                <SelectItem value="advanced">Lanjutan</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Deskripsi</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Deskripsi materi"
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="url">URL</Label>
            <Input
              id="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://example.com/material"
              type="url"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="content">Konten</Label>
            <Textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Konten materi (opsional)"
              rows={4}
            />
          </div>
        </CardContent>
        
        <CardFooter className="flex justify-end space-x-2">
          <Button 
            type="button" 
            variant="outline" 
            onClick={() => {
              setIsOpen(false);
              resetForm();
            }}
          >
            Batal
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Menyimpan...
              </>
            ) : (
              'Tambah Materi'
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
};

export default AddMaterialForm;