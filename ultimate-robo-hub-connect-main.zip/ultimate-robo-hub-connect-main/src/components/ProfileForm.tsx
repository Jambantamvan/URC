
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { Loader2 } from 'lucide-react';
import SecurityUtils from '@/utils/security';

const ProfileForm = () => {
  const { profile: authProfile, refreshProfile } = useAuth();
  const [name, setName] = useState('');
  const [className, setClassName] = useState('');
  const [division, setDivision] = useState('');
  const [skills, setSkills] = useState<string[]>([]);
  const [bio, setBio] = useState('');
  const [skillInput, setSkillInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [registrationData, setRegistrationData] = useState<any>(null);

  useEffect(() => {
    if (authProfile) {
      setName(authProfile.name || '');
      setClassName(authProfile.class || '');
      setDivision(authProfile.division || '');
      setSkills(authProfile.skills || []);
      setBio(authProfile.bio || '');
      
      // Check if user has registration data
      fetchRegistrationData();
    }
  }, [authProfile]);

  const fetchRegistrationData = async () => {
    if (!authProfile) return;
    
    try {
      const { data, error } = await supabase
        .from('registration_requests')
        .select('*')
        .eq('user_id', authProfile.id)
        .eq('status', 'approved')
        .maybeSingle();
        
      if (error) throw error;
      
      if (data) {
        setRegistrationData(data);
        
        // Auto-fill from registration data if profile fields are empty
        if (!name && data.name) setName(data.name);
        if (!className && data.class) setClassName(data.class);
        if (skills.length === 0 && data.skills_to_develop) setSkills(data.skills_to_develop);
        if (!bio) setBio(`Anggota ${data.name} dari kelas ${data.class}`);
      }
    } catch (error) {
      console.error('Error fetching registration data:', error);
    }
  };

  const handleAddSkill = () => {
    if (skillInput && !skills.includes(skillInput)) {
      setSkills([...skills, skillInput]);
      setSkillInput('');
    }
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    setSkills(skills.filter(skill => skill !== skillToRemove));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authProfile) return;

    // Security validations
    const nameValidation = SecurityUtils.validateContent(name, 'text');
    if (!nameValidation.isValid) {
      toast.error('Nama tidak valid: ' + nameValidation.errors.join(', '));
      return;
    }

    const classValidation = SecurityUtils.validateContent(className, 'text');
    if (!classValidation.isValid) {
      toast.error('Kelas tidak valid: ' + classValidation.errors.join(', '));
      return;
    }

    const bioValidation = SecurityUtils.validateContent(bio, 'text');
    if (!bioValidation.isValid) {
      toast.error('Bio tidak valid: ' + bioValidation.errors.join(', '));
      return;
    }

    // Validate skills
    const sanitizedSkills = skills.map(skill => {
      const skillValidation = SecurityUtils.validateContent(skill, 'text');
      if (!skillValidation.isValid) {
        throw new Error(`Skill "${skill}" tidak valid`);
      }
      return skillValidation.sanitized;
    });

    if (!SecurityUtils.checkClientRateLimit(`profile_update_${authProfile.id}`, 10, 60000)) {
      SecurityUtils.logSecurityEvent('PROFILE_UPDATE_RATE_LIMIT', { userId: authProfile.id });
      toast.error('Terlalu banyak percobaan update profil. Coba lagi dalam 1 menit.');
      return;
    }

    setIsLoading(true);
    
    try {
      console.log('Updating profile with data:', {
        name: nameValidation.sanitized,
        class: classValidation.sanitized,
        division,
        skills: sanitizedSkills,
        bio: bioValidation.sanitized,
        updated_at: new Date().toISOString()
      });

      const { data, error } = await supabase
        .from('profiles')
        .update({
          name: nameValidation.sanitized || null,
          class: classValidation.sanitized || null,
          division: division || null,
          skills: sanitizedSkills.length > 0 ? sanitizedSkills : null,
          bio: bioValidation.sanitized || null,
          updated_at: new Date().toISOString()
        })
        .eq('id', authProfile.id)
        .select();

      if (error) {
        console.error('Supabase update error:', error);
        SecurityUtils.logSecurityEvent('PROFILE_UPDATE_ERROR', { 
          userId: authProfile.id, 
          error: error.message 
        });
        throw error;
      }
      
      console.log('Profile updated successfully:', data);
      SecurityUtils.logSecurityEvent('PROFILE_UPDATE_SUCCESS', { userId: authProfile.id });
      
      // Refresh the profile data
      await refreshProfile();
      toast.success('Profil berhasil diperbarui');
    } catch (error: any) {
      console.error('Error updating profile:', error);
      const errorMessage = error?.message || 'Terjadi kesalahan saat memperbarui profil';
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  if (!authProfile) {
    return <div className="p-4 text-center">Loading profile data...</div>;
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {registrationData && (
        <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-md border border-green-200 dark:border-green-800 mb-4">
          <p className="text-green-700 dark:text-green-300 text-sm">
            Data pendaftaran anda telah disetujui. Beberapa informasi telah ditambahkan ke profil anda.
          </p>
        </div>
      )}

      <div className="space-y-2">
        <Label htmlFor="name">Nama Lengkap</Label>
        <Input
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Nama lengkap"
          required
          className="w-full"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="class">Kelas</Label>
          <Input
            id="class"
            value={className}
            onChange={(e) => setClassName(e.target.value)}
            placeholder="Contoh: 11 IPA 2"
            className="w-full"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="division">Divisi</Label>
          <select
            id="division"
            value={division}
            onChange={(e) => setDivision(e.target.value)}
            className="w-full rounded-md border border-input bg-background px-3 py-2 h-10"
          >
            <option value="">Pilih Divisi</option>
            <option value="Programming">Programming</option>
            <option value="Mekanik">Mekanik</option>
            <option value="Elektronik">Elektronik</option>
            <option value="AI">AI</option>
            <option value="IoT">IoT</option>
          </select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="skills">Keahlian</Label>
        <div className="flex gap-2">
          <Input
            id="skills"
            value={skillInput}
            onChange={(e) => setSkillInput(e.target.value)}
            placeholder="Tambahkan keahlian"
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                handleAddSkill();
              }
            }}
          />
          <Button type="button" onClick={handleAddSkill} className="whitespace-nowrap">
            Tambah
          </Button>
        </div>
        <div className="flex flex-wrap gap-2 mt-2">
          {skills.map((skill, index) => (
            <div
              key={index}
              className="bg-robo-blue/10 text-robo-blue px-3 py-1 rounded-full flex items-center gap-2"
            >
              <span>{skill}</span>
              <button
                type="button"
                onClick={() => handleRemoveSkill(skill)}
                className="text-robo-blue hover:text-robo-darkBlue"
              >
                &times;
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="bio">Bio</Label>
        <Textarea
          id="bio"
          value={bio}
          onChange={(e) => setBio(e.target.value)}
          placeholder="Ceritakan tentang dirimu..."
          rows={4}
        />
      </div>

      <Button type="submit" className="w-full" disabled={isLoading}>
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Menyimpan...
          </>
        ) : 'Simpan Profil'}
      </Button>
    </form>
  );
};

export default ProfileForm;
