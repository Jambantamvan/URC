
import { Link } from 'react-router-dom';
import { format, parseISO } from 'date-fns';
import { Clock, Tag } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface Project {
  id: string;
  title: string;
  description?: string | null;
  status: string;
  tags?: string[] | null;
  created_at: string;
}

interface ProjectCardProps {
  project: Project;
}

const ProjectCard = ({ project }: ProjectCardProps) => {
  // Fungsi bantu untuk memformat tanggal dengan pengecekan null/undefined
  const formatCreatedAt = () => {
    try {
      if (!project.created_at) return "Tanggal tidak tersedia";
      return format(parseISO(project.created_at), "dd MMM yyyy");
    } catch (error) {
      console.error("Error formatting date:", error);
      return "Format tanggal tidak valid";
    }
  };

  return (
    <Link 
      to={`/projects/${project.id}`}
      className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow"
    >
      <div className="p-5">
        <h3 className="text-xl font-medium mb-2 line-clamp-1">{project.title}</h3>
        <p className="text-gray-600 dark:text-gray-300 mb-4 text-sm line-clamp-3">
          {project.description || "Tidak ada deskripsi"}
        </p>
        <div className="flex flex-wrap gap-2 mb-4">
          {project.tags && project.tags.map((tag, idx) => (
            <Badge key={idx} variant="outline" className="text-xs">
              {tag}
            </Badge>
          ))}
        </div>
        <div className="flex justify-between items-center text-sm">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
            project.status === 'planning' ? 'bg-amber-100 text-amber-600' :
            project.status === 'in_progress' ? 'bg-blue-100 text-blue-600' :
            project.status === 'completed' ? 'bg-green-100 text-green-600' :
            'bg-gray-100 text-gray-600'
          }`}>
            {project.status === 'planning' && 'Planning'}
            {project.status === 'in_progress' && 'In Progress'}
            {project.status === 'completed' && 'Completed'}
            {project.status === 'archived' && 'Archived'}
          </span>
          <span className="text-gray-500 flex items-center">
            <Clock className="h-3 w-3 mr-1" />
            {formatCreatedAt()}
          </span>
        </div>
      </div>
    </Link>
  );
};

export default ProjectCard;
