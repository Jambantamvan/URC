
import React from 'react';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/contexts/ThemeContext';
import { Sun, Moon } from 'lucide-react';

export function ThemeToggle() {
  const { theme, toggleTheme, isTransitioning } = useTheme();
  
  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={toggleTheme}
      className={`rounded-md transition-transform ${isTransitioning ? 'scale-90' : 'scale-100'}`}
    >
      <Sun className={`h-5 w-5 transition-all ${theme === 'light' ? 'opacity-100 rotate-0' : 'opacity-0 rotate-90'} absolute`} />
      <Moon className={`h-5 w-5 transition-all ${theme === 'dark' ? 'opacity-100 rotate-0' : 'opacity-0 -rotate-90'} absolute`} />
      <span className="sr-only">Toggle theme</span>
    </Button>
  );
}

// Add default export as well for backward compatibility
export default ThemeToggle;
