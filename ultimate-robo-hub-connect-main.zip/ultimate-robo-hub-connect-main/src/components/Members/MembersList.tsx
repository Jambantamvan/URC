
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Shield, ShieldCheck, User, ShieldAlert, Mail } from 'lucide-react';
import { Profile } from '@/types/supabase';

interface MembersListProps {
  members: Profile[];
  isLoading: boolean;
  type: 'members' | 'admins' | 'non-members';
}

export const MembersList = ({ members, isLoading, type }: MembersListProps) => {
  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'admin':
        return <Badge variant="destructive" className="ml-2"><ShieldAlert className="h-3 w-3 mr-1" /> Admin</Badge>;
      case 'member':
        return <Badge variant="default" className="bg-green-500 ml-2"><ShieldCheck className="h-3 w-3 mr-1" /> Member</Badge>;
      default:
        return <Badge variant="outline" className="ml-2"><User className="h-3 w-3 mr-1" /> Non-Member</Badge>;
    }
  };
  
  const getUserAvatar = (user: Profile) => {
    return (
      <Avatar className="h-12 w-12 border">
        {user.photo_url ? (
          <AvatarImage src={user.photo_url} alt={user.name} />
        ) : (
          <AvatarFallback className="bg-robo-blue text-white">
            {user.name ? user.name.charAt(0).toUpperCase() : 'U'}
          </AvatarFallback>
        )}
      </Avatar>
    );
  };

  const renderUserCard = (user: Profile) => (
    <Card key={user.id} className="mb-3">
      <CardContent className="p-4">
        <div className="flex items-center">
          {getUserAvatar(user)}
          <div className="ml-4 flex-1">
            <div className="flex items-center">
              <h3 className="font-medium">{user.name}</h3>
              {getRoleBadge(user.role)}
            </div>
            <div className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
              <Mail className="h-3 w-3 mr-1" /> {user.email}
            </div>
            {user.class && (
              <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                Kelas: {user.class}
              </div>
            )}
            {user.division && (
              <div className="text-sm text-gray-500 dark:text-gray-400">
                Divisi: {user.division}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-3">
        {[1, 2, 3].map(i => (
          <div key={i} className="h-20 bg-gray-200 dark:bg-gray-700 rounded-md"></div>
        ))}
      </div>
    );
  }
  
  if (members.length === 0) {
    const EmptyStateIcon = () => {
      switch (type) {
        case 'admins':
          return <ShieldAlert className="h-12 w-12 mx-auto text-gray-400 mb-3" />;
        case 'members':
          return <Shield className="h-12 w-12 mx-auto text-gray-400 mb-3" />;
        case 'non-members':
          return <User className="h-12 w-12 mx-auto text-gray-400 mb-3" />;
      }
    };
    
    const emptyMessage = {
      'admins': 'Tidak ada admin yang terdaftar',
      'members': 'Tidak ada anggota yang terdaftar',
      'non-members': 'Tidak ada non-member yang terdaftar'
    };
    
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <EmptyStateIcon />
          <p>{emptyMessage[type]}</p>
        </CardContent>
      </Card>
    );
  }
  
  return <div className="space-y-2">{members.map(renderUserCard)}</div>;
};
