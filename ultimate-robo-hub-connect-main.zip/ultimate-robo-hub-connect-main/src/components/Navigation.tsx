
import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/custom-client';
import { useIsMobile } from '@/hooks/use-mobile';
import { ThemeToggle } from './ThemeToggle';
import { useAuth } from '@/contexts/AuthContext';
import {
  Calendar,
  BookOpen,
  MessageSquare,
  User,
  Users,
  LogOut,
  Settings,
  Menu,
  X,
  Home,
  Image,
  FileText,
  Code,
  LogIn,
  FileCheck
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const Navigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, profile, signOut } = useAuth();
  const isMobile = useIsMobile();
  const { pathname } = useLocation();
  
  useEffect(() => {
    // Close menu when changing routes on mobile
    setIsMenuOpen(false);
  }, [pathname]);
  
  const handleLogout = async () => {
    await signOut();
    window.location.href = '/';
  };
  
  // Menu items berdasarkan role user
  const getMenuItems = () => {
    const baseItems = [
      { name: 'Beranda', path: '/', icon: <Home className="w-5 h-5" /> }
    ];

    // Jika user tidak login atau role non-member, hanya tampilkan beranda dan registrasi
    if (!profile || profile.role === 'non-member') {
      return [
        ...baseItems,
        { name: 'Daftar Member', path: '/registration', icon: <User className="w-5 h-5" /> }
      ];
    }

    // Untuk member dan admin, tampilkan semua menu
    if (profile.role === 'member' || profile.role === 'admin') {
      return [
        ...baseItems,
        { name: 'Forum', path: '/forum', icon: <MessageSquare className="w-5 h-5" /> },
        { name: 'Kalender', path: '/calendar', icon: <Calendar className="w-5 h-5" /> },
        { name: 'Belajar', path: '/learn', icon: <BookOpen className="w-5 h-5" /> },
        { name: 'Proyek', path: '/projects', icon: <FileText className="w-5 h-5" /> },
        { name: 'Absensi', path: '/attendance', icon: <FileCheck className="w-5 h-5" /> },
        { name: 'Galeri', path: '/gallery', icon: <Image className="w-5 h-5" /> },
        { name: 'Playground', path: '/playground', icon: <Code className="w-5 h-5" /> },
      ];
    }

    return baseItems;
  };

  const menuItems = getMenuItems();
  
  // Admin only menu items
  const adminMenuItems = profile?.role === 'admin' ? [
    { name: 'Dashboard', path: '/admin', icon: <Settings className="w-5 h-5" /> },
    { name: 'Manajemen User', path: '/admin/users', icon: <Users className="w-5 h-5" /> },
  ] : [];
  
  const renderMobileMenu = () => (
    <div className="fixed inset-0 bg-background z-40 overflow-y-auto md:hidden">
      <div className="flex justify-between items-center p-4 border-b">
        <h1 className="text-xl font-bold">Menu</h1>
        <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(false)}>
          <X className="h-6 w-6" />
        </Button>
      </div>
      
      <div className="p-4">
        {profile ? (
          <div className="flex items-center space-x-4 mb-6 p-2 rounded-lg bg-muted">
            <Avatar>
              <AvatarImage src={profile.photo_url || undefined} />
              <AvatarFallback>{profile.name ? profile.name.charAt(0) : 'U'}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium">{profile.name || 'User'}</p>
              <p className="text-sm text-muted-foreground capitalize">{profile.role || 'user'}</p>
            </div>
          </div>
        ) : (
          <div className="mb-6 flex justify-center">
            <Link to="/auth">
              <Button className="w-full">
                <LogIn className="mr-2 h-4 w-4" />
                Login / Register
              </Button>
            </Link>
          </div>
        )}
        
        <nav className="space-y-1">
          {menuItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center space-x-3 px-3 py-2 rounded-md text-sm ${
                pathname === item.path
                  ? 'bg-primary text-primary-foreground font-medium'
                  : 'hover:bg-muted'
              }`}
            >
              {item.icon}
              <span>{item.name}</span>
            </Link>
          ))}
          
          {adminMenuItems.length > 0 && (
            <>
              <div className="py-2">
                <div className="h-px bg-border"></div>
              </div>
              
              {adminMenuItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center space-x-3 px-3 py-2 rounded-md text-sm ${
                    pathname === item.path
                      ? 'bg-primary text-primary-foreground font-medium'
                      : 'hover:bg-muted'
                  }`}
                >
                  {item.icon}
                  <span>{item.name}</span>
                </Link>
              ))}
            </>
          )}
        </nav>
        
        {profile && (
          <>
            <div className="py-2 mt-4">
              <div className="h-px bg-border"></div>
            </div>
            
            <div className="space-y-1">
              <Link
                to="/profile"
                className="flex items-center space-x-3 px-3 py-2 rounded-md text-sm hover:bg-muted"
              >
                <User className="w-5 h-5" />
                <span>Profil</span>
              </Link>
              
              <button
                onClick={handleLogout}
                className="flex items-center space-x-3 px-3 py-2 rounded-md text-sm hover:bg-muted w-full text-left"
              >
                <LogOut className="w-5 h-5" />
                <span>Logout</span>
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
  
  const renderDesktopSidebar = () => (
    <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
      <div className="flex flex-col flex-grow border-r bg-background overflow-y-auto">
        <div className="flex items-center justify-between h-16 flex-shrink-0 px-4 border-b">
          <Link to="/" className="font-bold text-lg">
            URC Robotics
          </Link>
          <ThemeToggle />
        </div>
        
        <div className="flex-grow flex flex-col pt-5 pb-4 overflow-y-auto">
          <nav className="flex-1 px-3 space-y-1">
            {menuItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center space-x-3 px-3 py-2 rounded-md text-sm ${
                  pathname === item.path
                    ? 'bg-primary text-primary-foreground font-medium'
                    : 'hover:bg-muted'
                }`}
              >
                {item.icon}
                <span>{item.name}</span>
              </Link>
            ))}
            
            {adminMenuItems.length > 0 && (
              <>
                <div className="pt-4 pb-2">
                  <div className="h-px bg-border"></div>
                  <h3 className="px-3 pt-3 pb-1 text-xs font-semibold text-muted-foreground">
                    Admin
                  </h3>
                </div>
                
                {adminMenuItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center space-x-3 px-3 py-2 rounded-md text-sm ${
                      pathname === item.path
                        ? 'bg-primary text-primary-foreground font-medium'
                        : 'hover:bg-muted'
                    }`}
                  >
                    {item.icon}
                    <span>{item.name}</span>
                  </Link>
                ))}
              </>
            )}
          </nav>
        </div>
        
        <div className="flex-shrink-0 border-t p-4">
          {profile ? (
            <div className="flex items-center">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2 w-full justify-start px-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={profile.photo_url || undefined} />
                      <AvatarFallback>{profile.name ? profile.name.charAt(0) : 'U'}</AvatarFallback>
                    </Avatar>
                    <div className="flex flex-col items-start text-sm">
                      <span className="font-medium truncate w-36">{profile.name || 'User'}</span>
                      <span className="text-xs text-muted-foreground capitalize">{profile.role || 'user'}</span>
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>Akun Saya</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to="/profile">
                      <User className="mr-2 h-4 w-4" />
                      <span>Profil</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          ) : (
            <Link to="/auth">
              <Button variant="default" className="w-full">
                <LogIn className="mr-2 h-4 w-4" />
                Login / Register
              </Button>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
  
  return (
    <>
      {/* Mobile Header */}
      <div className="fixed top-0 left-0 right-0 h-16 bg-background border-b z-30 md:hidden flex items-center justify-between px-4">
        <div className="flex items-center">
          <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(true)}>
            <Menu className="h-6 w-6" />
          </Button>
          <h1 className="font-bold ml-3">URC Robotics</h1>
        </div>
        <ThemeToggle />
      </div>
      
      {/* Mobile Menu (Slide-out) */}
      {isMobile && isMenuOpen && renderMobileMenu()}
      
      {/* Desktop Sidebar */}
      {renderDesktopSidebar()}
    </>
  );
};

export default Navigation;
