
import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue
} from "@/components/ui/select";
import { CodeSnippet } from '@/types';
import { createCodeSnippet, updateCodeSnippet, downloadCodeSnippet } from '@/services/api';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Download, Save } from 'lucide-react';
import CodeRunner from './CodeRunner';

interface CodeEditorProps {
  initialSnippet?: CodeSnippet;
}

const CodeEditor = ({ initialSnippet }: CodeEditorProps) => {
  const [title, setTitle] = useState(initialSnippet?.title || '');
  const [code, setCode] = useState(initialSnippet?.code || '');
  const [language, setLanguage] = useState<'python' | 'arduino' | 'c' | 'cpp'>(initialSnippet?.language || 'python');
  const [description, setDescription] = useState(initialSnippet?.description || '');
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  
  const handleSave = () => {
    if (!title || !code) return;
    
    if (initialSnippet) {
      updateCodeSnippet(initialSnippet.id, {
        title,
        code,
        language,
        description
      });
    } else {
      createCodeSnippet({
        title,
        code,
        language,
        description
      });
      
      // Reset form after creating
      setTitle('');
      setCode('');
      setDescription('');
    }
  };
  
  const handleDownload = () => {
    if (!title || !code) return;
    
    const snippetToDownload: CodeSnippet = initialSnippet || {
      id: 'temp',
      title,
      code,
      language,
      description,
      createdBy: '',
      createdAt: '',
      updatedAt: ''
    };
    
    downloadCodeSnippet(snippetToDownload);
  };
  
  const handleTab = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = e.currentTarget.selectionStart;
      const end = e.currentTarget.selectionEnd;
      
      const newCode = code.substring(0, start) + '  ' + code.substring(end);
      setCode(newCode);
      
      // Move cursor position after the inserted tab
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = textareaRef.current.selectionEnd = start + 2;
        }
      }, 0);
    }
  };

  return (
    <div className="space-y-6">
      <div className="border rounded-lg p-4 bg-white dark:bg-robo-dark shadow-sm">
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="title">Judul</Label>
              <Input
                id="title"
                placeholder="Judul kode"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="language">Bahasa</Label>
              <Select
                value={language}
                onValueChange={(value) => setLanguage(value as 'python' | 'arduino' | 'c' | 'cpp')}
              >
                <SelectTrigger id="language">
                  <SelectValue placeholder="Pilih bahasa" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="python">Python</SelectItem>
                  <SelectItem value="arduino">Arduino</SelectItem>
                  <SelectItem value="c">C</SelectItem>
                  <SelectItem value="cpp">C++</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description">Deskripsi</Label>
            <Input
              id="description"
              placeholder="Deskripsi kode"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="code">Kode</Label>
            <div className="relative">
              <Textarea
                ref={textareaRef}
                id="code"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                onKeyDown={handleTab}
                className="h-64 font-mono text-sm resize-y"
                placeholder="Ketik kode di sini..."
              />
            </div>
          </div>
          
          <div className="flex justify-end gap-3">
            <Button 
              variant="outline" 
              onClick={handleDownload}
              className="flex items-center gap-2"
            >
              <Download className="h-4 w-4" /> 
              Download
            </Button>
            
            <Button 
              onClick={handleSave}
              className="flex items-center gap-2"
            >
              <Save className="h-4 w-4" /> 
              Simpan
            </Button>
          </div>
        </div>
      </div>
      
      <CodeRunner code={code} language={language} />
    </div>
  );
};

export default CodeEditor;
