import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Play, Square, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

interface CodeRunnerProps {
  code: string;
  language: 'python' | 'arduino' | 'c' | 'cpp';
}

const CodeRunner: React.FC<CodeRunnerProps> = ({ code, language }) => {
  const [output, setOutput] = useState<string>('');
  const [isRunning, setIsRunning] = useState(false);
  const [error, setError] = useState<string>('');

  const runCode = async () => {
    if (!code.trim()) {
      toast.error('Masukkan kode terlebih dahulu');
      return;
    }

    setIsRunning(true);
    setOutput('');
    setError('');

    try {
      // Simulate code execution based on language
      const simulatedOutput = await simulateCodeExecution(code, language);
      setOutput(simulatedOutput);
    } catch (err: any) {
      setError(err.message || 'Terjadi kesalahan saat menjalankan kode');
      toast.error('Terjadi kesalahan saat menjalankan kode');
    } finally {
      setIsRunning(false);
    }
  };

  const simulateCodeExecution = (code: string, language: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        try {
          let output = '';

          if (language === 'python') {
            // Enhanced Python simulation
            if (code.includes('print(')) {
              const printStatements = code.match(/print\([^)]*\)/g);
              if (printStatements) {
                printStatements.forEach(statement => {
                  const content = statement.match(/print\(([^)]*)\)/)?.[1] || '';
                  // Better parsing for strings and variables
                  let cleanContent = content.trim();
                  if (cleanContent.startsWith('"') && cleanContent.endsWith('"')) {
                    cleanContent = cleanContent.slice(1, -1);
                  } else if (cleanContent.startsWith("'") && cleanContent.endsWith("'")) {
                    cleanContent = cleanContent.slice(1, -1);
                  }
                  // Handle simple expressions and math
                  if (cleanContent.includes('+')) {
                    try {
                      // Simple string concatenation or math
                      if (cleanContent.includes('"') || cleanContent.includes("'")) {
                        cleanContent = cleanContent.replace(/"/g, '').replace(/'/g, '').replace(/\+/g, '');
                      } else {
                        // Simple math evaluation for basic expressions
                        const mathExpression = cleanContent.match(/(\d+)\s*\+\s*(\d+)/);
                        if (mathExpression) {
                          const result = parseInt(mathExpression[1]) + parseInt(mathExpression[2]);
                          cleanContent = result.toString();
                        }
                      }
                    } catch (e) {
                      // Keep original if can't parse
                    }
                  }
                  // Handle simple variables
                  if (cleanContent.match(/^[a-zA-Z_][a-zA-Z0-9_]*$/)) {
                    cleanContent = `[variable: ${cleanContent}]`;
                  }
                  output += `${cleanContent}\n`;
                });
              }
            }
            
            if (code.includes('input(')) {
              output += 'Input: [Simulasi - masukan pengguna]\n';
            }
            
            if (code.includes('range(')) {
              output += 'Loop terdeteksi - eksekusi loop dalam simulasi\n';
            }

            // Simulate simple variable assignments
            const assignments = code.match(/^[a-zA-Z_][a-zA-Z0-9_]*\s*=\s*.+$/gm);
            if (assignments) {
              assignments.forEach(assignment => {
                const [varName] = assignment.split('=');
                output += `Variabel ${varName.trim()} telah diset\n`;
              });
            }
          } 
          
          else if (language === 'arduino') {
            output += '✓ Kompilasi berhasil\n';
            output += '✓ Upload ke board berhasil\n\n';
            
            if (code.includes('Serial.print')) {
              output += 'Serial Output:\n';
              const serialStatements = code.match(/Serial\.print[ln]*\([^)]*\)/g);
              if (serialStatements) {
                serialStatements.forEach(statement => {
                  const content = statement.match(/Serial\.print[ln]*\(([^)]*)\)/)?.[1] || '';
                  let cleanContent = content.replace(/["']/g, '');
                  // Handle simple variables
                  if (cleanContent.match(/^[a-zA-Z_][a-zA-Z0-9_]*$/)) {
                    cleanContent = `[${cleanContent} value]`;
                  }
                  output += `${cleanContent}\n`;
                });
              }
            }
            
            if (code.includes('digitalWrite')) {
              output += 'Pin digital diatur\n';
            }
            
            if (code.includes('analogRead')) {
              output += 'Analog reading: 512 (simulasi)\n';
            }
            
            if (code.includes('delay')) {
              output += 'Delay executed\n';
            }

            if (code.includes('setup()')) {
              output += 'Setup function dijalankan\n';
            }

            if (code.includes('loop()')) {
              output += 'Loop function berjalan...\n';
            }
          }
          
          else if (language === 'c' || language === 'cpp') {
            output += '✓ Kompilasi berhasil\n\n';
            
            if (code.includes('printf')) {
              output += 'Program Output:\n';
              const printfStatements = code.match(/printf\([^)]*\)/g);
              if (printfStatements) {
                printfStatements.forEach(statement => {
                  const content = statement.match(/printf\(([^)]*)\)/)?.[1] || '';
                  let cleanContent = content.replace(/["'\\n]/g, '');
                  // Handle format specifiers
                  if (cleanContent.includes('%d') || cleanContent.includes('%s')) {
                    cleanContent = cleanContent.replace(/%[ds]/g, '[value]');
                  }
                  output += `${cleanContent}\n`;
                });
              }
            }
            
            if (code.includes('scanf')) {
              output += 'Input: [Simulasi - masukan pengguna]\n';
            }

            if (code.includes('cout')) {
              output += 'C++ Output:\n';
              const coutStatements = code.match(/cout\s*<<[^;]+/g);
              if (coutStatements) {
                coutStatements.forEach(statement => {
                  const content = statement.replace(/cout\s*<<\s*/, '').replace(/["']/g, '');
                  output += `${content}\n`;
                });
              }
            }
          }

          if (!output.trim()) {
            output = `✓ Kode ${language} berhasil dijalankan\n✓ Tidak ada output yang ditampilkan\n\nCatatan: Ini adalah simulasi. Untuk eksekusi nyata, gunakan IDE atau compiler yang sesuai.`;
          } else {
            output += `\n✓ Eksekusi selesai\nCatatan: Ini adalah simulasi untuk tujuan pembelajaran.`;
          }

          resolve(output);
        } catch (error) {
          reject(new Error('Syntax error atau error dalam kode'));
        }
      }, 1000 + Math.random() * 2000); // Simulate compilation/execution time
    });
  };

  const stopExecution = () => {
    setIsRunning(false);
    setOutput(prev => prev + '\n\n⚠️ Eksekusi dihentikan oleh pengguna');
  };

  const clearOutput = () => {
    setOutput('');
    setError('');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Output</span>
          <div className="flex gap-2">
            {isRunning ? (
              <Button onClick={stopExecution} variant="destructive" size="sm">
                <Square className="w-4 h-4 mr-1" />
                Stop
              </Button>
            ) : (
              <Button onClick={runCode} size="sm">
                <Play className="w-4 h-4 mr-1" />
                Jalankan
              </Button>
            )}
            {(output || error) && (
              <Button onClick={clearOutput} variant="outline" size="sm">
                Clear
              </Button>
            )}
          </div>
        </CardTitle>
      </CardHeader>
      
      <CardContent>
        <div className="bg-slate-900 text-green-400 font-mono text-sm p-4 rounded-md min-h-[200px] max-h-[400px] overflow-y-auto">
          {isRunning && (
            <div className="text-yellow-400 mb-2">
              <div className="flex items-center gap-2">
                <div className="animate-spin h-4 w-4 border-2 border-yellow-400 border-t-transparent rounded-full"></div>
                Menjalankan kode {language}...
              </div>
            </div>
          )}
          
          {error && (
            <div className="text-red-400 mb-2 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <div>
                <div className="font-semibold">Error:</div>
                <div>{error}</div>
              </div>
            </div>
          )}
          
          {output && (
            <div className="whitespace-pre-wrap">
              {output}
            </div>
          )}
          
          {!isRunning && !output && !error && (
            <div className="text-gray-500 italic">
              Klik "Jalankan" untuk menjalankan kode Anda...
              <br />
              <br />
              💡 Tips:
              <br />
              • Python: gunakan print() untuk output
              <br />
              • Arduino: gunakan Serial.print() atau Serial.println()
              <br />
              • C/C++: gunakan printf() untuk output
            </div>
          )}
        </div>
        
        <div className="mt-2 text-xs text-gray-500">
          ⚠️ Ini adalah simulator untuk tujuan pembelajaran. Hasil mungkin berbeda dengan eksekusi sesungguhnya.
        </div>
      </CardContent>
    </Card>
  );
};

export default CodeRunner;
