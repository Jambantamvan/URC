
import { Link } from 'react-router-dom';
import { Project } from '@/types/supabase';
import ProjectCard from '@/components/ProjectCard';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';

interface ProfileProjectsProps {
  projects: Project[];
}

const ProfileProjects = ({ projects }: ProfileProjectsProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Proyek Anda</CardTitle>
        <CardDescription>
          Proyek robotik yang Anda ikuti atau pimpin
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        {projects.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {projects.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-500 mb-4">
              Anda belum memiliki proyek yang diikuti.
            </p>
            <Link 
              to="/projects/new" 
              className="bg-robo-blue hover:bg-robo-darkBlue text-white px-4 py-2 rounded-md"
            >
              Buat Proyek Baru
            </Link>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ProfileProjects;
