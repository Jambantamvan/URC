
import { Card } from '@/components/ui/card';

const ProfileSkeleton = () => {
  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
      <div className="flex-1 md:ml-64 pt-16 md:pt-0 p-6">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Profile header skeleton */}
          <div className="lg:col-span-1">
            <Card className="overflow-hidden">
              <div className="animate-pulse">
                <div className="p-8 flex justify-center">
                  <div className="w-24 h-24 bg-slate-200 dark:bg-slate-700 rounded-full"></div>
                </div>
                <div className="px-6 pb-6 space-y-4">
                  <div className="h-6 bg-slate-200 dark:bg-slate-700 rounded w-3/4 mx-auto"></div>
                  <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-1/2 mx-auto"></div>
                  <div className="h-8 bg-slate-200 dark:bg-slate-700 rounded w-1/3 mx-auto mt-4"></div>
                  
                  <div className="pt-4">
                    <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-1/4 mb-2"></div>
                    <div className="flex flex-wrap justify-center gap-2">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="h-6 w-16 bg-slate-200 dark:bg-slate-700 rounded-full"></div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="pt-4">
                    <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-1/4 mb-2"></div>
                    <div className="h-16 bg-slate-200 dark:bg-slate-700 rounded"></div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
          
          {/* Profile tabs skeleton */}
          <div className="lg:col-span-2">
            <div className="animate-pulse space-y-6">
              {/* Tabs header */}
              <div className="flex space-x-2">
                {[1, 2, 3].map(i => (
                  <div key={i} className="h-10 bg-slate-200 dark:bg-slate-700 rounded flex-1"></div>
                ))}
              </div>
              
              {/* Tab content */}
              <Card>
                <div className="p-6">
                  <div className="h-6 bg-slate-200 dark:bg-slate-700 rounded w-1/3 mb-4"></div>
                  <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-3/4 mb-6"></div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[1, 2, 3, 4].map(i => (
                      <div key={i} className="h-40 bg-slate-200 dark:bg-slate-700 rounded"></div>
                    ))}
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileSkeleton;
