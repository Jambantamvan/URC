
import { Profile } from '@/types/supabase';

interface ProfileHeaderProps {
  user: Profile;
}

const ProfileHeader = ({ user }: ProfileHeaderProps) => {
  return (
    <div className="bg-white dark:bg-robo-dark border-slate-200 dark:border-slate-700 rounded-lg border shadow-sm">
      <div className="pb-0 p-6">
        <div className="w-24 h-24 bg-robo-blue rounded-full text-white flex items-center justify-center text-4xl mx-auto">
          {user.name?.charAt(0) || 'U'}
        </div>
      </div>
      
      <div className="text-center pt-6 p-6">
        <h2 className="text-2xl font-bold mb-1">{user.name || 'User'}</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-3">{user.class || 'Tidak ada kelas'}</p>
        
        {user.division && (
          <div className="inline-flex items-center bg-robo-blue/10 text-robo-blue px-3 py-1 rounded-full text-sm font-medium">
            {user.division}
          </div>
        )}
        
        {user.skills && user.skills.length > 0 && (
          <div className="mt-6">
            <h3 className="font-medium mb-2 text-gray-700 dark:text-gray-300">Keahlian</h3>
            <div className="flex flex-wrap gap-2 justify-center">
              {user.skills.map((skill, index) => (
                <span 
                  key={index}
                  className="bg-gray-100 dark:bg-gray-700 px-3 py-1 rounded-full text-xs"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        )}
        
        <div className="mt-6 text-left">
          <h3 className="font-medium mb-2 text-gray-700 dark:text-gray-300">Bio</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            {user.bio || "Tidak ada bio tersedia."}
          </p>
        </div>
      </div>
    </div>
  );
};

export default ProfileHeader;
