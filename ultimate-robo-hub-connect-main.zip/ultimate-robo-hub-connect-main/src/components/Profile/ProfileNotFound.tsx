
import { Link } from 'react-router-dom';

const ProfileNotFound = () => {
  return (
    <div className="flex-1 md:ml-64 pt-16 md:pt-0 p-6 flex items-center justify-center">
      <div className="text-center">
        <h2 className="text-xl font-bold mb-2">User not found</h2>
        <p className="text-gray-600 dark:text-gray-300 mb-4">Could not load user profile</p>
        <Link to="/" className="text-robo-blue hover:underline">
          Return to Dashboard
        </Link>
      </div>
    </div>
  );
};

export default ProfileNotFound;
