
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';

const ProfileAchievements = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Prestasi</CardTitle>
        <CardDescription>
          Riwayat prestasi dalam kompetisi robotik
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <div className="text-center py-8">
          <p className="text-gray-500">
            Belum ada prestasi yang tercatat.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProfileAchievements;
