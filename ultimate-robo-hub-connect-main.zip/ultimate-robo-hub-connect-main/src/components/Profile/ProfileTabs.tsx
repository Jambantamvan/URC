
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Project } from '@/types/supabase';
import ProfileProjects from './ProfileProjects';
import ProfileAchievements from './ProfileAchievements';
import ProfileEditForm from './ProfileEditForm';

interface ProfileTabsProps {
  userProjects: Project[];
}

const ProfileTabs = ({ userProjects }: ProfileTabsProps) => {
  return (
    <Tabs defaultValue="projects" className="w-full">
      <TabsList className="grid grid-cols-3 mb-6">
        <TabsTrigger value="projects">Proyek</TabsTrigger>
        <TabsTrigger value="achievements">Prestasi</TabsTrigger>
        <TabsTrigger value="edit">Edit Profil</TabsTrigger>
      </TabsList>
      
      <TabsContent value="projects">
        <ProfileProjects projects={userProjects} />
      </TabsContent>
      
      <TabsContent value="achievements">
        <ProfileAchievements />
      </TabsContent>
      
      <TabsContent value="edit">
        <ProfileEditForm />
      </TabsContent>
    </Tabs>
  );
};

export default ProfileTabs;
