
import ProfileForm from '@/components/ProfileForm';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';

const ProfileEditForm = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Edit Profil</CardTitle>
        <CardDescription>
          Perbarui informasi profil Anda
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <ProfileForm />
      </CardContent>
    </Card>
  );
};

export default ProfileEditForm;
