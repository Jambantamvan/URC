
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import SecurityUtils from '@/utils/security';

const AuthForm = () => {
  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');
  const [isLoading, setIsLoading] = useState(false);
  
  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  
  // Register form state
  const [name, setName] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  const { signIn, signUp } = useAuth();
  
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Security validations
    if (!SecurityUtils.isValidEmail(loginEmail)) {
      SecurityUtils.logSecurityEvent('INVALID_EMAIL_LOGIN_ATTEMPT', { email: loginEmail });
      return;
    }
    
    if (!SecurityUtils.checkClientRateLimit(`login_${loginEmail}`, 5, 300000)) { // 5 attempts per 5 minutes
      SecurityUtils.logSecurityEvent('LOGIN_RATE_LIMIT_EXCEEDED', { email: loginEmail });
      alert('Terlalu banyak percobaan login. Coba lagi dalam 5 menit.');
      return;
    }

    console.log('Attempting login with:', { email: loginEmail, hasPassword: !!loginPassword });
    setIsLoading(true);
    try {
      const result = await signIn(loginEmail.trim(), loginPassword);
      console.log('Login result:', result);
      if (result.success) {
        SecurityUtils.logSecurityEvent('LOGIN_SUCCESS', { email: loginEmail });
        // Reset form on successful login
        setLoginEmail('');
        setLoginPassword('');
      } else {
        SecurityUtils.logSecurityEvent('LOGIN_FAILED', { email: loginEmail, error: result.error });
      }
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Security validations
    if (!SecurityUtils.isValidEmail(registerEmail)) {
      alert('Format email tidak valid');
      return;
    }
    
    const nameValidation = SecurityUtils.validateContent(name, 'text');
    if (!nameValidation.isValid) {
      alert('Nama mengandung karakter tidak valid: ' + nameValidation.errors.join(', '));
      return;
    }
    
    const passwordValidation = SecurityUtils.validatePassword(registerPassword);
    if (!passwordValidation.isValid) {
      alert('Password tidak memenuhi kriteria:\n' + passwordValidation.errors.join('\n'));
      return;
    }
    
    if (registerPassword !== confirmPassword) {
      alert('Password tidak cocok!');
      return;
    }
    
    if (!SecurityUtils.checkClientRateLimit(`register_${registerEmail}`, 3, 600000)) { // 3 attempts per 10 minutes
      SecurityUtils.logSecurityEvent('REGISTER_RATE_LIMIT_EXCEEDED', { email: registerEmail });
      alert('Terlalu banyak percobaan registrasi. Coba lagi dalam 10 menit.');
      return;
    }
    
    setIsLoading(true);
    try {
      const result = await signUp(registerEmail.trim(), registerPassword, nameValidation.sanitized);
      if (result.success) {
        SecurityUtils.logSecurityEvent('REGISTER_SUCCESS', { email: registerEmail });
        // Reset form after successful registration
        setName('');
        setRegisterEmail('');
        setRegisterPassword('');
        setConfirmPassword('');
        // Switch to login tab
        setActiveTab('login');
      } else {
        SecurityUtils.logSecurityEvent('REGISTER_FAILED', { email: registerEmail, error: result.error });
      }
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <Card className="w-full max-w-md mx-auto">
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'login' | 'register')}>
        <TabsList className="grid grid-cols-2 w-full">
          <TabsTrigger value="login">Masuk</TabsTrigger>
          <TabsTrigger value="register">Daftar</TabsTrigger>
        </TabsList>
        
        <TabsContent value="login">
          <form onSubmit={handleLogin}>
            <CardHeader>
              <CardTitle>Masuk</CardTitle>
              <CardDescription>
                Masuk ke akun Ultimate Robo Club Anda
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="login-email">Email</Label>
                <Input 
                  id="login-email" 
                  type="email" 
                  placeholder="email@example.com" 
                  required
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="login-password">Password</Label>
                </div>
                <Input 
                  id="login-password" 
                  type="password" 
                  required
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                />
              </div>
            </CardContent>
            
            <CardFooter>
              <Button className="w-full" type="submit" disabled={isLoading}>
                {isLoading ? "Memproses..." : "Login"}
              </Button>
            </CardFooter>
          </form>
        </TabsContent>
        
        <TabsContent value="register">
          <form onSubmit={handleRegister}>
            <CardHeader>
              <CardTitle>Daftar Akun</CardTitle>
              <CardDescription>
                Buat akun baru Ultimate Robo Club
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nama Lengkap</Label>
                <Input 
                  id="name" 
                  type="text" 
                  placeholder="John Doe" 
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="register-email">Email</Label>
                <Input 
                  id="register-email" 
                  type="email" 
                  placeholder="email@example.com" 
                  required
                  value={registerEmail}
                  onChange={(e) => setRegisterEmail(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="register-password">Password</Label>
                <Input 
                  id="register-password" 
                  type="password" 
                  required
                  value={registerPassword}
                  onChange={(e) => setRegisterPassword(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="confirm-password">Konfirmasi Password</Label>
                <Input 
                  id="confirm-password" 
                  type="password" 
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                />
              </div>
            </CardContent>
            
            <CardFooter>
              <Button className="w-full" type="submit" disabled={isLoading}>
                {isLoading ? "Memproses..." : "Daftar"}
              </Button>
            </CardFooter>
          </form>
        </TabsContent>
      </Tabs>
    </Card>
  );
};

export default AuthForm;
