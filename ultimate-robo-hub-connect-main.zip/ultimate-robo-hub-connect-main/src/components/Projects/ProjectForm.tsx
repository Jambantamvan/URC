import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/custom-client';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Profile } from '@/types/supabase';
import { ProjectMemberSelector } from './ProjectMemberSelector';

interface ProjectFormProps {
  currentUser: Profile;
}

export const ProjectForm: React.FC<ProjectFormProps> = ({ currentUser }) => {
  const navigate = useNavigate();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [division, setDivision] = useState<string>('none');
  const [status, setStatus] = useState('planning');
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  const [githubUrl, setGithubUrl] = useState('');
  const [demoUrl, setDemoUrl] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [projectMembers, setProjectMembers] = useState<Array<{
    user_id: string;
    role: string;
    user_name: string;
  }>>([]);

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) {
      toast.error('Judul proyek harus diisi');
      return;
    }
    
    if (!description.trim()) {
      toast.error('Deskripsi proyek harus diisi');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const newProject = {
        title: title.trim(),
        description: description.trim(),
        division: division === 'none' ? null : division,
        status,
        tags: tags.length > 0 ? tags : null,
        leader_id: currentUser.id,
        github_url: githubUrl.trim() || null,
        demo_url: demoUrl.trim() || null,
        image_url: imageUrl.trim() || null,
      };
      
      const { data, error } = await supabase
        .from('projects')
        .insert(newProject)
        .select();
      
      if (error) {
        throw error;
      }

      const createdProject = data[0];

      // Add project members if any
      if (projectMembers.length > 0 && createdProject) {
        const memberInserts = projectMembers.map(member => ({
          project_id: createdProject.id,
          user_id: member.user_id,
          role: member.role
        }));

        const { error: memberError } = await supabase
          .from('project_members')
          .insert(memberInserts);

        if (memberError) {
          console.error('Error adding project members:', memberError);
          toast.error('Proyek berhasil dibuat, tetapi gagal menambahkan beberapa anggota');
        }
      }
      
      toast.success('Proyek berhasil dibuat');
      
      // Use replace: true for immediate navigation without history stacking
      navigate('/projects', { replace: true });
      
    } catch (error) {
      console.error('Error creating project:', error);
      toast.error('Gagal membuat proyek');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleCreateProject} className="space-y-8">
      <div>
        <h2 className="text-xl font-semibold mb-4">Informasi Dasar</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label htmlFor="title" className="block text-sm font-medium">
              Judul Proyek
            </label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Masukkan judul proyek"
              required
            />
          </div>
          <div className="space-y-2">
            <label htmlFor="status" className="block text-sm font-medium">
              Status
            </label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Pilih status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="planning">Perencanaan</SelectItem>
                <SelectItem value="in-progress">Sedang Berjalan</SelectItem>
                <SelectItem value="completed">Selesai</SelectItem>
                <SelectItem value="archived">Ditunda</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="mt-4 space-y-2">
          <label htmlFor="description" className="block text-sm font-medium">
            Deskripsi
          </label>
          <Textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Ceritakan tentang proyek ini..."
            rows={5}
            required
          />
        </div>
        
        <div className="mt-4 space-y-2">
          <label htmlFor="division" className="block text-sm font-medium">
            Divisi
          </label>
          <Select value={division} onValueChange={setDivision}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Pilih divisi" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">Tidak ada divisi</SelectItem>
              <SelectItem value="web">Web Development</SelectItem>
              <SelectItem value="mobile">Mobile Development</SelectItem>
              <SelectItem value="ui_ux">UI/UX Design</SelectItem>
              <SelectItem value="data">Data Science</SelectItem>
              <SelectItem value="ai">Artificial Intelligence</SelectItem>
              <SelectItem value="game">Game Development</SelectItem>
              <SelectItem value="iot">Internet of Things</SelectItem>
              <SelectItem value="robotics">Robotics</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-4">Tag & Keywords</h2>
        <div className="space-y-2">
          <div className="flex gap-2">
            <Input
              id="tagInput"
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              placeholder="Tambahkan tag atau keyword"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddTag();
                }
              }}
            />
            <Button type="button" onClick={handleAddTag}>
              Tambah
            </Button>
          </div>
          
          {tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
              {tags.map((tag, index) => (
                <div
                  key={index}
                  className="bg-primary/10 text-primary px-2 py-1 rounded-md flex items-center gap-1"
                >
                  <span>{tag}</span>
                  <button
                    type="button"
                    className="text-primary hover:text-primary/70"
                    onClick={() => handleRemoveTag(tag)}
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-4">Link & Resources</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label htmlFor="githubUrl" className="block text-sm font-medium">
              GitHub URL
            </label>
            <Input
              id="githubUrl"
              value={githubUrl}
              onChange={(e) => setGithubUrl(e.target.value)}
              placeholder="https://github.com/username/repository"
            />
          </div>
          <div className="space-y-2">
            <label htmlFor="demoUrl" className="block text-sm font-medium">
              Demo URL
            </label>
            <Input
              id="demoUrl"
              value={demoUrl}
              onChange={(e) => setDemoUrl(e.target.value)}
              placeholder="https://example.com"
            />
          </div>
        </div>

        <div className="mt-4 space-y-2">
          <label htmlFor="imageUrl" className="block text-sm font-medium">
            Image URL
          </label>
          <Input
            id="imageUrl"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            placeholder="https://example.com/image.jpg"
          />
          <p className="text-sm text-gray-500">
            URL gambar yang merepresentasikan proyek Anda
          </p>
        </div>
      </div>

      {/* Project Members Section */}
      <div>
        <ProjectMemberSelector
          onMembersChange={setProjectMembers}
          currentMembers={projectMembers}
        />
      </div>

      <div className="flex items-center justify-end space-x-4 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={() => navigate('/projects', { replace: true })}
        >
          Batal
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Menyimpan...' : 'Buat Proyek'}
        </Button>
      </div>
    </form>
  );
};
