import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Plus, X } from 'lucide-react';
import { toast } from 'sonner';

interface User {
  id: string;
  name: string;
  role: string;
}

interface ProjectMember {
  user_id: string;
  role: string;
  user_name: string;
}

interface ProjectMemberSelectorProps {
  projectId?: string;
  onMembersChange: (members: ProjectMember[]) => void;
  currentMembers: ProjectMember[];
  disabled?: boolean;
}

export const ProjectMemberSelector: React.FC<ProjectMemberSelectorProps> = ({
  projectId,
  onMembersChange,
  currentMembers,
  disabled = false
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [availableUsers, setAvailableUsers] = useState<User[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [selectedRole, setSelectedRole] = useState<string>('member');

  useEffect(() => {
    fetchAvailableUsers();
  }, [currentMembers]);

  const fetchAvailableUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, name, role')
        .in('role', ['member', 'admin'])
        .not('name', 'is', null);

      if (error) throw error;

      // Filter out users who are already members
      const currentMemberIds = currentMembers.map(m => m.user_id);
      const filtered = data?.filter(user => !currentMemberIds.includes(user.id)) || [];
      
      setAvailableUsers(filtered);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error('Gagal memuat daftar pengguna');
    }
  };

  const handleAddMember = async () => {
    if (!selectedUserId) {
      toast.error('Pilih pengguna terlebih dahulu');
      return;
    }

    const selectedUser = availableUsers.find(u => u.id === selectedUserId);
    if (!selectedUser) return;

    const newMember: ProjectMember = {
      user_id: selectedUserId,
      role: selectedRole,
      user_name: selectedUser.name
    };

    // If we have a projectId, save to database
    if (projectId) {
      try {
        const { error } = await supabase
          .from('project_members')
          .insert({
            project_id: projectId,
            user_id: selectedUserId,
            role: selectedRole
          });

        if (error) throw error;
        toast.success(`${selectedUser.name} berhasil ditambahkan ke proyek`);
      } catch (error) {
        console.error('Error adding member:', error);
        toast.error('Gagal menambahkan anggota');
        return;
      }
    }

    // Update local state
    const updatedMembers = [...currentMembers, newMember];
    onMembersChange(updatedMembers);

    // Reset selections
    setSelectedUserId('');
    setSelectedRole('member');
    setIsOpen(false);
  };

  const handleRemoveMember = async (memberId: string) => {
    // If we have a projectId, remove from database
    if (projectId) {
      try {
        const { error } = await supabase
          .from('project_members')
          .delete()
          .eq('project_id', projectId)
          .eq('user_id', memberId);

        if (error) throw error;
        toast.success('Anggota berhasil dihapus');
      } catch (error) {
        console.error('Error removing member:', error);
        toast.error('Gagal menghapus anggota');
        return;
      }
    }

    // Update local state
    const updatedMembers = currentMembers.filter(m => m.user_id !== memberId);
    onMembersChange(updatedMembers);
  };

  const getRoleDisplayName = (role: string) => {
    switch (role) {
      case 'leader': return 'Pemimpin';
      case 'developer': return 'Developer';
      case 'designer': return 'Designer';
      case 'member': return 'Anggota';
      default: return role;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'leader': return 'bg-yellow-500';
      case 'developer': return 'bg-blue-500';
      case 'designer': return 'bg-purple-500';
      case 'member': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">Anggota Tim</h3>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm" disabled={disabled}>
              <Plus className="w-4 h-4 mr-2" />
              Tambah Anggota
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Tambah Anggota Tim</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Pilih Pengguna</label>
                <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih pengguna..." />
                  </SelectTrigger>
                  <SelectContent>
                    {availableUsers.map(user => (
                      <SelectItem key={user.id} value={user.id}>
                        <div className="flex items-center gap-2">
                          <Avatar className="w-6 h-6">
                            <AvatarFallback className="text-xs">
                              {user.name.charAt(0).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <span>{user.name}</span>
                          <Badge variant="secondary" className="text-xs">
                            {user.role}
                          </Badge>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium">Role dalam Proyek</label>
                <Select value={selectedRole} onValueChange={setSelectedRole}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="member">Anggota</SelectItem>
                    <SelectItem value="developer">Developer</SelectItem>
                    <SelectItem value="designer">Designer</SelectItem>
                    <SelectItem value="leader">Pemimpin</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsOpen(false)}>
                  Batal
                </Button>
                <Button onClick={handleAddMember}>
                  Tambah
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Current Members Display */}
      <div className="space-y-2">
        {currentMembers.length > 0 ? (
          currentMembers.map((member) => (
            <div
              key={member.user_id}
              className="flex items-center justify-between p-3 border rounded-lg"
            >
              <div className="flex items-center gap-3">
                <Avatar className="w-8 h-8">
                  <AvatarFallback>
                    {member.user_name.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{member.user_name}</p>
                  <Badge 
                    variant="secondary" 
                    className={`text-xs text-white ${getRoleColor(member.role)}`}
                  >
                    {getRoleDisplayName(member.role)}
                  </Badge>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleRemoveMember(member.user_id)}
                disabled={disabled}
                className="text-red-500 hover:text-red-700"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          ))
        ) : (
          <p className="text-muted-foreground text-sm">Belum ada anggota tim</p>
        )}
      </div>
    </div>
  );
};