import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Users } from 'lucide-react';

interface ProjectMember {
  user_id: string;
  role: string;
  user_name: string;
}

interface ProjectMembersDisplayProps {
  projectId: string;
  projectLeaderId?: string;
  projectLeaderName?: string;
}

export const ProjectMembersDisplay: React.FC<ProjectMembersDisplayProps> = ({
  projectId,
  projectLeaderId,
  projectLeaderName
}) => {
  const [members, setMembers] = useState<ProjectMember[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchProjectMembers();
  }, [projectId]);

  const fetchProjectMembers = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('project_members')
        .select(`
          user_id,
          role,
          profiles!project_members_user_id_fkey(name)
        `)
        .eq('project_id', projectId);

      if (error) throw error;

      const membersData = data?.map(member => ({
        user_id: member.user_id!,
        role: member.role,
        user_name: (member as any).profiles?.name || 'Unknown'
      })) || [];

      setMembers(membersData);
    } catch (error) {
      console.error('Error fetching project members:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getRoleDisplayName = (role: string) => {
    switch (role) {
      case 'leader': return 'Pemimpin';
      case 'developer': return 'Developer';
      case 'designer': return 'Designer';
      case 'member': return 'Anggota';
      default: return role;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'leader': return 'bg-yellow-500';
      case 'developer': return 'bg-blue-500';
      case 'designer': return 'bg-purple-500';
      case 'member': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Tim Proyek
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-3">
            <div className="h-12 bg-muted rounded"></div>
            <div className="h-12 bg-muted rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Combine project leader and members
  const allTeamMembers = [];
  
  // Add project leader first
  if (projectLeaderId && projectLeaderName) {
    allTeamMembers.push({
      user_id: projectLeaderId,
      role: 'project_leader',
      user_name: projectLeaderName
    });
  }

  // Add other members
  allTeamMembers.push(...members);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="w-5 h-5" />
          Tim Proyek ({allTeamMembers.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        {allTeamMembers.length > 0 ? (
          <div className="space-y-3">
            {allTeamMembers.map((member, index) => (
              <div
                key={`${member.user_id}-${index}`}
                className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Avatar className="w-10 h-10">
                    <AvatarFallback className="text-sm font-medium">
                      {member.user_name.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-sm">{member.user_name}</p>
                    <p className="text-xs text-muted-foreground">
                      {member.role === 'project_leader' ? 'Pemimpin Proyek' : getRoleDisplayName(member.role)}
                    </p>
                  </div>
                </div>
                <Badge 
                  variant="secondary" 
                  className={`text-xs text-white ${
                    member.role === 'project_leader' 
                      ? 'bg-green-500' 
                      : getRoleColor(member.role)
                  }`}
                >
                  {member.role === 'project_leader' ? 'Pemimpin Proyek' : getRoleDisplayName(member.role)}
                </Badge>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6 text-muted-foreground">
            <Users className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p className="text-sm">Belum ada anggota tim yang ditambahkan</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};