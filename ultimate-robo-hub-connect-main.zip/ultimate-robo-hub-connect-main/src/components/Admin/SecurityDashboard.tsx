import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/custom-client';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Shield, 
  AlertTriangle, 
  Eye, 
  Lock, 
  Activity,
  UserX,
  Database,
  RefreshCw
} from 'lucide-react';
import { toast } from 'sonner';

interface SecurityLog {
  id: string;
  user_id?: string | null;
  action: string;
  resource?: string | null;
  ip_address?: string | null;
  user_agent?: string | null;
  created_at: string;
  metadata?: any;
}

interface FailedLoginAttempt {
  id: string;
  email: string;
  ip_address?: string | null;
  user_agent?: string | null;
  attempted_at: string;
  reason?: string | null;
}

const SecurityDashboard = () => {
  const { profile } = useAuth();
  const [securityLogs, setSecurityLogs] = useState<SecurityLog[]>([]);
  const [failedLogins, setFailedLogins] = useState<FailedLoginAttempt[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({
    totalLogs: 0,
    failedLoginsToday: 0,
    suspiciousActivity: 0,
    activeUsers: 0
  });

  useEffect(() => {
    if (profile?.role === 'admin') {
      loadSecurityData();
    }
  }, [profile]);

  const loadSecurityData = async () => {
    setIsLoading(true);
    try {
      // Load security logs
      const { data: logs, error: logsError } = await supabase
        .from('security_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (logsError) throw logsError;
      setSecurityLogs((logs || []) as SecurityLog[]);

      // Load failed login attempts
      const { data: failedAttempts, error: failedError } = await supabase
        .from('failed_login_attempts')
        .select('*')
        .order('attempted_at', { ascending: false })
        .limit(50);

      if (failedError) throw failedError;
      setFailedLogins((failedAttempts || []) as FailedLoginAttempt[]);

      // Calculate stats
      const today = new Date().toISOString().split('T')[0];
      const failedLoginsToday = (failedAttempts || []).filter(
        attempt => attempt.attempted_at.startsWith(today)
      ).length;

      const suspiciousActivity = (logs || []).filter(
        log => log.action.includes('RATE_LIMIT') || log.action.includes('SUSPICIOUS')
      ).length;

      setStats({
        totalLogs: logs?.length || 0,
        failedLoginsToday,
        suspiciousActivity,
        activeUsers: 0 // This would need additional query
      });

    } catch (error) {
      console.error('Error loading security data:', error);
      toast.error('Gagal memuat data keamanan');
    } finally {
      setIsLoading(false);
    }
  };

  const getActionBadgeColor = (action: string) => {
    if (action.includes('SUCCESS')) return 'success';
    if (action.includes('FAILED') || action.includes('ERROR')) return 'destructive';
    if (action.includes('RATE_LIMIT') || action.includes('SUSPICIOUS')) return 'warning';
    return 'secondary';
  };

  const clearOldLogs = async () => {
    try {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      await supabase
        .from('security_logs')
        .delete()
        .lt('created_at', thirtyDaysAgo.toISOString());

      await supabase
        .from('failed_login_attempts')
        .delete()
        .lt('attempted_at', thirtyDaysAgo.toISOString());

      toast.success('Log lama berhasil dibersihkan');
      loadSecurityData();
    } catch (error) {
      toast.error('Gagal membersihkan log lama');
    }
  };

  if (profile?.role !== 'admin') {
    return (
      <div className="p-6">
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Anda tidak memiliki akses ke dashboard keamanan ini.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Shield className="h-8 w-8" />
          Dashboard Keamanan
        </h1>
        <div className="flex gap-2">
          <Button onClick={loadSecurityData} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button onClick={clearOldLogs} variant="outline" size="sm">
            <Database className="h-4 w-4 mr-2" />
            Bersihkan Log Lama
          </Button>
        </div>
      </div>

      {/* Security Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Log</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalLogs}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Login Gagal Hari Ini</CardTitle>
            <UserX className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.failedLoginsToday}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Aktivitas Mencurigakan</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats.suspiciousActivity}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Status Sistem</CardTitle>
            <Lock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">Aman</div>
          </CardContent>
        </Card>
      </div>

      {/* Failed Login Attempts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserX className="h-5 w-5" />
            Percobaan Login Gagal Terbaru
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-4">Loading...</div>
          ) : failedLogins.length === 0 ? (
            <div className="text-center py-4 text-muted-foreground">
              Tidak ada percobaan login gagal
            </div>
          ) : (
            <div className="space-y-2">
              {failedLogins.slice(0, 10).map((attempt) => (
                <div key={attempt.id} className="flex items-center justify-between p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                  <div>
                    <div className="font-medium">{attempt.email}</div>
                    <div className="text-sm text-muted-foreground">
                      IP: {attempt.ip_address || 'Unknown'} • 
                      {new Date(attempt.attempted_at).toLocaleString('id-ID')}
                    </div>
                    {attempt.reason && (
                      <div className="text-xs text-red-600 mt-1">
                        Alasan: {attempt.reason}
                      </div>
                    )}
                  </div>
                  <Badge variant="destructive">Gagal</Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Security Logs */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            Log Keamanan Terbaru
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-4">Loading...</div>
          ) : securityLogs.length === 0 ? (
            <div className="text-center py-4 text-muted-foreground">
              Tidak ada log keamanan
            </div>
          ) : (
            <div className="space-y-2">
              {securityLogs.slice(0, 20).map((log) => (
                <div key={log.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Badge variant={getActionBadgeColor(log.action) as any}>
                        {log.action}
                      </Badge>
                      {log.resource && (
                        <span className="text-sm text-muted-foreground">
                          {log.resource}
                        </span>
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">
                      User: {log.user_id || 'System'} • 
                      IP: {log.ip_address || 'Unknown'} • 
                      {new Date(log.created_at).toLocaleString('id-ID')}
                    </div>
                    {log.metadata && (
                      <details className="text-xs text-muted-foreground mt-1">
                        <summary className="cursor-pointer">Detail Metadata</summary>
                        <pre className="mt-1 p-2 bg-gray-100 dark:bg-gray-700 rounded text-xs overflow-auto">
                          {JSON.stringify(log.metadata, null, 2)}
                        </pre>
                      </details>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default SecurityDashboard;