import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';

interface UserWarning {
  id: string;
  user_id: string;
  admin_id: string;
  reason: string;
  type: 'warning' | 'punishment';
  severity: 'minor' | 'major' | 'severe';
  description: string;
  expires_at: string | null;
  created_at: string;
  is_active: boolean;
  user_name?: string;
  admin_name?: string;
}

interface User {
  id: string;
  name: string;
  role: string;
}

const WARNING_REASONS = [
  'Sexual Harassment',
  'Spam',
  'Inappropriate Content',
  'Bullying',
  'Hate Speech',
  'Rule Violation',
  'Disruptive Behavior',
  'Other'
];

export const UserWarningsManager: React.FC = () => {
  const { user, profile } = useAuth();
  const [warnings, setWarnings] = useState<UserWarning[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // Form states
  const [selectedUserId, setSelectedUserId] = useState('');
  const [warningType, setWarningType] = useState<'warning' | 'punishment'>('warning');
  const [severity, setSeverity] = useState<'minor' | 'major' | 'severe'>('minor');
  const [reason, setReason] = useState('');
  const [customReason, setCustomReason] = useState('');
  const [description, setDescription] = useState('');
  const [expiresInDays, setExpiresInDays] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (profile?.role === 'admin') {
      fetchWarnings();
      fetchUsers();
    }
  }, [profile]);

  const fetchWarnings = async () => {
    try {
      const { data, error } = await supabase
        .from('user_warnings')
        .select(`
          *,
          user_profile:profiles!user_warnings_user_id_fkey(name),
          admin_profile:profiles!user_warnings_admin_id_fkey(name)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const warningsWithNames = data.map(warning => ({
        ...warning,
        user_name: (warning as any).user_profile?.name || 'Unknown User',
        admin_name: (warning as any).admin_profile?.name || 'Unknown Admin'
      }));

      setWarnings(warningsWithNames as UserWarning[]);
    } catch (error) {
      console.error('Error fetching warnings:', error);
      toast.error('Gagal memuat data warning');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, name, role')
        .not('name', 'is', null)
        .neq('role', 'admin');

      if (error) throw error;
      setUsers(data as User[]);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const handleSubmitWarning = async () => {
    if (!user || !selectedUserId || !reason) {
      toast.error('Mohon lengkapi semua field yang wajib diisi');
      return;
    }

    setIsSubmitting(true);

    try {
      const finalReason = reason === 'Other' ? customReason : reason;
      const expiresAt = expiresInDays ? 
        new Date(Date.now() + (expiresInDays * 24 * 60 * 60 * 1000)).toISOString() : 
        null;

      const { error } = await supabase
        .from('user_warnings')
        .insert({
          user_id: selectedUserId,
          admin_id: user.id,
          reason: finalReason,
          type: warningType,
          severity: severity,
          description: description || null,
          expires_at: expiresAt,
          is_active: true
        });

      if (error) throw error;

      toast.success('Warning berhasil diberikan');
      setIsDialogOpen(false);
      resetForm();
      fetchWarnings();
    } catch (error) {
      console.error('Error creating warning:', error);
      toast.error('Gagal memberikan warning');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setSelectedUserId('');
    setWarningType('warning');
    setSeverity('minor');
    setReason('');
    setCustomReason('');
    setDescription('');
    setExpiresInDays(null);
  };

  const deactivateWarning = async (warningId: string) => {
    try {
      const { error } = await supabase
        .from('user_warnings')
        .update({ is_active: false })
        .eq('id', warningId);

      if (error) throw error;

      toast.success('Warning berhasil dinonaktifkan');
      fetchWarnings();
    } catch (error) {
      console.error('Error deactivating warning:', error);
      toast.error('Gagal menonaktifkan warning');
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'minor': return 'bg-yellow-100 text-yellow-800';
      case 'major': return 'bg-orange-100 text-orange-800';
      case 'severe': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (profile?.role !== 'admin') {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">Anda tidak memiliki akses ke halaman ini.</p>
      </div>
    );
  }

  if (isLoading) {
    return <div className="animate-pulse">Memuat data warnings...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Manajemen Warning & Punishment</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>Berikan Warning</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Berikan Warning/Punishment</DialogTitle>
              <DialogDescription>
                Berikan peringatan atau hukuman kepada anggota yang melanggar aturan.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Pilih Anggota</label>
                <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih anggota" />
                  </SelectTrigger>
                  <SelectContent>
                    {users.map((user) => (
                      <SelectItem key={user.id} value={user.id}>
                        {user.name} ({user.role})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Jenis</label>
                  <Select value={warningType} onValueChange={(value: 'warning' | 'punishment') => setWarningType(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="warning">Warning</SelectItem>
                      <SelectItem value="punishment">Punishment</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Tingkat</label>
                  <Select value={severity} onValueChange={(value: 'minor' | 'major' | 'severe') => setSeverity(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="minor">Ringan</SelectItem>
                      <SelectItem value="major">Sedang</SelectItem>
                      <SelectItem value="severe">Berat</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Alasan</label>
                <Select value={reason} onValueChange={setReason}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih alasan" />
                  </SelectTrigger>
                  <SelectContent>
                    {WARNING_REASONS.map((reasonOption) => (
                      <SelectItem key={reasonOption} value={reasonOption}>
                        {reasonOption}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {reason === 'Other' && (
                <div className="space-y-2">
                  <label className="text-sm font-medium">Alasan Lainnya</label>
                  <Input
                    value={customReason}
                    onChange={(e) => setCustomReason(e.target.value)}
                    placeholder="Masukkan alasan"
                  />
                </div>
              )}

              <div className="space-y-2">
                <label className="text-sm font-medium">Deskripsi (Opsional)</label>
                <Textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Detail tambahan tentang pelanggaran"
                />
              </div>

              {warningType === 'punishment' && (
                <div className="space-y-2">
                  <label className="text-sm font-medium">Berlaku Selama (Hari)</label>
                  <Input
                    type="number"
                    value={expiresInDays || ''}
                    onChange={(e) => setExpiresInDays(parseInt(e.target.value) || null)}
                    placeholder="Contoh: 7"
                  />
                </div>
              )}
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Batal
              </Button>
              <Button onClick={handleSubmitWarning} disabled={isSubmitting}>
                {isSubmitting ? 'Menyimpan...' : 'Berikan Warning'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Anggota</TableHead>
              <TableHead>Jenis</TableHead>
              <TableHead>Tingkat</TableHead>
              <TableHead>Alasan</TableHead>
              <TableHead>Admin</TableHead>
              <TableHead>Tanggal</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Aksi</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {warnings.length > 0 ? (
              warnings.map((warning) => (
                <TableRow key={warning.id}>
                  <TableCell className="font-medium">{warning.user_name}</TableCell>
                  <TableCell>
                    <Badge variant={warning.type === 'warning' ? 'secondary' : 'destructive'}>
                      {warning.type === 'warning' ? 'Warning' : 'Punishment'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded-full text-xs ${getSeverityColor(warning.severity)}`}>
                      {warning.severity === 'minor' ? 'Ringan' :
                       warning.severity === 'major' ? 'Sedang' : 'Berat'}
                    </span>
                  </TableCell>
                  <TableCell>{warning.reason}</TableCell>
                  <TableCell>{warning.admin_name}</TableCell>
                  <TableCell>{formatDate(warning.created_at)}</TableCell>
                  <TableCell>
                    <Badge variant={warning.is_active ? 'default' : 'secondary'}>
                      {warning.is_active ? 'Aktif' : 'Nonaktif'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {warning.is_active && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => deactivateWarning(warning.id)}
                      >
                        Nonaktifkan
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={8} className="text-center">
                  Tidak ada warning ditemukan
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};