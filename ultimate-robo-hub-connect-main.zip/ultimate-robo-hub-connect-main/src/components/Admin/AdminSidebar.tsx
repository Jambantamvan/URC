
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Users, 
  UserPlus, 
  Settings, 
  ArrowLeft,
  Calendar,
  BookOpen,
  MessageSquare,
  FileText,
  AlertTriangle,
  BarChart3
} from 'lucide-react';

const AdminSidebar = () => {
  const location = useLocation();
  const pathname = location.pathname;

  const menuItems = [
    {
      title: 'Dashboard',
      path: '/admin',
      icon: <BarChart3 className="w-5 h-5" />
    },
    {
      title: 'Users',
      path: '/admin/users',
      icon: <Users className="w-5 h-5" />
    },
    {
      title: 'Pendaftaran',
      path: '/admin/registrations',
      icon: <UserPlus className="w-5 h-5" />
    },
    {
      title: 'Warnings',
      path: '/admin/warnings',
      icon: <AlertTriangle className="w-5 h-5" />
    },
    {
      title: 'Events',
      path: '/admin/events',
      icon: <Calendar className="w-5 h-5" />
    },
    {
      title: 'Learning Materials',
      path: '/admin/materials',
      icon: <BookOpen className="w-5 h-5" />
    },
    {
      title: 'Forum',
      path: '/admin/forum',
      icon: <MessageSquare className="w-5 h-5" />
    },
    {
      title: 'Projects',
      path: '/admin/projects',
      icon: <FileText className="w-5 h-5" />
    },
  ];

  return (
    <div className="bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 w-64 min-h-screen fixed left-0 top-0 shadow-sm z-50">
      <div className="p-4 border-b border-slate-200 dark:border-slate-700 bg-robo-blue text-white">
        <h2 className="text-lg font-bold">Admin Panel</h2>
      </div>
      
      <div className="p-2 overflow-y-auto h-[calc(100vh-132px)]">
        {menuItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`flex items-center gap-3 px-4 py-3 rounded-md mb-1 transition-colors ${
              pathname === item.path
                ? 'bg-robo-blue text-white'
                : 'text-gray-600 dark:text-gray-300 hover:bg-robo-blue/10'
            }`}
          >
            {item.icon}
            <span>{item.title}</span>
          </Link>
        ))}
      </div>
      
      <div className="absolute bottom-0 w-full p-4 border-t border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
        <Link
          to="/"
          className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 hover:text-robo-blue dark:hover:text-robo-blue transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali ke Aplikasi</span>
        </Link>
      </div>
    </div>
  );
};

export default AdminSidebar;
