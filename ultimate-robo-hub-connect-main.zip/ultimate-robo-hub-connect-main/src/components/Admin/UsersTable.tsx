
import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import { UserProfile, UserRole, useAuth } from '@/contexts/AuthContext';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { Loader2 } from 'lucide-react';

const UsersTable = () => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { profile, refreshProfile } = useAuth();

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      console.log("Fetching users data...");
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error("Error fetching users:", error);
        throw error;
      }
      
      console.log("Users data fetched:", data);
      setUsers(data as UserProfile[]);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error('Gagal memuat daftar pengguna');
    } finally {
      setIsLoading(false);
    }
  };

  const updateUserRole = async (userId: string, newRole: UserRole) => {
    try {
      console.log(`Updating user ${userId} to role ${newRole}`);
      
      const { data, error } = await supabase
        .from('profiles')
        .update({ 
          role: newRole,
          updated_at: new Date().toISOString()
        })
        .eq('id', userId)
        .select()
        .single();

      if (error) {
        console.error("Error updating role:", error);
        throw error;
      }
      
      console.log("Role updated successfully:", data);
      
      // Update local state
      setUsers(users.map(user => 
        user.id === userId ? {...user, role: newRole, updated_at: data.updated_at} : user
      ));
      
      // Refresh current user profile if we're updating our own role
      if (profile && userId === profile.id) {
        await refreshProfile();
      }
      
      toast.success(`Role pengguna berhasil diupdate ke ${newRole} dan disimpan ke database`);
    } catch (error) {
      console.error('Error updating user role:', error);
      toast.error('Gagal mengupdate role pengguna');
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-robo-blue" />
        <span className="ml-2">Memuat data pengguna...</span>
      </div>
    );
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Nama</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Kelas</TableHead>
            <TableHead>Role</TableHead>
            <TableHead>Aksi</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {users.length > 0 ? (
            users.map((user) => (
              <TableRow key={user.id}>
                <TableCell className="font-medium">{user.name || '-'}</TableCell>
                <TableCell>{user.email || '-'}</TableCell>
                <TableCell>{user.class || '-'}</TableCell>
                <TableCell>
                  <Select
                    disabled={user.id === profile?.id}
                    defaultValue={user.role || undefined}
                    onValueChange={(value) => 
                      updateUserRole(user.id, value as UserRole)
                    }
                  >
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder={user.role || 'non-member'} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="non-member">Non-member</SelectItem>
                      <SelectItem value="member">Member</SelectItem>
                      <SelectItem value="admin">Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </TableCell>
                <TableCell>
                  <Button 
                    variant="outline" 
                    size="sm"
                    disabled={user.id === profile?.id}
                    onClick={() => {
                      // Functionality to view details could be added here
                      toast.info(`Detail untuk ${user.name} akan ditampilkan.`);
                    }}
                  >
                    Detail
                  </Button>
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={5} className="text-center">
                Tidak ada pengguna ditemukan
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
};

export default UsersTable;
