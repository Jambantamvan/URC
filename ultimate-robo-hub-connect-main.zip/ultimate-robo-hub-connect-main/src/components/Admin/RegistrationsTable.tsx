
import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import { useAuth } from '@/contexts/AuthContext';
import { RegistrationRequest } from '@/types/supabase';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';

const RegistrationsTable = () => {
  const [registrations, setRegistrations] = useState<RegistrationRequest[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedRegistration, setSelectedRegistration] = useState<RegistrationRequest | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    fetchRegistrations();
  }, []);

  const fetchRegistrations = async () => {
    try {
      const { data, error } = await supabase
        .from('registration_requests')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRegistrations(data as RegistrationRequest[]);
    } catch (error) {
      console.error('Error fetching registrations:', error);
      toast.error('Gagal memuat daftar pendaftaran');
    } finally {
      setIsLoading(false);
    }
  };

  const handleViewDetails = (registration: RegistrationRequest) => {
    setSelectedRegistration(registration);
    setIsDialogOpen(true);
  };

  const updateRegistrationStatus = async (registrationId: string, newStatus: string) => {
    if (!user) return;
    
    try {
      const { error } = await supabase
        .from('registration_requests')
        .update({
          status: newStatus,
          reviewed_at: new Date().toISOString(),
          reviewed_by: user.id
        })
        .eq('id', registrationId);

      if (error) throw error;
      
      // If approving, update user role to member
      if (newStatus === 'approved') {
        const registration = registrations.find(r => r.id === registrationId);
        if (registration) {
          const { error: roleError } = await supabase
            .from('profiles')
            .update({ role: 'member' })
            .eq('id', registration.user_id);
            
          if (roleError) throw roleError;
        }
      }
      
      // Update local state
      setRegistrations(registrations.map(reg => 
        reg.id === registrationId ? {...reg, status: newStatus} : reg
      ));
      
      toast.success(`Status pendaftaran berhasil diupdate ke ${newStatus}`);
      setIsDialogOpen(false);
    } catch (error) {
      console.error('Error updating registration status:', error);
      toast.error('Gagal mengupdate status pendaftaran');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  if (isLoading) {
    return <div className="animate-pulse">Memuat data pendaftaran...</div>;
  }

  return (
    <>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nama</TableHead>
              <TableHead>Kelas</TableHead>
              <TableHead>Tanggal Daftar</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Aksi</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {registrations.length > 0 ? (
              registrations.map((registration) => (
                <TableRow key={registration.id}>
                  <TableCell className="font-medium">{registration.name}</TableCell>
                  <TableCell>{registration.class}</TableCell>
                  <TableCell>{formatDate(registration.created_at)}</TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      registration.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      registration.status === 'approved' ? 'bg-green-100 text-green-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {registration.status === 'pending' ? 'Menunggu' :
                       registration.status === 'approved' ? 'Disetujui' : 'Ditolak'}
                    </span>
                  </TableCell>
                  <TableCell>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleViewDetails(registration)}
                    >
                      Detail
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={5} className="text-center">
                  Tidak ada pendaftaran ditemukan
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {selectedRegistration && (
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Detail Pendaftaran</DialogTitle>
              <DialogDescription>
                Form pendaftaran dari {selectedRegistration.name}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="space-y-1">
                <p className="text-sm font-medium">Nama Lengkap</p>
                <p className="text-sm text-slate-700 dark:text-slate-300">{selectedRegistration.name}</p>
              </div>
              
              <div className="space-y-1">
                <p className="text-sm font-medium">Tanggal Lahir</p>
                <p className="text-sm text-slate-700 dark:text-slate-300">
                  {formatDate(selectedRegistration.birth_date)}
                </p>
              </div>
              
              <div className="space-y-1">
                <p className="text-sm font-medium">Kelas</p>
                <p className="text-sm text-slate-700 dark:text-slate-300">{selectedRegistration.class}</p>
              </div>
              
              <div className="space-y-1">
                <p className="text-sm font-medium">Alasan</p>
                <p className="text-sm text-slate-700 dark:text-slate-300 whitespace-pre-line">
                  {selectedRegistration.reason}
                </p>
              </div>
              
              <div className="space-y-1">
                <p className="text-sm font-medium">Skill yang Ingin Dikembangkan</p>
                <p className="text-sm text-slate-700 dark:text-slate-300">
                  {Array.isArray(selectedRegistration.skills_to_develop) 
                    ? selectedRegistration.skills_to_develop.join(', ')
                    : selectedRegistration.skills_to_develop}
                </p>
              </div>
              
              <div className="space-y-1">
                <p className="text-sm font-medium">Status</p>
                <p className={`text-sm ${
                  selectedRegistration.status === 'pending' ? 'text-yellow-600' :
                  selectedRegistration.status === 'approved' ? 'text-green-600' :
                  'text-red-600'
                }`}>
                  {selectedRegistration.status === 'pending' ? 'Menunggu persetujuan' :
                   selectedRegistration.status === 'approved' ? 'Disetujui' : 'Ditolak'}
                </p>
              </div>
            </div>
            
            <DialogFooter className="sm:justify-between">
              {selectedRegistration.status === 'pending' ? (
                <>
                  <Button
                    variant="outline"
                    onClick={() => updateRegistrationStatus(selectedRegistration.id, 'rejected')}
                  >
                    Tolak
                  </Button>
                  <Button
                    onClick={() => updateRegistrationStatus(selectedRegistration.id, 'approved')}
                  >
                    Setujui
                  </Button>
                </>
              ) : (
                <Button
                  onClick={() => setIsDialogOpen(false)}
                  className="w-full"
                >
                  Tutup
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
};

export default RegistrationsTable;
