import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import { useAuth } from '@/contexts/AuthContext';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface UserPresence {
  id: string;
  user_id: string;
  status: 'online' | 'offline' | 'busy';
  last_seen: string;
  user_name?: string;
}

interface UserPresenceManagerProps {
  showMembersList?: boolean;
}

export const UserPresenceManager: React.FC<UserPresenceManagerProps> = ({ 
  showMembersList = false 
}) => {
  const { user, profile } = useAuth();
  const [userStatus, setUserStatus] = useState<'online' | 'offline' | 'busy'>('offline');
  const [allUsers, setAllUsers] = useState<UserPresence[]>([]);

  useEffect(() => {
    if (!user) return;

    // Initialize user presence
    const initializePresence = async () => {
      const { data: existingPresence } = await supabase
        .from('user_presence')
        .select('status')
        .eq('user_id', user.id)
        .single();

      if (existingPresence) {
        setUserStatus(existingPresence.status as 'online' | 'offline' | 'busy');
      } else {
        // Create initial presence record
        await supabase.from('user_presence').insert({
          user_id: user.id,
          status: 'online'
        });
        setUserStatus('online');
      }
    };

    initializePresence();

    // Fetch all users if showing members list
    if (showMembersList) {
      fetchAllUsers();
    }

    // Set up realtime subscription for presence updates with heavy debouncing
    let updateTimeout: NodeJS.Timeout;
    const channel = supabase
      .channel('user_presence_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'user_presence'
        },
        () => {
          if (showMembersList) {
            // Heavy debouncing to prevent rapid changes
            clearTimeout(updateTimeout);
            updateTimeout = setTimeout(() => {
              fetchAllUsers();
            }, 5000); // Wait 5 seconds before updating
          }
        }
      )
      .subscribe();

    // Update status to online when component mounts
    updateUserStatus('online');

    // Set up activity tracking
    const updateActivity = () => {
      if (userStatus !== 'offline') {
        updateUserStatus(userStatus);
      }
    };

    const activityEvents = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    activityEvents.forEach(event => {
      window.addEventListener(event, updateActivity);
    });

    // Set up periodic presence updates (much less frequent)
    const presenceInterval = setInterval(() => {
      if (userStatus !== 'offline') {
        updateUserStatus(userStatus);
      }
    }, 120000); // Update every 2 minutes instead of 60 seconds

    // Handle page visibility changes
    const handleVisibilityChange = () => {
      if (document.hidden) {
        updateUserStatus('offline');
      } else {
        updateUserStatus(userStatus === 'offline' ? 'online' : userStatus);
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Handle page unload
    const handleBeforeUnload = () => {
      updateUserStatus('offline');
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      // Cleanup
      activityEvents.forEach(event => {
        window.removeEventListener(event, updateActivity);
      });
      clearInterval(presenceInterval);
      clearTimeout(updateTimeout);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      supabase.removeChannel(channel);
      
      // Set status to offline on cleanup
      updateUserStatus('offline');
    };
  }, [user, userStatus, showMembersList]);

  const fetchAllUsers = async () => {
    const { data } = await supabase
      .from('user_presence')
      .select(`
        *,
        profiles!user_presence_user_id_fkey(name)
      `)
      .order('status', { ascending: false })
      .order('last_seen', { ascending: false });

    if (data) {
      const usersWithNames = data.map(user => ({
        ...user,
        status: user.status as 'online' | 'offline' | 'busy',
        user_name: (user as any).profiles?.name || 'Unknown User'
      }));
      setAllUsers(usersWithNames as UserPresence[]);
    }
  };

  const updateUserStatus = async (status: 'online' | 'offline' | 'busy') => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('user_presence')
        .upsert({
          user_id: user.id,
          status: status,
          last_seen: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }, {
          onConflict: 'user_id'
        });

      if (!error) {
        setUserStatus(status);
      }
    } catch (error) {
      console.error('Error updating user status:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'busy': return 'bg-yellow-500';
      case 'offline': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'online': return 'Online';
      case 'busy': return 'Sibuk';
      case 'offline': return 'Offline';
      default: return 'Unknown';
    }
  };

  const formatLastSeen = (lastSeen: string) => {
    const now = new Date();
    const lastSeenDate = new Date(lastSeen);
    const diffMs = now.getTime() - lastSeenDate.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 1) return 'Baru saja';
    if (diffMins < 60) return `${diffMins} menit yang lalu`;
    if (diffHours < 24) return `${diffHours} jam yang lalu`;
    return `${diffDays} hari yang lalu`;
  };

  const UserStatusBadge = ({ status, className = "" }: { status: string; className?: string }) => (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className={`w-3 h-3 rounded-full ${getStatusColor(status)}`} />
      <span className="text-sm">{getStatusText(status)}</span>
    </div>
  );

  if (!showMembersList) {
    return (
      <div className="flex items-center gap-4">
        <UserStatusBadge status={userStatus} />
        <Select value={userStatus} onValueChange={(value: 'online' | 'offline' | 'busy') => updateUserStatus(value)}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="online">Online</SelectItem>
            <SelectItem value="busy">Sibuk</SelectItem>
            <SelectItem value="offline">Offline</SelectItem>
          </SelectContent>
        </Select>
      </div>
    );
  }

  return (
    <Card className="w-80">
      <CardHeader>
        <CardTitle className="text-lg">Anggota Online</CardTitle>
        <div className="flex items-center gap-4">
          <UserStatusBadge status={userStatus} />
          <Select value={userStatus} onValueChange={(value: 'online' | 'offline' | 'busy') => updateUserStatus(value)}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="online">Online</SelectItem>
              <SelectItem value="busy">Sibuk</SelectItem>
              <SelectItem value="offline">Offline</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {allUsers.map((userPresence) => (
            <div key={userPresence.id} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
              <div className="flex items-center gap-3">
                <div className={`w-3 h-3 rounded-full ${getStatusColor(userPresence.status)}`} />
                <div>
                  <div className="font-medium text-sm">{userPresence.user_name}</div>
                  <div className="text-xs text-muted-foreground">
                    {userPresence.status === 'online' ? 'Online' : 
                     userPresence.status === 'busy' ? 'Sibuk' : 
                     formatLastSeen(userPresence.last_seen)}
                  </div>
                </div>
              </div>
            </div>
          ))}
          {allUsers.length === 0 && (
            <div className="text-center text-muted-foreground text-sm py-4">
              Tidak ada pengguna online
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};