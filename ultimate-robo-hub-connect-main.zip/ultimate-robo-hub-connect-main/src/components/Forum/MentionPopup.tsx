import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

interface User {
  id: string;
  name: string;
  role: string;
}

interface MentionPopupProps {
  isVisible: boolean;
  onSelect: (user: User) => void;
  position: { x: number; y: number };
  searchQuery: string;
}

export const MentionPopup: React.FC<MentionPopupProps> = ({
  isVisible,
  onSelect,
  position,
  searchQuery
}) => {
  const [users, setUsers] = useState<User[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const popupRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isVisible) {
      fetchUsers();
    }
  }, [isVisible, searchQuery]);

  useEffect(() => {
    setSelectedIndex(0);
  }, [users]);

  const fetchUsers = async () => {
    try {
      let query = supabase
        .from('profiles')
        .select('id, name, role')
        .not('name', 'is', null)
        .neq('role', 'visitor');

      if (searchQuery) {
        query = query.ilike('name', `%${searchQuery}%`);
      }

      const { data, error } = await query.limit(5);

      if (error) throw error;
      setUsers(data || []);
    } catch (error) {
      console.error('Error fetching users for mention:', error);
    }
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (!isVisible || users.length === 0) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => 
          prev < users.length - 1 ? prev + 1 : prev
        );
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => prev > 0 ? prev - 1 : prev);
        break;
      case 'Enter':
        e.preventDefault();
        if (users[selectedIndex]) {
          onSelect(users[selectedIndex]);
        }
        break;
      case 'Escape':
        e.preventDefault();
        onSelect(null as any);
        break;
    }
  };

  useEffect(() => {
    if (isVisible) {
      document.addEventListener('keydown', handleKeyDown);
      return () => document.removeEventListener('keydown', handleKeyDown);
    }
  }, [isVisible, users, selectedIndex]);

  if (!isVisible || users.length === 0) return null;

  return (
    <Card 
      ref={popupRef}
      className="absolute z-50 w-64 max-h-48 overflow-y-auto shadow-lg border bg-background"
      style={{
        left: position.x,
        top: position.y + 20,
      }}
    >
      <div className="p-2">
        {users.map((user, index) => (
          <div
            key={user.id}
            className={`flex items-center gap-3 p-2 rounded cursor-pointer transition-colors ${
              index === selectedIndex 
                ? 'bg-primary text-primary-foreground' 
                : 'hover:bg-muted'
            }`}
            onClick={() => onSelect(user)}
          >
            <Avatar className="w-6 h-6">
              <AvatarFallback className="text-xs">
                {user.name?.charAt(0)?.toUpperCase() || 'U'}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">{user.name}</div>
              <div className="text-xs opacity-70 truncate">{user.role}</div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
};