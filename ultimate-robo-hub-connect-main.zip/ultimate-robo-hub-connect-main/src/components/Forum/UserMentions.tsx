import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/custom-client';

interface User {
  id: string;
  name: string;
}

interface UserMentionsProps {
  content: string;
  onMention: (userId: string) => void;
  threadId?: string;
  replyId?: string;
}

export const UserMentions: React.FC<UserMentionsProps> = ({ 
  content, 
  onMention, 
  threadId, 
  replyId 
}) => {
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    const fetchUsers = async () => {
      const { data } = await supabase
        .from('profiles')
        .select('id, name')
        .not('name', 'is', null);
      
      if (data) {
        setUsers(data as User[]);
      }
    };

    fetchUsers();
  }, []);

  useEffect(() => {
    // Extract mentions from content
    const mentionRegex = /@(\w+)/g;
    const mentions = [...content.matchAll(mentionRegex)];
    
    mentions.forEach(async (match) => {
      const username = match[1];
      const user = users.find(u => u.name?.toLowerCase() === username.toLowerCase());
      
      if (user) {
        // Create mention record
        await supabase.from('forum_mentions').insert({
          mentioned_user_id: user.id,
          mentioner_user_id: (await supabase.auth.getUser()).data.user?.id,
          thread_id: threadId || null,
          reply_id: replyId || null,
        });
        
        onMention(user.id);
      }
    });
  }, [content, users, onMention, threadId, replyId]);

  return null;
};

export const renderMentions = (text: string): React.ReactNode => {
  const mentionRegex = /@(\w+)/g;
  const parts = text.split(mentionRegex);
  
  return parts.map((part, index) => {
    if (index % 2 === 1) {
      // This is a username
      return (
        <span key={index} className="text-blue-500 font-medium">
          @{part}
        </span>
      );
    }
    return part;
  });
};