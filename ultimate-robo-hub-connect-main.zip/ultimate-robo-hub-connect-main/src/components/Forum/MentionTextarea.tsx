import React, { useState, useRef, useEffect } from 'react';
import { Textarea } from '@/components/ui/textarea';
import { MentionPopup } from './MentionPopup';

interface User {
  id: string;
  name: string;
  role: string;
}

interface MentionTextareaProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  onMention?: (userId: string) => void;
}

export const MentionTextarea: React.FC<MentionTextareaProps> = ({
  value,
  onChange,
  placeholder = "Tulis balasan Anda... (gunakan @ untuk mention)",
  className = "min-h-[120px]",
  onMention
}) => {
  const [showMentionPopup, setShowMentionPopup] = useState(false);
  const [mentionQuery, setMentionQuery] = useState('');
  const [popupPosition, setPopupPosition] = useState({ x: 0, y: 0 });
  const [cursorPosition, setCursorPosition] = useState(0);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newValue = e.target.value;
    const cursorPos = e.target.selectionStart;
    
    onChange(newValue);
    setCursorPosition(cursorPos);
    
    // Check for mention trigger
    const textBeforeCursor = newValue.substring(0, cursorPos);
    const mentionMatch = textBeforeCursor.match(/@(\w*)$/);
    
    if (mentionMatch) {
      setMentionQuery(mentionMatch[1]);
      setShowMentionPopup(true);
      
      // Calculate popup position
      if (textareaRef.current) {
        const textarea = textareaRef.current;
        const rect = textarea.getBoundingClientRect();
        
        // Create a temporary element to measure text width
        const temp = document.createElement('div');
        temp.style.position = 'absolute';
        temp.style.visibility = 'hidden';
        temp.style.whiteSpace = 'pre-wrap';
        temp.style.wordWrap = 'break-word';
        temp.style.font = window.getComputedStyle(textarea).font;
        temp.style.width = `${textarea.clientWidth}px`;
        temp.style.padding = window.getComputedStyle(textarea).padding;
        temp.textContent = textBeforeCursor;
        
        document.body.appendChild(temp);
        const tempRect = temp.getBoundingClientRect();
        document.body.removeChild(temp);
        
        setPopupPosition({
          x: rect.left + (tempRect.width % textarea.clientWidth),
          y: rect.top + Math.floor(tempRect.width / textarea.clientWidth) * 20
        });
      }
    } else {
      setShowMentionPopup(false);
      setMentionQuery('');
    }
  };

  const handleMentionSelect = (user: User | null) => {
    if (!user) {
      setShowMentionPopup(false);
      return;
    }

    const textBeforeCursor = value.substring(0, cursorPosition);
    const textAfterCursor = value.substring(cursorPosition);
    
    // Replace the @query with @username
    const mentionMatch = textBeforeCursor.match(/@(\w*)$/);
    if (mentionMatch) {
      const newTextBefore = textBeforeCursor.replace(/@(\w*)$/, `@${user.name} `);
      const newValue = newTextBefore + textAfterCursor;
      
      onChange(newValue);
      
      // Set cursor position after the mention
      setTimeout(() => {
        if (textareaRef.current) {
          const newCursorPos = newTextBefore.length;
          textareaRef.current.setSelectionRange(newCursorPos, newCursorPos);
          textareaRef.current.focus();
        }
      }, 0);
      
      // Trigger mention callback
      if (onMention) {
        onMention(user.id);
      }
    }
    
    setShowMentionPopup(false);
    setMentionQuery('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (showMentionPopup && ['ArrowDown', 'ArrowUp', 'Enter', 'Escape'].includes(e.key)) {
      e.preventDefault();
      return;
    }
  };

  const handleBlur = () => {
    // Delay hiding popup to allow click on popup items
    setTimeout(() => {
      setShowMentionPopup(false);
    }, 200);
  };

  return (
    <div className="relative">
      <Textarea
        ref={textareaRef}
        value={value}
        onChange={handleTextChange}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
        placeholder={placeholder}
        className={className}
      />
      
      <MentionPopup
        isVisible={showMentionPopup}
        onSelect={handleMentionSelect}
        position={popupPosition}
        searchQuery={mentionQuery}
      />
    </div>
  );
};