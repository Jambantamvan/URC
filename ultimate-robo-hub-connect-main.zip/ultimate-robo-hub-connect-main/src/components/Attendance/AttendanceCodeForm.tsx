
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface AttendanceCodeFormProps {
  attendanceCode: string;
  isSubmitting: boolean;
  setAttendanceCode: (value: string) => void;
  onCancel: () => void;
  onSubmit: () => void;
}

export const AttendanceCodeForm: React.FC<AttendanceCodeFormProps> = ({
  attendanceCode,
  isSubmitting,
  setAttendanceCode,
  onCancel,
  onSubmit,
}) => {
  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>Kehadiran</DialogTitle>
      </DialogHeader>
      <div className="space-y-4 py-4">
        <p>
          Masukkan kode verifikasi yang diberikan oleh pembimbing untuk menandai kehadiran Anda.
        </p>
        <Input
          placeholder="Kode Verifikasi"
          value={attendanceCode}
          onChange={(e) => setAttendanceCode(e.target.value.toUpperCase())}
          className="text-center tracking-widest text-lg font-bold"
          maxLength={6}
        />
      </div>
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={onCancel}>
          Batal
        </Button>
        <Button onClick={onSubmit} disabled={isSubmitting}>
          {isSubmitting ? 'Menyimpan...' : 'Hadir'}
        </Button>
      </div>
    </DialogContent>
  );
};
