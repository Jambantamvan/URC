
import React from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface AbsenceFormProps {
  absenceReason: string;
  isSubmitting: boolean;
  setAbsenceReason: (value: string) => void;
  onCancel: () => void;
  onSubmit: () => void;
  attendanceTitle?: string;
}

export const AbsenceForm: React.FC<AbsenceFormProps> = ({
  absenceReason,
  isSubmitting,
  setAbsenceReason,
  onCancel,
  onSubmit,
  attendanceTitle,
}) => {
  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>Catatan Ketidakhadiran</DialogTitle>
      </DialogHeader>
      <div className="space-y-4 py-4">
        <p>
          Silakan berikan alasan ketidakhadiran Anda untuk acara{' '}
          {attendanceTitle ? attendanceTitle : ''}.
        </p>
        <Textarea
          placeholder="Alasan ketidakhadiran"
          value={absenceReason}
          onChange={(e) => setAbsenceReason(e.target.value)}
          rows={4}
        />
      </div>
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={onCancel}>
          Batal
        </Button>
        <Button variant="default" onClick={onSubmit} disabled={isSubmitting}>
          {isSubmitting ? 'Menyimpan...' : 'Simpan'}
        </Button>
      </div>
    </DialogContent>
  );
};
