
import React from 'react';
import { format, parseISO } from 'date-fns';
import { Calendar, User } from 'lucide-react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AttendanceEvent } from '@/types/supabase';

interface AttendanceCardProps {
  attendance: AttendanceEvent;
  isAdmin: boolean;
  onEdit: (attendance: AttendanceEvent) => void;
  onMarkPresent: () => void;
  onMarkAbsent: (attendance: AttendanceEvent) => void;
}

export const AttendanceCard: React.FC<AttendanceCardProps> = ({
  attendance,
  isAdmin,
  onEdit,
  onMarkPresent,
  onMarkAbsent,
}) => {
  const formatDate = (dateStr: string) => {
    try {
      return format(parseISO(dateStr), 'dd MMMM yyyy');
    } catch (e) {
      return dateStr;
    }
  };

  const formatTime = (timeStr: string) => {
    try {
      return format(parseISO(timeStr), 'HH:mm');
    } catch (e) {
      return timeStr;
    }
  };

  return (
    <Card key={attendance.id} className="overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle>{attendance.title}</CardTitle>
          {isAdmin && (
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 w-8 p-0"
              onClick={() => onEdit(attendance)}
            >
              <span className="sr-only">Edit</span>
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
            </Button>
          )}
        </div>
        <CardDescription className="space-y-1">
          <div className="flex items-center">
            <Calendar className="h-3.5 w-3.5 mr-1 opacity-70" />
            {formatDate(attendance.date)}
          </div>
          {(attendance.start_time || attendance.end_time) && (
            <div className="text-xs text-muted-foreground">
              {attendance.start_time && attendance.end_time ? (
                <>Waktu: {formatTime(attendance.start_time)} - {formatTime(attendance.end_time)}</>
              ) : attendance.start_time ? (
                <>Mulai: {formatTime(attendance.start_time)}</>
              ) : (
                <>Selesai: {formatTime(attendance.end_time!)}</>
              )}
            </div>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm line-clamp-3 min-h-[3rem]">
          {attendance.description || "Tidak ada deskripsi"}
        </p>
        <div className="mt-4 text-xs text-muted-foreground">
          <span className="flex items-center">
            <User className="h-3.5 w-3.5 mr-1 opacity-70" />
            Dibuat oleh: {attendance.creator_name}
          </span>
        </div>
      </CardContent>
      <CardFooter>
        {attendance.user_attended ? (
          <Button variant="outline" className="w-full" disabled>
            Sudah Diisi
          </Button>
        ) : (
          <div className="flex gap-2 w-full">
            <Button className="flex-1" onClick={onMarkPresent}>
              Hadir
            </Button>
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => onMarkAbsent(attendance)}
            >
              Tidak Hadir
            </Button>
          </div>
        )}
      </CardFooter>
    </Card>
  );
};
