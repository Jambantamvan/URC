
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface AttendanceFormProps {
  isEdit: boolean;
  formTitle: string;
  formDescription: string;
  formDate: string;
  formStartTime: string;
  formEndTime: string;
  formVerificationCode: string;
  isSubmitting: boolean;
  generateVerificationCode: () => void;
  setFormTitle: (value: string) => void;
  setFormDescription: (value: string) => void;
  setFormDate: (value: string) => void;
  setFormStartTime: (value: string) => void;
  setFormEndTime: (value: string) => void;
  setFormVerificationCode: (value: string) => void;
  onCancel: () => void;
  onSubmit: () => void;
}

export const AttendanceForm: React.FC<AttendanceFormProps> = ({
  isEdit,
  formTitle,
  formDescription,
  formDate,
  formStartTime,
  formEndTime,
  formVerificationCode,
  isSubmitting,
  generateVerificationCode,
  setFormTitle,
  setFormDescription,
  setFormDate,
  setFormStartTime,
  setFormEndTime,
  setFormVerificationCode,
  onCancel,
  onSubmit,
}) => {
  return (
    <DialogContent className="sm:max-w-[425px]">
      <DialogHeader>
        <DialogTitle>{isEdit ? 'Edit Absensi' : 'Tambah Absensi Baru'}</DialogTitle>
      </DialogHeader>
      <div className="grid gap-4 py-4">
        <div className="grid grid-cols-1 gap-3">
          <label htmlFor="title" className="text-sm font-medium">
            Judul
          </label>
          <Input
            id="title"
            placeholder="Judul acara"
            value={formTitle}
            onChange={(e) => setFormTitle(e.target.value)}
          />
        </div>
        <div className="grid grid-cols-1 gap-3">
          <label htmlFor="description" className="text-sm font-medium">
            Deskripsi
          </label>
          <Textarea
            id="description"
            placeholder="Deskripsi acara"
            value={formDescription}
            onChange={(e) => setFormDescription(e.target.value)}
            rows={3}
          />
        </div>
        <div className="grid grid-cols-1 gap-3">
          <label htmlFor="date" className="text-sm font-medium">
            Tanggal
          </label>
          <Input
            id="date"
            type="date"
            value={formDate}
            onChange={(e) => setFormDate(e.target.value)}
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label htmlFor="startTime" className="text-sm font-medium">
              Waktu Mulai
            </label>
            <Input
              id="startTime"
              type="time"
              value={formStartTime}
              onChange={(e) => setFormStartTime(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="endTime" className="text-sm font-medium">
              Waktu Selesai
            </label>
            <Input
              id="endTime"
              type="time"
              value={formEndTime}
              onChange={(e) => setFormEndTime(e.target.value)}
            />
          </div>
        </div>
        <div className="grid grid-cols-1 gap-3">
          <div className="flex justify-between items-center">
            <label htmlFor="code" className="text-sm font-medium">
              Kode Verifikasi
            </label>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={generateVerificationCode}
            >
              Generate
            </Button>
          </div>
          <Input
            id="code"
            placeholder="Kode verifikasi"
            value={formVerificationCode}
            onChange={(e) => setFormVerificationCode(e.target.value.toUpperCase())}
            className="tracking-widest text-center"
            maxLength={6}
          />
        </div>
      </div>
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={onCancel}>
          Batal
        </Button>
        <Button onClick={onSubmit} disabled={isSubmitting}>
          {isSubmitting ? 'Menyimpan...' : 'Simpan'}
        </Button>
      </div>
    </DialogContent>
  );
};
