
import { toast } from "sonner";
import {
  User,
  Project,
  Announcement,
  Event,
  LearningMaterial,
  ForumThread,
  CodeSnippet,
  Achievement,
  Comment,
  ForumReply,
  Media,
} from "../types";

// Mock database using localStorage
const STORAGE_KEYS = {
  USERS: 'robo_users',
  PROJECTS: 'robo_projects',
  ANNOUNCEMENTS: 'robo_announcements',
  EVENTS: 'robo_events',
  LEARNING_MATERIALS: 'robo_materials',
  FORUM_THREADS: 'robo_forum',
  CODE_SNIPPETS: 'robo_code',
  ACHIEVEMENTS: 'robo_achievements',
  CURRENT_USER: 'robo_current_user',
};

// Helper to generate IDs
const generateId = () => {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
};

// Helper to get current timestamp
const getCurrentTimestamp = () => {
  return new Date().toISOString();
};

// Mock data initialization
const initializeData = () => {
  // Check if data already exists
  const users = localStorage.getItem(STORAGE_KEYS.USERS);
  if (!users) {
    // Create mock user
    const defaultUser: User = {
      id: generateId(),
      name: 'Budi Santoso',
      class: '11 IPA 2',
      division: 'Programming',
      skills: ['Python', 'Arduino', 'Electronics'],
      bio: 'Passionate about robotics and programming',
      projects: [],
      competitions: [],
      createdAt: getCurrentTimestamp(),
      updatedAt: getCurrentTimestamp(),
    };

    // Set current user
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, defaultUser.id);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify([defaultUser]));
    
    // Create mock announcements
    const announcements: Announcement[] = [
      {
        id: generateId(),
        title: 'Pertemuan Minggu Ini',
        content: 'Pertemuan ekskul robotik akan diadakan pada hari Jumat pukul 15:00 di Lab Robotik.',
        important: true,
        createdBy: defaultUser.id,
        createdAt: getCurrentTimestamp(),
        updatedAt: getCurrentTimestamp(),
      },
      {
        id: generateId(),
        title: 'Lomba Robotik Nasional 2024',
        content: 'Pendaftaran untuk Lomba Robotik Nasional 2024 sudah dibuka. Tim yang berminat bisa mendaftar melalui link berikut.',
        important: true,
        createdBy: defaultUser.id,
        createdAt: getCurrentTimestamp(),
        updatedAt: getCurrentTimestamp(),
      }
    ];
    localStorage.setItem(STORAGE_KEYS.ANNOUNCEMENTS, JSON.stringify(announcements));

    // Create mock projects
    const projects: Project[] = [
      {
        id: generateId(),
        title: 'Line Follower Robot',
        description: 'Robot yang dapat mengikuti garis dengan sensor inframerah.',
        status: 'in-progress',
        tags: ['Arduino', 'Sensor', 'Motors'],
        members: [defaultUser.id],
        leader: defaultUser.id,
        media: [],
        createdAt: getCurrentTimestamp(),
        updatedAt: getCurrentTimestamp(),
        comments: [],
        created_at: getCurrentTimestamp(),
        github_url: null,
        demo_url: null,
        image_url: null,
        leader_name: defaultUser.name,
        division: null,
      },
      {
        id: generateId(),
        title: 'Smart Home IoT',
        description: 'Sistem otomatisasi rumah menggunakan ESP32 dan sensor suhu.',
        status: 'planning',
        tags: ['IoT', 'ESP32', 'Sensors'],
        members: [defaultUser.id],
        leader: defaultUser.id,
        media: [],
        createdAt: getCurrentTimestamp(),
        updatedAt: getCurrentTimestamp(),
        comments: [],
        created_at: getCurrentTimestamp(),
        github_url: null,
        demo_url: null,
        image_url: null,
        leader_name: defaultUser.name,
        division: null,
      }
    ];
    localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(projects));

    // Create mock events
    const events: Event[] = [
      {
        id: generateId(),
        title: 'Workshop Arduino',
        description: 'Belajar dasar-dasar Arduino untuk pemula.',
        location: 'Lab Robotik',
        startDate: new Date(Date.now() + 86400000 * 3).toISOString(), // 3 days from now
        endDate: new Date(Date.now() + 86400000 * 3 + 7200000).toISOString(), // +2 hours
        attendees: [
          { userId: defaultUser.id, status: 'attending', userName: defaultUser.name }
        ],
        createdBy: defaultUser.id,
        createdAt: getCurrentTimestamp(),
        updatedAt: getCurrentTimestamp(),
      }
    ];
    localStorage.setItem(STORAGE_KEYS.EVENTS, JSON.stringify(events));

    // Create mock learning materials
    const materials: LearningMaterial[] = [
      {
        id: generateId(),
        title: 'Dasar Arduino',
        description: 'Pengenalan Arduino untuk pemula',
        type: 'document',
        level: 'beginner',
        url: 'https://example.com/arduino-basics.pdf',
        createdBy: defaultUser.id,
        createdAt: getCurrentTimestamp(),
        updatedAt: getCurrentTimestamp(),
      },
      {
        id: generateId(),
        title: 'Tutorial Sensor Ultrasonik',
        description: 'Cara menggunakan sensor ultrasonik dengan Arduino',
        type: 'video',
        level: 'intermediate',
        url: 'https://youtube.com/watch?v=example',
        createdBy: defaultUser.id,
        createdAt: getCurrentTimestamp(),
        updatedAt: getCurrentTimestamp(),
      }
    ];
    localStorage.setItem(STORAGE_KEYS.LEARNING_MATERIALS, JSON.stringify(materials));

    // Create mock forum threads
    const threads: ForumThread[] = [
      {
        id: generateId(),
        title: 'Tips untuk Line Follower',
        content: 'Bagaimana cara membuat algoritma PID yang baik untuk line follower?',
        division: 'Programming',
        createdBy: defaultUser.id,
        createdAt: getCurrentTimestamp(),
        updatedAt: getCurrentTimestamp(),
        replies: [],
      }
    ];
    localStorage.setItem(STORAGE_KEYS.FORUM_THREADS, JSON.stringify(threads));

    // Create mock code snippets
    const snippets: CodeSnippet[] = [
      {
        id: generateId(),
        title: 'Baca Sensor Ultrasonik',
        code: 'const int trigPin = 9;\nconst int echoPin = 10;\n\nvoid setup() {\n  Serial.begin(9600);\n  pinMode(trigPin, OUTPUT);\n  pinMode(echoPin, INPUT);\n}\n\nvoid loop() {\n  digitalWrite(trigPin, LOW);\n  delayMicroseconds(2);\n  digitalWrite(trigPin, HIGH);\n  delayMicroseconds(10);\n  digitalWrite(trigPin, LOW);\n  \n  long duration = pulseIn(echoPin, HIGH);\n  int distance = duration * 0.034 / 2;\n  \n  Serial.print("Distance: ");\n  Serial.println(distance);\n  delay(500);\n}',
        language: 'arduino',
        description: 'Kode untuk membaca jarak dengan sensor ultrasonik HC-SR04',
        createdBy: defaultUser.id,
        createdAt: getCurrentTimestamp(),
        updatedAt: getCurrentTimestamp(),
      }
    ];
    localStorage.setItem(STORAGE_KEYS.CODE_SNIPPETS, JSON.stringify(snippets));

    // Create mock achievements
    const achievements: Achievement[] = [
      {
        id: generateId(),
        title: 'Juara 2 Lomba Robotik Regional',
        description: 'Tim UltimateRoboClub berhasil meraih juara 2 dalam lomba robotik regional',
        date: new Date(Date.now() - 86400000 * 30).toISOString(), // 30 days ago
        type: 'competition',
        participants: [defaultUser.id],
        media: [],
        createdBy: defaultUser.id,
        createdAt: getCurrentTimestamp(),
      }
    ];
    localStorage.setItem(STORAGE_KEYS.ACHIEVEMENTS, JSON.stringify(achievements));

    console.log('Mock data initialized');
  }
};

// Initialize on module import
initializeData();

// Get current user
export const getCurrentUser = (): User | null => {
  const currentUserId = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
  if (!currentUserId) return null;

  const users = getUsers();
  return users.find(user => user.id === currentUserId) || null;
};

// CRUD operations for Users
export const getUsers = (): User[] => {
  const users = localStorage.getItem(STORAGE_KEYS.USERS);
  return users ? JSON.parse(users) : [];
};

export const getUserById = (id: string): User | null => {
  const users = getUsers();
  return users.find(user => user.id === id) || null;
};

export const createUser = (userData: Omit<User, 'id' | 'createdAt' | 'updatedAt'>): User => {
  const users = getUsers();
  const newUser: User = {
    ...userData,
    id: generateId(),
    createdAt: getCurrentTimestamp(),
    updatedAt: getCurrentTimestamp(),
  };
  
  users.push(newUser);
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  
  // Set as current user if none exists
  if (!localStorage.getItem(STORAGE_KEYS.CURRENT_USER)) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, newUser.id);
  }
  
  return newUser;
};

export const updateUser = (id: string, userData: Partial<User>): User | null => {
  const users = getUsers();
  const userIndex = users.findIndex(user => user.id === id);
  
  if (userIndex === -1) return null;
  
  const updatedUser = {
    ...users[userIndex],
    ...userData,
    updatedAt: getCurrentTimestamp(),
  };
  
  users[userIndex] = updatedUser;
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  return updatedUser;
};

export const deleteUser = (id: string): boolean => {
  const users = getUsers();
  const filteredUsers = users.filter(user => user.id !== id);
  
  if (filteredUsers.length === users.length) return false;
  
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(filteredUsers));
  
  // If current user is deleted, set current user to null
  if (localStorage.getItem(STORAGE_KEYS.CURRENT_USER) === id) {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  }
  
  return true;
};

// CRUD operations for Projects
export const getProjects = (): Project[] => {
  const projects = localStorage.getItem(STORAGE_KEYS.PROJECTS);
  return projects ? JSON.parse(projects) : [];
};

export const getProjectById = (id: string): Project | null => {
  const projects = getProjects();
  return projects.find(project => project.id === id) || null;
};

export const createProject = (projectData: Omit<Project, 'id' | 'createdAt' | 'updatedAt' | 'comments'>): Project => {
  const projects = getProjects();
  const currentUser = getCurrentUser();
  
  if (!currentUser) {
    throw new Error('No current user found');
  }
  
  const newProject: Project = {
    ...projectData,
    id: generateId(),
    createdAt: getCurrentTimestamp(),
    updatedAt: getCurrentTimestamp(),
    comments: [],
  };
  
  projects.push(newProject);
  localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(projects));
  
  // Update user's project list
  if (!projectData.members.includes(currentUser.id)) {
    updateUser(currentUser.id, {
      projects: [...currentUser.projects, newProject.id]
    });
  }
  
  toast.success('Proyek berhasil dibuat');
  return newProject;
};

export const updateProject = (id: string, projectData: Partial<Project>): Project | null => {
  const projects = getProjects();
  const projectIndex = projects.findIndex(project => project.id === id);
  
  if (projectIndex === -1) return null;
  
  const updatedProject = {
    ...projects[projectIndex],
    ...projectData,
    updatedAt: getCurrentTimestamp(),
  };
  
  projects[projectIndex] = updatedProject;
  localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(projects));
  toast.success('Proyek berhasil diperbarui');
  return updatedProject;
};

export const deleteProject = (id: string): boolean => {
  const projects = getProjects();
  const filteredProjects = projects.filter(project => project.id !== id);
  
  if (filteredProjects.length === projects.length) return false;
  
  localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(filteredProjects));
  toast.success('Proyek berhasil dihapus');
  
  // Update users who were members of this project
  const usersThatHadProject = getUsers().filter(user => user.projects.includes(id));
  usersThatHadProject.forEach(user => {
    updateUser(user.id, {
      projects: user.projects.filter(projectId => projectId !== id)
    });
  });
  
  return true;
};

export const addProjectComment = (projectId: string, content: string): Comment | null => {
  const currentUser = getCurrentUser();
  if (!currentUser) return null;
  
  const project = getProjectById(projectId);
  if (!project) return null;
  
  const newComment: Comment = {
    id: generateId(),
    content,
    userId: currentUser.id,
    userName: currentUser.name,
    userPhotoUrl: currentUser.photoUrl,
    createdAt: getCurrentTimestamp(),
  };
  
  project.comments.push(newComment);
  updateProject(projectId, { comments: project.comments });
  toast.success('Komentar berhasil ditambahkan');
  
  return newComment;
};

// CRUD operations for Announcements
export const getAnnouncements = (): Announcement[] => {
  const announcements = localStorage.getItem(STORAGE_KEYS.ANNOUNCEMENTS);
  return announcements ? JSON.parse(announcements) : [];
};

export const getAnnouncementById = (id: string): Announcement | null => {
  const announcements = getAnnouncements();
  return announcements.find(announcement => announcement.id === id) || null;
};

export const createAnnouncement = (announcementData: Omit<Announcement, 'id' | 'createdAt' | 'updatedAt' | 'createdBy'>): Announcement => {
  const announcements = getAnnouncements();
  const currentUser = getCurrentUser();
  
  if (!currentUser) {
    throw new Error('No current user found');
  }
  
  const newAnnouncement: Announcement = {
    ...announcementData,
    id: generateId(),
    createdBy: currentUser.id,
    createdAt: getCurrentTimestamp(),
    updatedAt: getCurrentTimestamp(),
  };
  
  announcements.push(newAnnouncement);
  localStorage.setItem(STORAGE_KEYS.ANNOUNCEMENTS, JSON.stringify(announcements));
  
  toast.success('Pengumuman berhasil dibuat');
  return newAnnouncement;
};

export const updateAnnouncement = (id: string, announcementData: Partial<Announcement>): Announcement | null => {
  const announcements = getAnnouncements();
  const announcementIndex = announcements.findIndex(announcement => announcement.id === id);
  
  if (announcementIndex === -1) return null;
  
  const updatedAnnouncement = {
    ...announcements[announcementIndex],
    ...announcementData,
    updatedAt: getCurrentTimestamp(),
  };
  
  announcements[announcementIndex] = updatedAnnouncement;
  localStorage.setItem(STORAGE_KEYS.ANNOUNCEMENTS, JSON.stringify(announcements));
  
  toast.success('Pengumuman berhasil diperbarui');
  return updatedAnnouncement;
};

export const deleteAnnouncement = (id: string): boolean => {
  const announcements = getAnnouncements();
  const filteredAnnouncements = announcements.filter(announcement => announcement.id !== id);
  
  if (filteredAnnouncements.length === announcements.length) return false;
  
  localStorage.setItem(STORAGE_KEYS.ANNOUNCEMENTS, JSON.stringify(filteredAnnouncements));
  
  toast.success('Pengumuman berhasil dihapus');
  return true;
};

// CRUD operations for Events
export const getEvents = (): Event[] => {
  const events = localStorage.getItem(STORAGE_KEYS.EVENTS);
  return events ? JSON.parse(events) : [];
};

export const getEventById = (id: string): Event | null => {
  const events = getEvents();
  return events.find(event => event.id === id) || null;
};

export const createEvent = (eventData: Omit<Event, 'id' | 'createdAt' | 'updatedAt' | 'createdBy' | 'attendees'>): Event => {
  const events = getEvents();
  const currentUser = getCurrentUser();
  
  if (!currentUser) {
    throw new Error('No current user found');
  }
  
  const newEvent: Event = {
    ...eventData,
    id: generateId(),
    createdBy: currentUser.id,
    attendees: [{ userId: currentUser.id, status: 'attending', userName: currentUser.name }],
    createdAt: getCurrentTimestamp(),
    updatedAt: getCurrentTimestamp(),
  };
  
  events.push(newEvent);
  localStorage.setItem(STORAGE_KEYS.EVENTS, JSON.stringify(events));
  
  toast.success('Kegiatan berhasil dibuat');
  return newEvent;
};

export const updateEvent = (id: string, eventData: Partial<Event>): Event | null => {
  const events = getEvents();
  const eventIndex = events.findIndex(event => event.id === id);
  
  if (eventIndex === -1) return null;
  
  const updatedEvent = {
    ...events[eventIndex],
    ...eventData,
    updatedAt: getCurrentTimestamp(),
  };
  
  events[eventIndex] = updatedEvent;
  localStorage.setItem(STORAGE_KEYS.EVENTS, JSON.stringify(events));
  
  toast.success('Kegiatan berhasil diperbarui');
  return updatedEvent;
};

export const deleteEvent = (id: string): boolean => {
  const events = getEvents();
  const filteredEvents = events.filter(event => event.id !== id);
  
  if (filteredEvents.length === events.length) return false;
  
  localStorage.setItem(STORAGE_KEYS.EVENTS, JSON.stringify(filteredEvents));
  
  toast.success('Kegiatan berhasil dihapus');
  return true;
};

export const updateEventAttendance = (eventId: string, status: 'attending' | 'not-attending' | 'maybe'): boolean => {
  const currentUser = getCurrentUser();
  if (!currentUser) return false;
  
  const event = getEventById(eventId);
  if (!event) return false;
  
  const existingAttendeeIndex = event.attendees.findIndex(a => a.userId === currentUser.id);
  
  if (existingAttendeeIndex !== -1) {
    event.attendees[existingAttendeeIndex].status = status;
  } else {
    event.attendees.push({
      userId: currentUser.id,
      status,
      userName: currentUser.name,
    });
  }
  
  updateEvent(eventId, { attendees: event.attendees });
  
  toast.success('Status kehadiran berhasil diperbarui');
  return true;
};

// CRUD operations for Learning Materials
export const getLearningMaterials = (): LearningMaterial[] => {
  const materials = localStorage.getItem(STORAGE_KEYS.LEARNING_MATERIALS);
  return materials ? JSON.parse(materials) : [];
};

export const getLearningMaterialById = (id: string): LearningMaterial | null => {
  const materials = getLearningMaterials();
  return materials.find(material => material.id === id) || null;
};

export const createLearningMaterial = (materialData: Omit<LearningMaterial, 'id' | 'createdAt' | 'updatedAt' | 'createdBy'>): LearningMaterial => {
  const materials = getLearningMaterials();
  const currentUser = getCurrentUser();
  
  if (!currentUser) {
    throw new Error('No current user found');
  }
  
  const newMaterial: LearningMaterial = {
    ...materialData,
    id: generateId(),
    createdBy: currentUser.id,
    createdAt: getCurrentTimestamp(),
    updatedAt: getCurrentTimestamp(),
  };
  
  materials.push(newMaterial);
  localStorage.setItem(STORAGE_KEYS.LEARNING_MATERIALS, JSON.stringify(materials));
  
  toast.success('Materi belajar berhasil ditambahkan');
  return newMaterial;
};

export const updateLearningMaterial = (id: string, materialData: Partial<LearningMaterial>): LearningMaterial | null => {
  const materials = getLearningMaterials();
  const materialIndex = materials.findIndex(material => material.id === id);
  
  if (materialIndex === -1) return null;
  
  const updatedMaterial = {
    ...materials[materialIndex],
    ...materialData,
    updatedAt: getCurrentTimestamp(),
  };
  
  materials[materialIndex] = updatedMaterial;
  localStorage.setItem(STORAGE_KEYS.LEARNING_MATERIALS, JSON.stringify(materials));
  
  toast.success('Materi belajar berhasil diperbarui');
  return updatedMaterial;
};

export const deleteLearningMaterial = (id: string): boolean => {
  const materials = getLearningMaterials();
  const filteredMaterials = materials.filter(material => material.id !== id);
  
  if (filteredMaterials.length === materials.length) return false;
  
  localStorage.setItem(STORAGE_KEYS.LEARNING_MATERIALS, JSON.stringify(filteredMaterials));
  
  toast.success('Materi belajar berhasil dihapus');
  return true;
};

// CRUD operations for Forum Threads
export const getForumThreads = (): ForumThread[] => {
  const threads = localStorage.getItem(STORAGE_KEYS.FORUM_THREADS);
  return threads ? JSON.parse(threads) : [];
};

export const getForumThreadById = (id: string): ForumThread | null => {
  const threads = getForumThreads();
  return threads.find(thread => thread.id === id) || null;
};

export const createForumThread = (threadData: Omit<ForumThread, 'id' | 'createdAt' | 'updatedAt' | 'createdBy' | 'replies'>): ForumThread => {
  const threads = getForumThreads();
  const currentUser = getCurrentUser();
  
  if (!currentUser) {
    throw new Error('No current user found');
  }
  
  const newThread: ForumThread = {
    ...threadData,
    id: generateId(),
    createdBy: currentUser.id,
    createdAt: getCurrentTimestamp(),
    updatedAt: getCurrentTimestamp(),
    replies: [],
  };
  
  threads.push(newThread);
  localStorage.setItem(STORAGE_KEYS.FORUM_THREADS, JSON.stringify(threads));
  
  toast.success('Thread forum berhasil dibuat');
  return newThread;
};

export const updateForumThread = (id: string, threadData: Partial<ForumThread>): ForumThread | null => {
  const threads = getForumThreads();
  const threadIndex = threads.findIndex(thread => thread.id === id);
  
  if (threadIndex === -1) return null;
  
  const updatedThread = {
    ...threads[threadIndex],
    ...threadData,
    updatedAt: getCurrentTimestamp(),
  };
  
  threads[threadIndex] = updatedThread;
  localStorage.setItem(STORAGE_KEYS.FORUM_THREADS, JSON.stringify(threads));
  
  toast.success('Thread forum berhasil diperbarui');
  return updatedThread;
};

export const deleteForumThread = (id: string): boolean => {
  const threads = getForumThreads();
  const filteredThreads = threads.filter(thread => thread.id !== id);
  
  if (filteredThreads.length === threads.length) return false;
  
  localStorage.setItem(STORAGE_KEYS.FORUM_THREADS, JSON.stringify(filteredThreads));
  
  toast.success('Thread forum berhasil dihapus');
  return true;
};

export const addForumReply = (threadId: string, content: string): ForumReply | null => {
  const currentUser = getCurrentUser();
  if (!currentUser) return null;
  
  const thread = getForumThreadById(threadId);
  if (!thread) return null;
  
  const newReply: ForumReply = {
    id: generateId(),
    content,
    userId: currentUser.id,
    userName: currentUser.name,
    userPhotoUrl: currentUser.photoUrl,
    createdAt: getCurrentTimestamp(),
  };
  
  thread.replies.push(newReply);
  updateForumThread(threadId, { 
    replies: thread.replies,
    updatedAt: getCurrentTimestamp()
  });
  
  toast.success('Balasan berhasil ditambahkan');
  return newReply;
};

// CRUD operations for Code Snippets
export const getCodeSnippets = (): CodeSnippet[] => {
  const snippets = localStorage.getItem(STORAGE_KEYS.CODE_SNIPPETS);
  return snippets ? JSON.parse(snippets) : [];
};

export const getCodeSnippetById = (id: string): CodeSnippet | null => {
  const snippets = getCodeSnippets();
  return snippets.find(snippet => snippet.id === id) || null;
};

export const createCodeSnippet = (snippetData: Omit<CodeSnippet, 'id' | 'createdAt' | 'updatedAt' | 'createdBy'>): CodeSnippet => {
  const snippets = getCodeSnippets();
  const currentUser = getCurrentUser();
  
  if (!currentUser) {
    throw new Error('No current user found');
  }
  
  const newSnippet: CodeSnippet = {
    ...snippetData,
    id: generateId(),
    createdBy: currentUser.id,
    createdAt: getCurrentTimestamp(),
    updatedAt: getCurrentTimestamp(),
  };
  
  snippets.push(newSnippet);
  localStorage.setItem(STORAGE_KEYS.CODE_SNIPPETS, JSON.stringify(snippets));
  
  toast.success('Kode berhasil disimpan');
  return newSnippet;
};

export const updateCodeSnippet = (id: string, snippetData: Partial<CodeSnippet>): CodeSnippet | null => {
  const snippets = getCodeSnippets();
  const snippetIndex = snippets.findIndex(snippet => snippet.id === id);
  
  if (snippetIndex === -1) return null;
  
  const updatedSnippet = {
    ...snippets[snippetIndex],
    ...snippetData,
    updatedAt: getCurrentTimestamp(),
  };
  
  snippets[snippetIndex] = updatedSnippet;
  localStorage.setItem(STORAGE_KEYS.CODE_SNIPPETS, JSON.stringify(snippets));
  
  toast.success('Kode berhasil diperbarui');
  return updatedSnippet;
};

export const deleteCodeSnippet = (id: string): boolean => {
  const snippets = getCodeSnippets();
  const filteredSnippets = snippets.filter(snippet => snippet.id !== id);
  
  if (filteredSnippets.length === snippets.length) return false;
  
  localStorage.setItem(STORAGE_KEYS.CODE_SNIPPETS, JSON.stringify(filteredSnippets));
  
  toast.success('Kode berhasil dihapus');
  return true;
};

// CRUD operations for Achievements
export const getAchievements = (): Achievement[] => {
  const achievements = localStorage.getItem(STORAGE_KEYS.ACHIEVEMENTS);
  return achievements ? JSON.parse(achievements) : [];
};

export const getAchievementById = (id: string): Achievement | null => {
  const achievements = getAchievements();
  return achievements.find(achievement => achievement.id === id) || null;
};

export const createAchievement = (achievementData: Omit<Achievement, 'id' | 'createdAt' | 'createdBy'>): Achievement => {
  const achievements = getAchievements();
  const currentUser = getCurrentUser();
  
  if (!currentUser) {
    throw new Error('No current user found');
  }
  
  const newAchievement: Achievement = {
    ...achievementData,
    id: generateId(),
    createdBy: currentUser.id,
    createdAt: getCurrentTimestamp(),
  };
  
  achievements.push(newAchievement);
  localStorage.setItem(STORAGE_KEYS.ACHIEVEMENTS, JSON.stringify(achievements));
  
  toast.success('Prestasi berhasil ditambahkan');
  return newAchievement;
};

export const updateAchievement = (id: string, achievementData: Partial<Achievement>): Achievement | null => {
  const achievements = getAchievements();
  const achievementIndex = achievements.findIndex(achievement => achievement.id === id);
  
  if (achievementIndex === -1) return null;
  
  const updatedAchievement = {
    ...achievements[achievementIndex],
    ...achievementData,
  };
  
  achievements[achievementIndex] = updatedAchievement;
  localStorage.setItem(STORAGE_KEYS.ACHIEVEMENTS, JSON.stringify(achievements));
  
  toast.success('Prestasi berhasil diperbarui');
  return updatedAchievement;
};

export const deleteAchievement = (id: string): boolean => {
  const achievements = getAchievements();
  const filteredAchievements = achievements.filter(achievement => achievement.id !== id);
  
  if (filteredAchievements.length === achievements.length) return false;
  
  localStorage.setItem(STORAGE_KEYS.ACHIEVEMENTS, JSON.stringify(filteredAchievements));
  
  toast.success('Prestasi berhasil dihapus');
  return true;
};

// Helper function for file uploads (simulated)
export const uploadMedia = (file: File): Promise<string> => {
  return new Promise((resolve) => {
    // Simulate delay
    setTimeout(() => {
      // Create an object URL for the file (this is temporary and not persistent)
      // In a real app, you'd upload to a storage service
      const url = URL.createObjectURL(file);
      resolve(url);
    }, 1500);
  });
};

// Add a media item to a project, achievement, etc.
export const addMediaToEntity = async (
  entityType: 'project' | 'achievement',
  entityId: string, 
  file: File,
  title: string
): Promise<Media | null> => {
  const currentUser = getCurrentUser();
  if (!currentUser) return null;
  
  const mediaUrl = await uploadMedia(file);
  
  const newMedia: Media = {
    id: generateId(),
    type: file.type.startsWith('image/') ? 'image' : 
          file.type.startsWith('video/') ? 'video' : 'document',
    url: mediaUrl,
    title,
    createdAt: getCurrentTimestamp(),
    creatorId: currentUser.id,
  };
  
  if (entityType === 'project') {
    const project = getProjectById(entityId);
    if (!project) return null;
    
    project.media.push(newMedia);
    updateProject(entityId, { media: project.media });
  } else if (entityType === 'achievement') {
    const achievement = getAchievementById(entityId);
    if (!achievement) return null;
    
    achievement.media.push(newMedia);
    updateAchievement(entityId, { media: achievement.media });
  }
  
  toast.success('Media berhasil diunggah');
  return newMedia;
};

// Delete a media item
export const deleteMedia = (
  entityType: 'project' | 'achievement',
  entityId: string,
  mediaId: string
): boolean => {
  if (entityType === 'project') {
    const project = getProjectById(entityId);
    if (!project) return false;
    
    project.media = project.media.filter(media => media.id !== mediaId);
    updateProject(entityId, { media: project.media });
  } else if (entityType === 'achievement') {
    const achievement = getAchievementById(entityId);
    if (!achievement) return false;
    
    achievement.media = achievement.media.filter(media => media.id !== mediaId);
    updateAchievement(entityId, { media: achievement.media });
  }
  
  toast.success('Media berhasil dihapus');
  return true;
};

// Download code snippet as file
export const downloadCodeSnippet = (snippet: CodeSnippet): void => {
  const fileExtension = snippet.language === 'python' ? '.py' : 
                        snippet.language === 'arduino' ? '.ino' : '.cpp';
  
  const filename = `${snippet.title.toLowerCase().replace(/\s+/g, '_')}${fileExtension}`;
  const blob = new Blob([snippet.code], { type: 'text/plain' });
  
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.URL.revokeObjectURL(url);
  
  toast.success('Kode berhasil diunduh');
};
