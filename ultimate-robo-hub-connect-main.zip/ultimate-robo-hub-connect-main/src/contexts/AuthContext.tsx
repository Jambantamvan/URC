
import React, { createContext, useContext, useEffect, useState } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/custom-client';
import { toast } from 'sonner';
import { UserRole } from '@/types/supabase';

export type { UserRole };

export interface UserProfile {
  id: string;
  name: string | null;
  email: string | null;
  role: UserRole | null;
  class: string | null;
  birth_date: string | null;
  division: string | null;
  skills: string[] | null;
  bio: string | null;
  photo_url: string | null;
  created_at: string;
  updated_at: string;
}

interface AuthContextType {
  session: Session | null;
  user: User | null;
  profile: UserProfile | null;
  isLoading: boolean;
  signIn: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signUp: (email: string, password: string, name: string) => Promise<{ success: boolean; error?: string }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    console.log('AuthProvider: Initializing auth state');
    
    // Set a timeout to prevent infinite loading
    const loadingTimeout = setTimeout(() => {
      console.log('Auth loading timeout reached, forcing loading to false');
      setIsLoading(false);
    }, 10000); // 10 second timeout
    
    // Set up auth state listener first
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, currentSession) => {
        console.log('Auth state changed:', event, currentSession?.user?.id);
        setSession(currentSession);
        setUser(currentSession?.user ?? null);
        
        // Fetch profile if user is logged in
        if (currentSession?.user) {
          setTimeout(() => {
            fetchProfile(currentSession.user.id);
          }, 0);
        } else {
          setProfile(null);
          // Always set loading to false when no user
          setIsLoading(false);
        }
      }
    );

    // Then check for existing session
    supabase.auth.getSession().then(({ data: { session: currentSession }, error }) => {
      console.log('Initial session check:', { session: currentSession?.user?.id, error });
      
      if (error) {
        console.error('Error getting session:', error);
        setIsLoading(false);
        return;
      }
      
      setSession(currentSession);
      setUser(currentSession?.user ?? null);
      
      // Fetch profile if user is logged in
      if (currentSession?.user) {
        fetchProfile(currentSession.user.id);
      } else {
        // No user found, stop loading
        setIsLoading(false);
      }
    }).catch((error) => {
      console.error('Session check failed:', error);
      setIsLoading(false);
    });

    return () => {
      clearTimeout(loadingTimeout);
      subscription.unsubscribe();
    };
  }, []);

  const fetchProfile = async (userId: string) => {
    try {
      console.log("Fetching profile for user ID:", userId);
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle(); // Use maybeSingle instead of single to avoid errors
      
      if (error && error.code !== 'PGRST116') {
        // Only log and throw for errors other than "no rows returned"
        console.error('Error fetching profile:', error);
        setIsLoading(false); // Stop loading on error
        return;
      }
      
      if (data) {
        console.log("Profile data fetched:", data);
        setProfile(data as UserProfile);
        setIsLoading(false); // Stop loading after successful profile fetch
      } else {
        console.log("No profile found, creating new profile");
        // Create profile if it doesn't exist
        const currentUser = await supabase.auth.getUser();
        if (currentUser.data.user?.email) {
          const { error: createError } = await supabase.from('profiles').insert({
            id: userId,
            email: currentUser.data.user.email,
            name: currentUser.data.user.user_metadata.name || currentUser.data.user.email,
            role: 'non-member',
            class: null,
            birth_date: null,
            division: null,
            skills: null,
            bio: null,
            photo_url: null,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          });
          
          if (createError) {
            console.error('Error creating profile:', createError);
            setIsLoading(false); // Stop loading even if profile creation fails
          } else {
            // Fetch the newly created profile
            const { data: newProfile } = await supabase
              .from('profiles')
              .select('*')
              .eq('id', userId)
              .maybeSingle();
              
            if (newProfile) {
              console.log("New profile created:", newProfile);
              setProfile(newProfile as UserProfile);
            }
            setIsLoading(false); // Stop loading after profile creation
          }
        } else {
          console.error('No user email found');
          setIsLoading(false);
        }
      }
    } catch (error) {
      console.error('Error in fetchProfile:', error);
      setIsLoading(false); // Always stop loading on catch
    }
  };

  const refreshProfile = async () => {
    if (user) {
      await fetchProfile(user.id);
    }
  };

  const signIn = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      console.log('Starting sign in process for:', email);
      setIsLoading(true);
      
      const { data, error } = await supabase.auth.signInWithPassword({ 
        email: email.trim(), 
        password 
      });
      
      if (error) {
        console.error('Login error:', error);
        let errorMessage = 'Gagal login. Periksa email dan password Anda.';
        
        if (error.message.includes('Invalid login credentials')) {
          errorMessage = 'Email atau password salah. Silakan coba lagi.';
        } else if (error.message.includes('Email not confirmed')) {
          errorMessage = 'Email belum dikonfirmasi. Periksa email Anda.';
        } else if (error.message.includes('Too many requests')) {
          errorMessage = 'Terlalu banyak percobaan. Coba lagi dalam beberapa menit.';
        }
        
        toast.error(errorMessage);
        return { success: false, error: errorMessage };
      }
      
      if (data.user) {
        console.log('Login successful for user:', data.user.id);
        toast.success('Login berhasil!');
        return { success: true };
      }
      
      return { success: false, error: 'Login tidak berhasil' };
    } catch (error: any) {
      console.error('Error signing in:', error);
      const errorMessage = error?.message || 'Terjadi kesalahan saat login';
      toast.error(errorMessage);
      return { success: false, error: errorMessage };
    } finally {
      setIsLoading(false);
    }
  };

  const signUp = async (email: string, password: string, name: string): Promise<{ success: boolean; error?: string }> => {
    try {
      setIsLoading(true);
      
      // Get current window origin for redirect URL
      const redirectUrl = `${window.location.origin}/`;
      
      // Register the user
      const { data: authData, error: authError } = await supabase.auth.signUp({ 
        email, 
        password,
        options: {
          emailRedirectTo: redirectUrl,
          data: {
            name
          }
        }
      });
      
      if (authError) {
        console.error('Signup error:', authError);
        toast.error(authError.message || 'Gagal mendaftar. Email mungkin sudah terdaftar.');
        return { success: false, error: authError.message };
      }

      // Create profile if signup was successful
      if (authData.user && !authData.user.email_confirmed_at) {
        // For email confirmation flow
        toast.success('Registrasi berhasil! Periksa email Anda untuk konfirmasi akun.');
        return { success: true };
      } else if (authData.user) {
        // If email is auto-confirmed, create profile
        const { error: profileError } = await supabase.from('profiles').insert({
          id: authData.user.id,
          name: name,
          email: email,
          role: 'non-member'
        });

        if (profileError) {
          console.error('Error creating profile:', profileError);
          // We continue even if profile creation fails, as the user was created
        }
        
        toast.success('Registrasi berhasil! Anda sudah dapat login.');
        return { success: true };
      }
      
      return { success: false, error: 'Terjadi kesalahan tidak diketahui' };
    } catch (error) {
      console.error('Error signing up:', error);
      const errorMessage = 'Terjadi kesalahan saat mendaftar';
      toast.error(errorMessage);
      return { success: false, error: errorMessage };
    } finally {
      setIsLoading(false);
    }
  };

  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      
      if (error) {
        toast.error(error.message);
        throw error;
      }
      
      // Clear local state
      setSession(null);
      setUser(null);
      setProfile(null);
      
      toast.success('Logout berhasil!');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        session,
        user,
        profile,
        isLoading,
        signIn,
        signUp,
        signOut,
        refreshProfile
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
